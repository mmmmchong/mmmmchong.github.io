/* Copyright 2018 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include <sys/time.h>
// add files
#include "mynbiq.cc"
#include "pmzjpl.cc"
#include "sgqeje.cc"
#include "ydtzir.cc"
#include "wztejd.cc"
#include "xcvkpr.cc"
#include "dlnktu.cc"
// end files


extern "C" const float* coder(float *input_v) {
//  timeval t_start, t_end; 
//  gettimeofday( &t_start, NULL);
 const Eigen::ThreadPoolDevice* device = tflite::eigen_support::CreateThreadPoolDevice(-1);
 auto* cpu_backend = new CpuBackendContext();
 cpu_backend->SetMaxNumThreads(-1);
  // add function
 auto* out_3 = input_v;
 auto* out_1 = mynbiq::mynbiq(out_3, device);
 auto* out_14 = pmzjpl::pmzjpl(out_1);
 free(out_1);
 auto* out_5 = sgqeje::sgqeje(out_14, device);
 free(out_14);
 auto* out_15 = ydtzir::ydtzir(out_5);
 free(out_5);
 auto* out_8 = wztejd::wztejd(out_15, cpu_backend);
 free(out_15);
 auto* out_10 = xcvkpr::xcvkpr(out_8, cpu_backend);
 free(out_8);
 delete cpu_backend;
 auto* out_12 = dlnktu::dlnktu(out_10);
 free(out_10);
 return out_12;
  // end function
}
