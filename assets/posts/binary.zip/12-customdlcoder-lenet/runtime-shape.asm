# Actual instructions and data from model; addresses are ELF virtual addresses.
# At the MaxPool call: rdi=params, rsi=input_shape, rdx=input_data, rcx=output_shape, r8=output_data.

# First pool wrapper: build two stack RuntimeShapes and call MaxPool
0x4077a0: endbr64   
0x4077a4: push      rbx
0x4077a5: sub       rsp, 0x90
0x4077ac: mov       rbx, qword ptr fs:[0x28]
0x4077b5: mov       qword ptr [rsp + 0x88], rbx
0x4077bd: mov       rbx, rdi
0x4077c0: mov       edi, 0x5000
0x4077c5: call      0x403890
0x4077ca: mov       ecx, 2
0x4077cf: lea       rsi, [rsp + 0x40]
0x4077d4: mov       rdx, qword ptr [rip + 0x5af4d]
0x4077db: movd      xmm0, ecx
0x4077df: mov       r8, rax
0x4077e2: lea       rcx, [rsp + 0x60]
0x4077e7: mov       qword ptr [rsp + 8], rax
0x4077ec: pshufd    xmm0, xmm0, 0
0x4077f1: movups    xmmword ptr [rsp + 0x1c], xmm0
0x4077f6: movdqa    xmm0, xmmword ptr [rip + 0x5b092]
0x4077fe: lea       rdi, [rsp + 0x10]
0x407803: mov       qword ptr [rsp + 0x34], rdx
0x407808: movups    xmmword ptr [rsp + 0x68], xmm0
0x40780d: movdqa    xmm0, xmmword ptr [rip + 0x5b08b]
0x407815: mov       rdx, rbx
0x407818: mov       dword ptr [rsp + 0x12], 0
0x407820: mov       dword ptr [rsp + 0x60], 4
0x407828: mov       dword ptr [rsp + 0x40], 4
0x407830: movups    xmmword ptr [rsp + 0x48], xmm0
0x407835: call      0x41c680

# MaxPool: read shape ranks and dimensions
0x41c680: endbr64   
0x41c684: push      r15
0x41c686: mov       rax, rsi
0x41c689: mov       rsi, rcx
0x41c68c: push      r14
0x41c68e: mov       r14, rdx
0x41c691: push      r13
0x41c693: mov       r13, r8
0x41c696: push      r12
0x41c698: push      rbp
0x41c699: push      rbx
0x41c69a: sub       rsp, 0x20
0x41c69e: mov       qword ptr [rsp - 0x48], rdi
0x41c6a3: mov       edi, dword ptr [rcx]
0x41c6a5: cmp       edi, 5
0x41c6a8: jle       0x41cf44
0x41c6ae: mov       r9, qword ptr [rcx + 8]
0x41c6b2: mov       ecx, dword ptr [rax]
0x41c6b4: mov       edx, dword ptr [r9]
0x41c6b7: cmp       ecx, 5
0x41c6ba: jg        0x41cf52
0x41c6c0: mov       r8d, dword ptr [rax + 8]
0x41c6c4: mov       r10d, dword ptr [rax + 0xc]
0x41c6c8: mov       ebp, dword ptr [rax + 0x10]
0x41c6cb: cmp       edx, r8d
0x41c6ce: cmovle    r8d, edx
0x41c6d2: mov       ebx, dword ptr [r9 + 4]
0x41c6d6: mov       dword ptr [rsp - 0x38], ebx
0x41c6da: mov       ebx, dword ptr [r9 + 8]
0x41c6de: mov       dword ptr [rsp - 0x34], ebx
0x41c6e2: mov       rbx, qword ptr [rsp - 0x48]
0x41c6e7: mov       edx, dword ptr [rbx + 0xc]
0x41c6ea: mov       ebx, dword ptr [rbx + 0x10]
0x41c6ed: mov       dword ptr [rsp - 0x40], edx
0x41c6f1: lea       edx, [rcx - 1]
0x41c6f4: mov       dword ptr [rsp - 0x3c], ebx

# Small output shape branch
0x41cf44: mov       edx, dword ptr [rcx + 8]
0x41cf47: mov       ecx, dword ptr [rax]
0x41cf49: cmp       ecx, 5
0x41cf4c: jle       0x41d102

# First pool input dimensions: N,H,W,C
0x4628a0: .long 1, 32, 32, 20

# First pool output dimensions: N,H,W,C
0x462890: .long 1, 16, 16, 20
