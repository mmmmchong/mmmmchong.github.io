# Symbols and machine instructions from this delivered ELF.
# Each function excerpt is limited to its first 180 instructions.

# main @ 0x404460, size=396
0x404460: endbr64    
0x404464: push       r14
0x404466: push       r13
0x404468: mov        r13, rsi
0x40446b: push       r12
0x40446d: push       rbp
0x40446e: push       rbx
0x40446f: cmp        edi, 3
0x404472: jne        0x4045ad
0x404478: mov        ebx, edi
0x40447a: mov        edi, 0x6000
0x40447f: call       0x4037e0
0x404484: xor        esi, esi
0x404486: mov        edx, 0x5ffc
0x40448b: mov        dword ptr [rax], 0
0x404491: lea        rdi, [rax + 4]
0x404495: mov        r12, rax
0x404498: call       0x403690
0x40449d: mov        rdi, qword ptr [r13 + 8]
0x4044a1: mov        esi, 0x460880
0x4044a6: call       0x403820
0x4044ab: mov        rbp, rax
0x4044ae: test       rax, rax
0x4044b1: je         0x403a4e
0x4044b7: mov        rcx, rax
0x4044ba: mov        edx, 0x1800
0x4044bf: mov        esi, 4
0x4044c4: mov        rdi, r12
0x4044c7: call       0x4038f0
0x4044cc: xor        r14d, r14d
0x4044cf: cmp        rax, 0x1800
0x4044d5: je         0x4045cf
0x4044db: mov        rdi, rbp
0x4044de: call       0x4037d0
0x4044e3: test       r14b, r14b
0x4044e6: je         0x40458e
0x4044ec: mov        rdi, r12
0x4044ef: call       0x4163e0
0x4044f4: mov        rbp, rax
0x4044f7: test       rax, rax
0x4044fa: je         0x404576
0x4044fc: mov        rdi, qword ptr [r13 + 0x10]
0x404500: mov        esi, 0x4608a1
0x404505: call       0x403820
0x40450a: mov        rbx, rax
0x40450d: test       rax, rax
0x404510: je         0x403a40
0x404516: mov        rcx, rax
0x404519: mov        edx, 4
0x40451e: mov        esi, 1
0x404523: mov        rdi, rbp
0x404526: call       0x403a00
0x40452b: mov        rdi, rbx
0x40452e: mov        r13, rax
0x404531: call       0x4037d0
0x404536: test       eax, eax
0x404538: pxor       xmm0, xmm0
0x40453c: mov        edx, 4
0x404541: mov        esi, 0x4608a4
0x404546: sete       bl
0x404549: cmp        r13, 4
0x40454d: mov        edi, 2
0x404552: cvtss2sd   xmm0, dword ptr [rbp]
0x404557: sete       al
0x40455a: and        ebx, eax
0x40455c: mov        eax, 1
0x404561: call       0x403540
0x404566: xor        ebx, 1
0x404569: mov        rdi, rbp
0x40456c: call       0x403830
0x404571: movzx      ebx, bl
0x404574: add        ebx, ebx
0x404576: mov        esi, 0x6000
0x40457b: mov        rdi, r12
0x40457e: call       0x4037f0
0x404583: mov        eax, ebx
0x404585: pop        rbx
0x404586: pop        rbp
0x404587: pop        r12
0x404589: pop        r13
0x40458b: pop        r14
0x40458d: ret        
0x40458e: mov        rdi, qword ptr [rip + 0x69e34b]
0x404595: mov        edx, 0x460883
0x40459a: mov        esi, 2
0x40459f: xor        eax, eax
0x4045a1: call       0x403920
0x4045a6: mov        ebx, 2
0x4045ab: jmp        0x404576
0x4045ad: mov        rcx, qword ptr [rsi]
0x4045b0: mov        rdi, qword ptr [rip + 0x69e329]
0x4045b7: mov        edx, 0x460030
0x4045bc: xor        eax, eax
0x4045be: mov        esi, 2
0x4045c3: call       0x403920
0x4045c8: mov        eax, 2
0x4045cd: jmp        0x404585
0x4045cf: mov        rdi, rbp
0x4045d2: call       0x403900
0x4045d7: add        eax, 1
0x4045da: sete       r14b
0x4045de: jmp        0x4044db
0x4045e3: endbr64    
0x4045e7: jmp        0x403a60

# pmzjpl::pmzjpl(float*) @ 0x4077a0, size=192
0x4077a0: endbr64    
0x4077a4: push       rbx
0x4077a5: sub        rsp, 0x90
0x4077ac: mov        rbx, qword ptr fs:[0x28]
0x4077b5: mov        qword ptr [rsp + 0x88], rbx
0x4077bd: mov        rbx, rdi
0x4077c0: mov        edi, 0x5000
0x4077c5: call       0x403890
0x4077ca: mov        ecx, 2
0x4077cf: lea        rsi, [rsp + 0x40]
0x4077d4: mov        rdx, qword ptr [rip + 0x5af4d]
0x4077db: movd       xmm0, ecx
0x4077df: mov        r8, rax
0x4077e2: lea        rcx, [rsp + 0x60]
0x4077e7: mov        qword ptr [rsp + 8], rax
0x4077ec: pshufd     xmm0, xmm0, 0
0x4077f1: movups     xmmword ptr [rsp + 0x1c], xmm0
0x4077f6: movdqa     xmm0, xmmword ptr [rip + 0x5b092]
0x4077fe: lea        rdi, [rsp + 0x10]
0x407803: mov        qword ptr [rsp + 0x34], rdx
0x407808: movups     xmmword ptr [rsp + 0x68], xmm0
0x40780d: movdqa     xmm0, xmmword ptr [rip + 0x5b08b]
0x407815: mov        rdx, rbx
0x407818: mov        dword ptr [rsp + 0x12], 0
0x407820: mov        dword ptr [rsp + 0x60], 4
0x407828: mov        dword ptr [rsp + 0x40], 4
0x407830: movups     xmmword ptr [rsp + 0x48], xmm0
0x407835: call       0x41c680
0x40783a: mov        rax, qword ptr [rsp + 8]
0x40783f: mov        rdx, qword ptr [rsp + 0x88]
0x407847: sub        rdx, qword ptr fs:[0x28]
0x407850: jne        0x40785b
0x407852: add        rsp, 0x90
0x407859: pop        rbx
0x40785a: ret        
0x40785b: call       0x403800

# ydtzir::ydtzir(float*) @ 0x407860, size=192
0x407860: endbr64    
0x407864: push       rbx
0x407865: sub        rsp, 0x90
0x40786c: mov        rbx, qword ptr fs:[0x28]
0x407875: mov        qword ptr [rsp + 0x88], rbx
0x40787d: mov        rbx, rdi
0x407880: mov        edi, 0x3200
0x407885: call       0x403890
0x40788a: mov        ecx, 2
0x40788f: lea        rsi, [rsp + 0x40]
0x407894: mov        rdx, qword ptr [rip + 0x5ae8d]
0x40789b: movd       xmm0, ecx
0x40789f: mov        r8, rax
0x4078a2: lea        rcx, [rsp + 0x60]
0x4078a7: mov        qword ptr [rsp + 8], rax
0x4078ac: pshufd     xmm0, xmm0, 0
0x4078b1: movups     xmmword ptr [rsp + 0x1c], xmm0
0x4078b6: movdqa     xmm0, xmmword ptr [rip + 0x5aff2]
0x4078be: lea        rdi, [rsp + 0x10]
0x4078c3: mov        qword ptr [rsp + 0x34], rdx
0x4078c8: movups     xmmword ptr [rsp + 0x68], xmm0
0x4078cd: movdqa     xmm0, xmmword ptr [rip + 0x5afeb]
0x4078d5: mov        rdx, rbx
0x4078d8: mov        dword ptr [rsp + 0x12], 0
0x4078e0: mov        dword ptr [rsp + 0x60], 4
0x4078e8: mov        dword ptr [rsp + 0x40], 4
0x4078f0: movups     xmmword ptr [rsp + 0x48], xmm0
0x4078f5: call       0x41c680
0x4078fa: mov        rax, qword ptr [rsp + 8]
0x4078ff: mov        rdx, qword ptr [rsp + 0x88]
0x407907: sub        rdx, qword ptr fs:[0x28]
0x407910: jne        0x40791b
0x407912: add        rsp, 0x90
0x407919: pop        rbx
0x40791a: ret        
0x40791b: call       0x403800

# dlnktu::dlnktu(float*) @ 0x407960, size=102
0x407960: endbr64    
0x407964: push       rbp
0x407965: mov        rbp, rdi
0x407968: mov        edi, 4
0x40796d: push       rbx
0x40796e: sub        rsp, 8
0x407972: call       0x403890
0x407977: movss      xmm0, dword ptr [rbp]
0x40797c: mov        rbx, rax
0x40797f: call       0x403940
0x407984: ucomiss    xmm0, dword ptr [rip + 0x5867d]
0x40798b: jp         0x4079a8
0x40798d: jne        0x4079a8
0x40798f: movss      xmm0, dword ptr [rip + 0x5866d]
0x407997: mov        rax, rbx
0x40799a: movss      dword ptr [rbx], xmm0
0x40799e: add        rsp, 8
0x4079a2: pop        rbx
0x4079a3: pop        rbp
0x4079a4: ret        
0x4079a5: nop        dword ptr [rax]
0x4079a8: movss      xmm1, dword ptr [rip + 0x58654]
0x4079b0: mov        rax, rbx
0x4079b3: addss      xmm1, xmm0
0x4079b7: divss      xmm0, xmm1
0x4079bb: movss      dword ptr [rbx], xmm0
0x4079bf: add        rsp, 8
0x4079c3: pop        rbx
0x4079c4: pop        rbp
0x4079c5: ret        

# tflite::optimized_ops::FullyConnected(tflite::FullyConnectedParams const&, tflite::RuntimeShape const&, float const*, tflite::RuntimeShape const&, float const*, tflite::RuntimeShape const&, float const*, tflite::RuntimeShape const&, float*, tflite::CpuBackendContext*) [clone .isra.0] @ 0x4079d0, size=1650
0x4079d0: push       r15
0x4079d2: movaps     xmm2, xmm0
0x4079d5: mov        r11d, esi
0x4079d8: push       r14
0x4079da: unpcklps   xmm2, xmm1
0x4079dd: push       r13
0x4079df: push       r12
0x4079e1: push       rbp
0x4079e2: push       rbx
0x4079e3: sub        rsp, 0x2a8
0x4079ea: mov        byte ptr [rsp + 0xf], dil
0x4079ef: mov        rbp, qword ptr [rsp + 0x2e0]
0x4079f7: mov        qword ptr [rsp + 0x10], rcx
0x4079fc: mov        ecx, dword ptr [r8]
0x4079ff: mov        qword ptr [rsp + 0x18], r9
0x407a04: mov        rsi, qword ptr [rsp + 0x2e8]
0x407a0c: lea        edi, [rcx - 1]
0x407a0f: mov        r10, qword ptr [rsp + 0x2f0]
0x407a17: movsxd     r12, edi
0x407a1a: mov        rbx, qword ptr fs:[0x28]
0x407a23: mov        qword ptr [rsp + 0x298], rbx
0x407a2b: mov        rbx, qword ptr [rsp + 0x2f8]
0x407a33: cmp        ecx, 5
0x407a36: jle        0x407fc0
0x407a3c: mov        rax, qword ptr [r8 + 8]
0x407a40: mov        r9d, dword ptr [rax + r12*4]
0x407a44: mov        r13d, dword ptr [rdx]
0x407a47: pxor       xmm0, xmm0
0x407a4b: mov        dword ptr [rsp + 0x30], 0
0x407a53: movaps     xmmword ptr [rsp + 0x20], xmm0
0x407a58: mov        dword ptr [rsp + 0x24], r9d
0x407a5d: cmp        r13d, 5
0x407a61: jle        0x407fa0
0x407a67: mov        r14, qword ptr [rdx + 8]
0x407a6b: cmp        r13d, 0x1b
0x407a6f: jle        0x408031
0x407a75: mov        edx, r13d
0x407a78: pcmpeqd    xmm1, xmm1
0x407a7c: movaps     xmm4, xmm2
0x407a7f: mov        rax, r14
0x407a82: shr        edx, 2
0x407a85: psrld      xmm1, 0x1f
0x407a8a: shl        rdx, 4
0x407a8e: add        rdx, r14
0x407a91: nop        dword ptr [rax]
0x407a94: nop        word ptr cs:[rax + rax]
0x407a9f: nop        word ptr cs:[rax + rax]
0x407aaa: nop        word ptr cs:[rax + rax]
0x407ab5: nop        word ptr cs:[rax + rax]
0x407ac0: movdqu     xmm0, xmmword ptr [rax]
0x407ac4: add        rax, 0x10
0x407ac8: movdqa     xmm2, xmm0
0x407acc: psrlq      xmm0, 0x20
0x407ad1: pmuludq    xmm2, xmm1
0x407ad5: psrlq      xmm1, 0x20
0x407ada: pmuludq    xmm0, xmm1
0x407ade: pshufd     xmm1, xmm2, 8
0x407ae3: pshufd     xmm0, xmm0, 8
0x407ae8: punpckldq  xmm1, xmm0
0x407aec: cmp        rax, rdx
0x407aef: jne        0x407ac0
0x407af1: movdqa     xmm0, xmm1
0x407af5: movaps     xmm2, xmm4
0x407af8: psrldq     xmm0, 8
0x407afd: movdqa     xmm3, xmm0
0x407b01: psrlq      xmm0, 0x20
0x407b06: pmuludq    xmm3, xmm1
0x407b0a: psrlq      xmm1, 0x20
0x407b0f: pmuludq    xmm0, xmm1
0x407b13: pshufd     xmm1, xmm3, 8
0x407b18: pshufd     xmm0, xmm0, 8
0x407b1d: punpckldq  xmm1, xmm0
0x407b21: movdqa     xmm0, xmm1
0x407b25: psrldq     xmm0, 4
0x407b2a: pmuludq    xmm0, xmm1
0x407b2e: movd       eax, xmm0
0x407b32: test       r13b, 3
0x407b36: je         0x407b94
0x407b38: mov        edx, r13d
0x407b3b: and        edx, 0xfffffffc
0x407b3e: movsxd     rdx, edx
0x407b41: mov        r15, rdx
0x407b44: imul       eax, dword ptr [r14 + rdx*4]
0x407b49: add        rdx, 1
0x407b4d: not        r15
0x407b50: add        r15d, r13d
0x407b53: cmp        r13d, edx
0x407b56: jle        0x407b94
0x407b58: and        r15d, 1
0x407b5c: je         0x407b80
0x407b5e: imul       eax, dword ptr [r14 + rdx*4]
0x407b63: add        rdx, 1
0x407b67: cmp        r13d, edx
0x407b6a: jle        0x407b94
0x407b6c: nop        word ptr [rax + rax]
0x407b75: nop        word ptr cs:[rax + rax]
0x407b80: imul       eax, dword ptr [r14 + rdx*4]
0x407b85: imul       eax, dword ptr [r14 + rdx*4 + 4]
0x407b8b: add        rdx, 2
0x407b8f: cmp        r13d, edx
0x407b92: jg         0x407b80
0x407b94: cdq        
0x407b95: pxor       xmm0, xmm0
0x407b99: mov        byte ptr [rsp + 0x30], r11b
0x407b9e: idiv       r9d
0x407ba1: mov        dword ptr [rsp + 0x40], 1
0x407ba9: movups     xmmword ptr [rsp + 0x44], xmm0
0x407bae: mov        dword ptr [rsp + 0x28], eax
0x407bb2: cmp        ecx, 5
0x407bb5: jle        0x407f80
0x407bbb: mov        rdx, qword ptr [r8 + 8]
0x407bbf: mov        r12d, dword ptr [rdx + r12*4]
0x407bc3: mov        dword ptr [rsp + 0x48], r12d
0x407bc8: xor        r13d, r13d
0x407bcb: mov        r8d, 1
0x407bd1: nop        dword ptr [rax]
0x407bd5: nop        word ptr cs:[rax + rax]
0x407be0: cmp        edi, r13d
0x407be3: je         0x407bea
0x407be5: imul       r8d, dword ptr [rdx + r13*4]
0x407bea: add        r13, 1
0x407bee: cmp        ecx, r13d
0x407bf1: jg         0x407be0
0x407bf3: test       r8d, r8d
0x407bf6: setg       r15b
0x407bfa: movzx      ecx, byte ptr [rsp + 0xf]
0x407bff: mov        edi, dword ptr [rsi]
0x407c01: pxor       xmm0, xmm0
0x407c05: mov        dword ptr [rsp + 0x44], r8d
0x407c0a: mov        dword ptr [rsp + 0x70], 0
0x407c12: mov        byte ptr [rsp + 0x50], cl
0x407c16: lea        r13d, [rdi - 1]
0x407c1a: movaps     xmmword ptr [rsp + 0x60], xmm0
0x407c1f: cmp        edi, 5
0x407c22: jle        0x407f58
0x407c28: mov        rsi, qword ptr [rsi + 8]
0x407c2c: movsxd     rdx, r13d
0x407c2f: mov        r14d, dword ptr [rsi + rdx*4]
0x407c33: mov        dword ptr [rsp + 0x64], r14d
0x407c38: xor        edx, edx
0x407c3a: mov        ecx, 1
0x407c3f: nop        
0x407c40: cmp        r13d, edx
0x407c43: je         0x407c49
0x407c45: imul       ecx, dword ptr [rsi + rdx*4]
0x407c49: add        rdx, 1
0x407c4d: cmp        edi, edx
0x407c4f: jg         0x407c40
0x407c51: test       ecx, ecx
0x407c53: setg       dil
0x407c57: test       r9d, r9d
0x407c5a: pxor       xmm0, xmm0
0x407c5e: mov        dword ptr [rsp + 0x68], ecx
0x407c62: setg       dl
0x407c65: test       eax, eax
0x407c67: mov        qword ptr [rsp + 0x120], 0
0x407c73: setg       sil
0x407c77: mov        qword ptr [rsp + 0x138], rbp
0x407c7f: and        edx, esi
0x407c81: movups     xmmword ptr [rsp + 0x128], xmm0
0x407c89: and        edx, r15d
0x407c8c: test       r12d, r12d
0x407c8f: movlps     qword ptr [rsp + 0x140], xmm2
0x407c97: setg       sil
0x407c9b: and        edx, esi
0x407c9d: cmp        r9d, r12d
0x407ca0: sete       sil
0x407ca4: and        esi, edx
0x407ca6: and        esi, edi
0x407ca8: test       r14d, r14d
0x407cab: setg       dl
0x407cae: test       sil, dl
0x407cb1: je         0x407f29
0x407cb7: cmp        eax, ecx
0x407cb9: jne        0x407f29
0x407cbf: cmp        byte ptr [rbx + 0x20], 0
0x407cc3: je         0x407fd0
0x407cc9: mov        rdi, qword ptr [rbx + 8]
0x407ccd: mov        rbx, qword ptr [rsp + 0x10]
0x407cd2: mov        qword ptr [rsp + 0xd5], 0
# ... excerpt ends ...

# xcvkpr::xcvkpr(float*, tflite::CpuBackendContext*) @ 0x408050, size=200
0x408050: endbr64    
0x408054: push       r12
0x408056: mov        r12, rdi
0x408059: mov        edi, 4
0x40805e: push       rbp
0x40805f: push       rbx
0x408060: sub        rsp, 0x70
0x408064: mov        rbp, qword ptr fs:[0x28]
0x40806d: mov        qword ptr [rsp + 0x68], rbp
0x408072: mov        rbp, rsi
0x408075: call       0x403890
0x40807a: mov        dword ptr [rsp + 0x40], 2
0x408082: mov        rdx, rsp
0x408085: mov        rcx, r12
0x408088: mov        rbx, rax
0x40808b: mov        dword ptr [rsp], 2
0x408092: movabs     rax, 0x100000001
0x40809c: mov        r9, qword ptr [rip + 0x6420d]
0x4080a3: mov        qword ptr [rsp + 0x48], rax
0x4080a8: xor        esi, esi
0x4080aa: movabs     rax, 0x1f400000001
0x4080b4: movss      xmm1, dword ptr [rip + 0x5a670]
0x4080bc: mov        qword ptr [rsp + 0x28], rax
0x4080c1: movss      xmm0, dword ptr [rip + 0x5a65f]
0x4080c9: mov        edi, 1
0x4080ce: mov        qword ptr [rsp + 8], rax
0x4080d3: mov        dword ptr [rsp + 0x20], 2
0x4080db: push       rbp
0x4080dc: push       rbx
0x4080dd: lea        rax, [rsp + 0x50]
0x4080e2: push       rax
0x4080e3: push       qword ptr [rip + 0x641bf]
0x4080e9: lea        r8, [rsp + 0x40]
0x4080ee: call       0x4079d0
0x4080f3: add        rsp, 0x20
0x4080f7: mov        rax, qword ptr [rsp + 0x68]
0x4080fc: sub        rax, qword ptr fs:[0x28]
0x408105: jne        0x408113
0x408107: add        rsp, 0x70
0x40810b: mov        rax, rbx
0x40810e: pop        rbx
0x40810f: pop        rbp
0x408110: pop        r12
0x408112: ret        
0x408113: call       0x403800

# wztejd::wztejd(float*, tflite::CpuBackendContext*) @ 0x408120, size=204
0x408120: endbr64    
0x408124: push       r12
0x408126: mov        r12, rdi
0x408129: mov        edi, 0x7d0
0x40812e: push       rbp
0x40812f: push       rbx
0x408130: sub        rsp, 0x70
0x408134: mov        rbp, qword ptr fs:[0x28]
0x40813d: mov        qword ptr [rsp + 0x68], rbp
0x408142: mov        rbp, rsi
0x408145: call       0x403890
0x40814a: movdqa     xmm0, xmmword ptr [rip + 0x5a75e]
0x408152: mov        rdx, rsp
0x408155: xor        esi, esi
0x408157: mov        rbx, rax
0x40815a: mov        dword ptr [rsp + 0x40], 2
0x408162: movabs     rax, 0x1f400000001
0x40816c: mov        r9, qword ptr [rip + 0x6492d]
0x408173: mov        qword ptr [rsp + 0x48], rax
0x408178: mov        rcx, r12
0x40817b: movabs     rax, 0xc80000001f4
0x408185: movss      xmm1, dword ptr [rip + 0x5a59f]
0x40818d: mov        qword ptr [rsp + 0x28], rax
0x408192: mov        edi, 1
0x408197: movups     xmmword ptr [rsp + 8], xmm0
0x40819c: pxor       xmm0, xmm0
0x4081a0: mov        dword ptr [rsp + 0x20], 2
0x4081a8: mov        dword ptr [rsp], 4
0x4081af: push       rbp
0x4081b0: push       rbx
0x4081b1: lea        rax, [rsp + 0x50]
0x4081b6: push       rax
0x4081b7: push       qword ptr [rip + 0x648db]
0x4081bd: lea        r8, [rsp + 0x40]
0x4081c2: call       0x4079d0
0x4081c7: add        rsp, 0x20
0x4081cb: mov        rax, qword ptr [rsp + 0x68]
0x4081d0: sub        rax, qword ptr fs:[0x28]
0x4081d9: jne        0x4081e7
0x4081db: add        rsp, 0x70
0x4081df: mov        rax, rbx
0x4081e2: pop        rbx
0x4081e3: pop        rbp
0x4081e4: pop        r12
0x4081e6: ret        
0x4081e7: call       0x403800

# tflite::multithreaded_ops::EigenTensorConvFunctor<float>::operator()(EigenForTFLite::ThreadPoolDevice const&, float const*, int, int, int, int, float const*, int, int, int, int, int, int, int, tflite::PaddingType, float*, int, int) [clone .isra.0] @ 0x4156e0, size=1674
0x4156e0: push       r15
0x4156e2: mov        r11, rdi
0x4156e5: push       r14
0x4156e7: push       r13
0x4156e9: movsxd     r13, edx
0x4156ec: push       r12
0x4156ee: push       rbp
0x4156ef: push       rbx
0x4156f0: mov        rbx, rsi
0x4156f3: sub        rsp, 0x3e8
0x4156fa: mov        qword ptr [rsp + 8], rsi
0x4156ff: movsxd     rbp, dword ptr [rsp + 0x428]
0x415707: mov        esi, ecx
0x415709: mov        qword ptr [rsp + 0x38], rdi
0x41570e: mov        r10, qword ptr [rsp + 0x420]
0x415716: movsxd     rdx, dword ptr [rsp + 0x430]
0x41571e: mov        ecx, dword ptr [rsp + 0x460]
0x415725: movsxd     r15, dword ptr [rsp + 0x438]
0x41572d: mov        rax, qword ptr fs:[0x28]
0x415736: mov        qword ptr [rsp + 0x3d8], rax
0x41573e: mov        rax, qword ptr [rsp + 0x468]
0x415746: cmp        ebp, 1
0x415749: jne        0x415768
0x41574b: cmp        edx, 1
0x41574e: jne        0x415768
0x415750: cmp        dword ptr [rsp + 0x440], 1
0x415758: jne        0x415768
0x41575a: cmp        dword ptr [rsp + 0x448], 1
0x415762: je         0x415c18
0x415768: cmp        ebp, esi
0x41576a: jne        0x415785
0x41576c: cmp        edx, r8d
0x41576f: jne        0x415785
0x415771: mov        edi, dword ptr [rsp + 0x458]
0x415778: or         edi, dword ptr [rsp + 0x450]
0x41577f: je         0x415cb0
0x415785: mov        qword ptr [rsp + 0x70], rax
0x41578a: movsxd     r14, esi
0x41578d: xor        esi, esi
0x41578f: and        ecx, 0xfd
0x415795: movsxd     rax, dword ptr [rsp + 0x470]
0x41579d: movsxd     rcx, dword ptr [rsp + 0x440]
0x4157a5: setne      sil
0x4157a9: movsxd     r12, r9d
0x4157ac: add        esi, 1
0x4157af: mov        edi, 0x68
0x4157b4: mov        qword ptr [rsp + 0x58], r14
0x4157b9: mov        qword ptr [rsp + 0x80], rax
0x4157c1: movsxd     rax, dword ptr [rsp + 0x478]
0x4157c9: mov        qword ptr [rsp + 0x20], rcx
0x4157ce: movsxd     rcx, dword ptr [rsp + 0x448]
0x4157d6: mov        qword ptr [rsp + 0x88], rax
0x4157de: movsxd     rax, r8d
0x4157e1: mov        qword ptr [rsp + 0x50], r10
0x4157e6: mov        qword ptr [rsp + 0x78], r13
0x4157eb: mov        qword ptr [rsp + 0x90], r15
0x4157f3: mov        qword ptr [rsp + 0x10], rax
0x4157f8: mov        qword ptr [rsp + 0x18], rdx
0x4157fd: mov        dword ptr [rsp + 0x4c], esi
0x415801: mov        qword ptr [rsp + 0x30], rcx
0x415806: call       0x4037e0
0x41580b: mov        rdi, qword ptr [rsp + 8]
0x415810: mov        rbx, rax
0x415813: mov        qword ptr [rax + 0x20], r14
0x415817: lea        r14, [rsp + 0x60]
0x41581c: mov        qword ptr [rax + 0x18], r13
0x415820: movdqu     xmm0, xmmword ptr [rbx + 0x18]
0x415825: mov        qword ptr [rax + 0x10], rdi
0x415829: mov        rax, qword ptr [rsp + 0x10]
0x41582e: mov        edi, 0x68
0x415833: mov        qword ptr [rbx + 0x30], r12
0x415837: mov        qword ptr [rbx + 0x28], rax
0x41583b: movups     xmmword ptr [rbx + 0x40], xmm0
0x41583f: movdqu     xmm0, xmmword ptr [rbx + 0x28]
0x415844: mov        qword ptr [rbx + 0x38], r14
0x415848: mov        dword ptr [rbx + 0x60], 0
0x41584f: mov        qword ptr [rbx], 0x4626e8
0x415856: movups     xmmword ptr [rbx + 0x50], xmm0
0x41585a: call       0x4037e0
0x41585f: mov        rdx, qword ptr [rsp + 0x18]
0x415864: mov        r8, rax
0x415867: mov        r10, qword ptr [rsp + 0x50]
0x41586c: lea        rax, [rsp + 0x70]
0x415871: mov        qword ptr [r8 + 0x18], rbp
0x415875: mov        esi, dword ptr [rsp + 0x4c]
0x415879: movq       xmm1, rax
0x41587e: lea        rax, [rsp + 0x2c0]
0x415886: mov        qword ptr [r8 + 0x20], rdx
0x41588a: movdqu     xmm0, xmmword ptr [r8 + 0x18]
0x415890: mov        qword ptr [r8 + 0x28], r12
0x415894: movq       xmm4, qword ptr [rsp + 0x30]
0x41589a: movhps     xmm4, qword ptr [rsp + 0x20]
0x41589f: mov        qword ptr [r8 + 0x30], r15
0x4158a3: movdqu     xmm2, xmmword ptr [r8 + 0x28]
0x4158a9: movdqa     xmm5, xmm0
0x4158ad: movq       rdi, xmm0
0x4158b2: mov        qword ptr [rsp + 0x40], rax
0x4158b7: mov        rcx, qword ptr [rbx + 0x50]
0x4158bb: movhps     xmm1, qword ptr [rsp + 0x40]
0x4158c0: shufpd     xmm5, xmm0, 1
0x4158c5: movups     xmmword ptr [r8 + 0x50], xmm2
0x4158ca: mov        r9, qword ptr [rbx + 0x48]
0x4158ce: mov        r11, qword ptr [r8 + 0x50]
0x4158d2: mov        qword ptr [r8 + 0x10], r10
0x4158d6: movq       xmm3, qword ptr [r8 + 0x58]
0x4158dc: mov        qword ptr [r8 + 0x38], r14
0x4158e0: mov        dword ptr [r8 + 0x60], 0
0x4158e8: mov        qword ptr [r8], 0x4626e8
0x4158ef: movups     xmmword ptr [r8 + 0x40], xmm0
0x4158f4: movhps     qword ptr [rsp + 0x40], xmm0
0x4158f9: cmp        esi, 2
0x4158fc: jne        0x415bd0
0x415902: test       rcx, rcx
0x415905: je         0x415916
0x415907: lea        rax, [rcx - 1]
0x41590b: cqo        
0x41590d: idiv       qword ptr [rsp + 0x30]
0x415912: lea        rcx, [rax + 1]
0x415916: xor        edx, edx
0x415918: test       r9, r9
0x41591b: jne        0x415d50
0x415921: mov        rax, qword ptr [rsp + 0x40]
0x415926: movdqa     xmm6, xmmword ptr [rip + 0x4cfc2]
0x41592e: pxor       xmm2, xmm2
0x415932: mov        qword ptr [rsp + 0xa8], r13
0x41593a: movaps     xmmword ptr [rsp + 0x20], xmm1
0x41593f: imul       rax, r11
0x415943: mov        r11, qword ptr [rsp + 8]
0x415948: mov        qword ptr [rsp + 0x148], r10
0x415950: movups     xmmword ptr [rsp + 0xc8], xmm5
0x415958: mov        qword ptr [rsp + 0xa0], r11
0x415960: mov        r11, qword ptr [rsp + 0x58]
0x415965: imul       rdi, rax
0x415969: mov        rax, qword ptr [rbx + 0x40]
0x41596d: movdqa     xmm8, xmmword ptr [rsp + 0xa0]
0x415977: movups     xmmword ptr [rsp + 0xd8], xmm4
0x41597f: mov        qword ptr [rsp + 0xb0], r11
0x415987: mov        r11, qword ptr [rsp + 0x10]
0x41598c: imul       rdx, rax
0x415990: movaps     xmmword ptr [rsp + 0x110], xmm2
0x415998: mov        qword ptr [rsp + 0xb8], r11
0x4159a0: mov        r11d, 1
0x4159a6: movq       xmm7, rdi
0x4159ab: movq       xmm0, r11
0x4159b0: mov        qword ptr [rsp + 0x140], rdi
0x4159b8: mov        rdi, qword ptr [rsp + 0x18]
0x4159bd: punpcklqdq xmm7, xmm3
0x4159c1: punpcklqdq xmm0, xmm0
0x4159c5: movaps     xmmword ptr [rsp + 0x120], xmm2
0x4159cd: movaps     xmmword ptr [rsp + 0x170], xmm7
0x4159d5: mov        dword ptr [rsp + 0x130], esi
0x4159dc: mov        qword ptr [rsp + 0x138], rdx
0x4159e4: mov        qword ptr [rsp + 0x158], rdi
0x4159ec: movups     xmmword ptr [rsp + 0xe8], xmm0
0x4159f4: movups     xmmword ptr [rsp + 0xf8], xmm0
0x4159fc: movaps     xmmword ptr [rsp + 0x180], xmm6
0x415a04: mov        qword ptr [rsp + 0xc0], r12
0x415a0c: mov        byte ptr [rsp + 0x108], 0
0x415a14: mov        dword ptr [rsp + 0x134], 0
0x415a1f: mov        qword ptr [rsp + 0x150], rbp
0x415a27: mov        qword ptr [rsp + 0x160], r12
0x415a2f: mov        qword ptr [rsp + 0x168], r15
0x415a37: movaps     xmmword ptr [rsp + 0x1a0], xmm8
0x415a40: movdqa     xmm8, xmmword ptr [rsp + 0xb0]
0x415a4a: mov        rdx, qword ptr [rsp + 0x190]
0x415a52: movups     xmmword ptr [rsp + 0x1e8], xmm0
0x415a5a: movaps     xmmword ptr [rsp + 0x1b0], xmm8
0x415a63: movdqa     xmm8, xmmword ptr [rsp + 0xc0]
0x415a6d: movaps     xmmword ptr [rsp + 0x280], xmm6
0x415a75: movq       xmm6, r9
0x415a7a: movaps     xmmword ptr [rsp + 0x1c0], xmm8
0x415a83: movdqa     xmm8, xmmword ptr [rsp + 0x100]
0x415a8d: mov        qword ptr [rsp + 0x290], rdx
0x415a95: movaps     xmmword ptr [rsp + 0x200], xmm8
0x415a9e: movdqa     xmm8, xmmword ptr [rsp + 0x130]
0x415aa8: movups     xmmword ptr [rsp + 0x1f8], xmm0
0x415ab0: movq       xmm0, rax
0x415ab5: punpcklqdq xmm0, xmm6
0x415ab9: movups     xmmword ptr [rsp + 0x1c8], xmm5
0x415ac1: movaps     xmmword ptr [rsp + 0x230], xmm8
# ... excerpt ends ...

# sgqeje::sgqeje(float*, EigenForTFLite::ThreadPoolDevice const*) @ 0x415d70, size=1005
0x415d70: endbr64    
0x415d74: push       r15
0x415d76: push       r14
0x415d78: push       r13
0x415d7a: push       r12
0x415d7c: push       rbp
0x415d7d: push       rbx
0x415d7e: sub        rsp, 0x18
0x415d82: mov        qword ptr [rsp], rdi
0x415d86: mov        edi, 0xc800
0x415d8b: mov        qword ptr [rsp + 8], rsi
0x415d90: call       0x403890
0x415d95: mov        edx, 0x32
0x415d9a: mov        esi, 1
0x415d9f: mov        r9d, 0x14
0x415da5: mov        rbp, rax
0x415da8: mov        rax, qword ptr [rip + 0x4cac9]
0x415daf: mov        r8d, 0x10
0x415db5: mov        ecx, 0x10
0x415dba: mov        rbx, qword ptr [rip + 0x671517]
0x415dc1: mov        qword ptr [rip + 0x6714fc], rax
0x415dc8: mov        r13, qword ptr [rip + 0x6714f1]
0x415dcf: mov        r15, qword ptr [rip + 0x6714f2]
0x415dd6: mov        r12, r13
0x415dd9: mov        r14, r15
0x415ddc: sar        r12, 0x20
0x415de0: push       r15
0x415de2: sar        r14, 0x20
0x415de6: test       r13d, r13d
0x415de9: push       r12
0x415deb: cmovle     esi, r13d
0x415def: cmp        r14d, edx
0x415df2: push       rbp
0x415df3: cmovle     edx, r14d
0x415df7: push       1
0x415df9: push       2
0x415dfb: push       2
0x415dfd: push       1
0x415dff: push       1
0x415e01: push       rdx
0x415e02: mov        edx, esi
0x415e04: push       5
0x415e06: push       5
0x415e08: push       qword ptr [rip + 0x6714d2]
0x415e0e: mov        rdi, qword ptr [rsp + 0x68]
0x415e13: mov        rsi, qword ptr [rsp + 0x60]
0x415e18: call       0x4156e0
0x415e1d: mov        edi, r12d
0x415e20: add        rsp, 0x60
0x415e24: imul       edi, r13d
0x415e28: imul       edi, r15d
0x415e2c: imul       edi, r14d
0x415e30: test       edi, edi
0x415e32: jle        0x41614b
0x415e38: mov        rcx, 0xfffffffffffffffc
0x415e3f: mov        rax, rbp
0x415e42: xor        esi, esi
0x415e44: sub        rcx, rbx
0x415e47: jmp        0x4160db
0x415e4c: nop        dword ptr [rax]
0x415e50: movups     xmm5, xmmword ptr [rbx]
0x415e53: movups     xmm0, xmmword ptr [rax]
0x415e56: pxor       xmm1, xmm1
0x415e5a: add        esi, 0x32
0x415e5d: movups     xmm7, xmmword ptr [rax + 0x20]
0x415e61: add        rax, 0xc8
0x415e67: addps      xmm0, xmm5
0x415e6a: movaps     xmm3, xmm0
0x415e6d: cmpltps    xmm3, xmm1
0x415e71: andnps     xmm3, xmm0
0x415e74: movss      xmm0, dword ptr [rip + 0x4c8b0]
0x415e7c: shufps     xmm0, xmm0, 0
0x415e80: movaps     xmm2, xmm0
0x415e83: movaps     xmm4, xmm0
0x415e86: cmpltps    xmm2, xmm3
0x415e8a: andps      xmm4, xmm2
0x415e8d: andnps     xmm2, xmm3
0x415e90: orps       xmm2, xmm4
0x415e93: movaps     xmm4, xmm0
0x415e96: movups     xmmword ptr [rax - 0xc8], xmm2
0x415e9d: movups     xmm2, xmmword ptr [rax - 0xb8]
0x415ea4: movups     xmm6, xmmword ptr [rbx + 0x10]
0x415ea8: addps      xmm2, xmm6
0x415eab: movups     xmm6, xmmword ptr [rax - 0x88]
0x415eb2: movaps     xmm3, xmm2
0x415eb5: cmpltps    xmm3, xmm1
0x415eb9: andnps     xmm3, xmm2
0x415ebc: movaps     xmm2, xmm0
0x415ebf: cmpltps    xmm2, xmm3
0x415ec3: andps      xmm4, xmm2
0x415ec6: andnps     xmm2, xmm3
0x415ec9: orps       xmm2, xmm4
0x415ecc: movaps     xmm4, xmm0
0x415ecf: movups     xmmword ptr [rax - 0xb8], xmm2
0x415ed6: movups     xmm2, xmmword ptr [rbx + 0x20]
0x415eda: addps      xmm2, xmm7
0x415edd: movaps     xmm3, xmm2
0x415ee0: cmpltps    xmm3, xmm1
0x415ee4: andnps     xmm3, xmm2
0x415ee7: movaps     xmm2, xmm0
0x415eea: cmpltps    xmm2, xmm3
0x415eee: andps      xmm4, xmm2
0x415ef1: andnps     xmm2, xmm3
0x415ef4: orps       xmm2, xmm4
0x415ef7: movaps     xmm4, xmm0
0x415efa: movups     xmmword ptr [rax - 0xa8], xmm2
0x415f01: movups     xmm2, xmmword ptr [rax - 0x98]
0x415f08: movups     xmm5, xmmword ptr [rbx + 0x30]
0x415f0c: addps      xmm2, xmm5
0x415f0f: movaps     xmm3, xmm2
0x415f12: cmpltps    xmm3, xmm1
0x415f16: andnps     xmm3, xmm2
0x415f19: movaps     xmm2, xmm0
0x415f1c: cmpltps    xmm2, xmm3
0x415f20: andps      xmm4, xmm2
0x415f23: andnps     xmm2, xmm3
0x415f26: orps       xmm2, xmm4
0x415f29: movaps     xmm4, xmm0
0x415f2c: movups     xmmword ptr [rax - 0x98], xmm2
0x415f33: movups     xmm2, xmmword ptr [rbx + 0x40]
0x415f37: addps      xmm2, xmm6
0x415f3a: movups     xmm6, xmmword ptr [rax - 0x58]
0x415f3e: movaps     xmm3, xmm2
0x415f41: cmpltps    xmm3, xmm1
0x415f45: andnps     xmm3, xmm2
0x415f48: movaps     xmm2, xmm0
0x415f4b: cmpltps    xmm2, xmm3
0x415f4f: andps      xmm4, xmm2
0x415f52: andnps     xmm2, xmm3
0x415f55: orps       xmm2, xmm4
0x415f58: movaps     xmm4, xmm0
0x415f5b: movups     xmmword ptr [rax - 0x88], xmm2
0x415f62: movups     xmm2, xmmword ptr [rax - 0x78]
0x415f66: movups     xmm7, xmmword ptr [rbx + 0x50]
0x415f6a: addps      xmm2, xmm7
0x415f6d: movups     xmm7, xmmword ptr [rax - 0x48]
0x415f71: movaps     xmm3, xmm2
0x415f74: cmpltps    xmm3, xmm1
0x415f78: andnps     xmm3, xmm2
0x415f7b: movaps     xmm2, xmm0
0x415f7e: cmpltps    xmm2, xmm3
0x415f82: andps      xmm4, xmm2
0x415f85: andnps     xmm2, xmm3
0x415f88: orps       xmm2, xmm4
0x415f8b: movaps     xmm4, xmm0
0x415f8e: movups     xmmword ptr [rax - 0x78], xmm2
0x415f92: movups     xmm2, xmmword ptr [rax - 0x68]
0x415f96: movups     xmm5, xmmword ptr [rbx + 0x60]
0x415f9a: addps      xmm2, xmm5
0x415f9d: movaps     xmm3, xmm2
0x415fa0: cmpltps    xmm3, xmm1
0x415fa4: andnps     xmm3, xmm2
0x415fa7: movaps     xmm2, xmm0
0x415faa: cmpltps    xmm2, xmm3
0x415fae: andps      xmm4, xmm2
0x415fb1: andnps     xmm2, xmm3
0x415fb4: orps       xmm2, xmm4
0x415fb7: movaps     xmm4, xmm0
0x415fba: movups     xmmword ptr [rax - 0x68], xmm2
0x415fbe: movups     xmm2, xmmword ptr [rbx + 0x70]
0x415fc2: addps      xmm2, xmm6
0x415fc5: movaps     xmm3, xmm2
0x415fc8: cmpltps    xmm3, xmm1
0x415fcc: andnps     xmm3, xmm2
0x415fcf: movaps     xmm2, xmm0
0x415fd2: cmpltps    xmm2, xmm3
0x415fd6: andps      xmm4, xmm2
0x415fd9: andnps     xmm2, xmm3
0x415fdc: orps       xmm2, xmm4
0x415fdf: movaps     xmm4, xmm0
0x415fe2: movups     xmmword ptr [rax - 0x58], xmm2
0x415fe6: movups     xmm2, xmmword ptr [rbx + 0x80]
0x415fed: addps      xmm2, xmm7
0x415ff0: movaps     xmm3, xmm2
0x415ff3: cmpltps    xmm3, xmm1
0x415ff7: andnps     xmm3, xmm2
0x415ffa: movaps     xmm2, xmm0
0x415ffd: cmpltps    xmm2, xmm3
0x416001: andps      xmm4, xmm2
0x416004: andnps     xmm2, xmm3
# ... excerpt ends ...

# mynbiq::mynbiq(float*, EigenForTFLite::ThreadPoolDevice const*) @ 0x416160, size=636
0x416160: endbr64    
0x416164: push       r15
0x416166: push       r14
0x416168: push       r13
0x41616a: push       r12
0x41616c: push       rbp
0x41616d: push       rbx
0x41616e: sub        rsp, 0x18
0x416172: mov        qword ptr [rsp], rdi
0x416176: mov        edi, 0x14000
0x41617b: mov        qword ptr [rsp + 8], rsi
0x416180: call       0x403890
0x416185: mov        edx, 0x14
0x41618a: mov        esi, 1
0x41618f: mov        r9d, 6
0x416195: mov        rbp, rax
0x416198: mov        rax, qword ptr [rip + 0x4c6e9]
0x41619f: mov        r8d, 0x20
0x4161a5: mov        ecx, 0x20
0x4161aa: mov        rbx, qword ptr [rip + 0x689807]
0x4161b1: mov        qword ptr [rip + 0x6897ec], rax
0x4161b8: mov        r13, qword ptr [rip + 0x6897e1]
0x4161bf: mov        r15, qword ptr [rip + 0x6897e2]
0x4161c6: mov        r12, r13
0x4161c9: mov        r14, r15
0x4161cc: sar        r12, 0x20
0x4161d0: push       r15
0x4161d2: sar        r14, 0x20
0x4161d6: test       r13d, r13d
0x4161d9: push       r12
0x4161db: cmovle     esi, r13d
0x4161df: cmp        r14d, edx
0x4161e2: push       rbp
0x4161e3: cmovle     edx, r14d
0x4161e7: push       1
0x4161e9: push       2
0x4161eb: push       2
0x4161ed: push       1
0x4161ef: push       1
0x4161f1: push       rdx
0x4161f2: mov        edx, esi
0x4161f4: push       5
0x4161f6: push       5
0x4161f8: push       qword ptr [rip + 0x6897c2]
0x4161fe: mov        rsi, qword ptr [rsp + 0x60]
0x416203: mov        rdi, qword ptr [rsp + 0x68]
0x416208: call       0x4156e0
0x41620d: mov        esi, r12d
0x416210: add        rsp, 0x60
0x416214: imul       esi, r13d
0x416218: imul       esi, r15d
0x41621c: imul       esi, r14d
0x416220: test       esi, esi
0x416222: jle        0x4163ca
0x416228: mov        rdi, 0xfffffffffffffffc
0x41622f: mov        rax, rbp
0x416232: xor        ecx, ecx
0x416234: sub        rdi, rbx
0x416237: jmp        0x416339
0x41623c: nop        dword ptr [rax]
0x416240: movups     xmm5, xmmword ptr [rbx]
0x416243: movups     xmm0, xmmword ptr [rax]
0x416246: pxor       xmm2, xmm2
0x41624a: add        ecx, 0x14
0x41624d: add        rax, 0x50
0x416251: addps      xmm0, xmm5
0x416254: movaps     xmm3, xmm0
0x416257: cmpltps    xmm3, xmm2
0x41625b: andnps     xmm3, xmm0
0x41625e: movss      xmm0, dword ptr [rip + 0x4c4c6]
0x416266: shufps     xmm0, xmm0, 0
0x41626a: movaps     xmm1, xmm0
0x41626d: movaps     xmm4, xmm0
0x416270: cmpltps    xmm1, xmm3
0x416274: andps      xmm4, xmm1
0x416277: andnps     xmm1, xmm3
0x41627a: orps       xmm1, xmm4
0x41627d: movaps     xmm4, xmm0
0x416280: movups     xmmword ptr [rax - 0x50], xmm1
0x416284: movups     xmm1, xmmword ptr [rax - 0x40]
0x416288: movups     xmm6, xmmword ptr [rbx + 0x10]
0x41628c: addps      xmm1, xmm6
0x41628f: movaps     xmm3, xmm1
0x416292: cmpltps    xmm3, xmm2
0x416296: andnps     xmm3, xmm1
0x416299: movaps     xmm1, xmm0
0x41629c: cmpltps    xmm1, xmm3
0x4162a0: andps      xmm4, xmm1
0x4162a3: andnps     xmm1, xmm3
0x4162a6: orps       xmm1, xmm4
0x4162a9: movaps     xmm4, xmm0
0x4162ac: movups     xmmword ptr [rax - 0x40], xmm1
0x4162b0: movups     xmm1, xmmword ptr [rax - 0x30]
0x4162b4: movups     xmm7, xmmword ptr [rbx + 0x20]
0x4162b8: addps      xmm1, xmm7
0x4162bb: movaps     xmm3, xmm1
0x4162be: cmpltps    xmm3, xmm2
0x4162c2: andnps     xmm3, xmm1
0x4162c5: movaps     xmm1, xmm0
0x4162c8: cmpltps    xmm1, xmm3
0x4162cc: andps      xmm4, xmm1
0x4162cf: andnps     xmm1, xmm3
0x4162d2: orps       xmm1, xmm4
0x4162d5: movaps     xmm4, xmm0
0x4162d8: movups     xmmword ptr [rax - 0x30], xmm1
0x4162dc: movups     xmm1, xmmword ptr [rax - 0x20]
0x4162e0: movups     xmm5, xmmword ptr [rbx + 0x30]
0x4162e4: addps      xmm1, xmm5
0x4162e7: movaps     xmm3, xmm1
0x4162ea: cmpltps    xmm3, xmm2
0x4162ee: andnps     xmm3, xmm1
0x4162f1: movaps     xmm1, xmm0
0x4162f4: cmpltps    xmm1, xmm3
0x4162f8: andps      xmm4, xmm1
0x4162fb: andnps     xmm1, xmm3
0x4162fe: movups     xmm3, xmmword ptr [rax - 0x10]
0x416302: orps       xmm1, xmm4
0x416305: movups     xmmword ptr [rax - 0x20], xmm1
0x416309: movups     xmm6, xmmword ptr [rbx + 0x40]
0x41630d: addps      xmm3, xmm6
0x416310: movaps     xmm1, xmm3
0x416313: cmpltps    xmm1, xmm2
0x416317: movaps     xmm2, xmm1
0x41631a: movaps     xmm1, xmm0
0x41631d: andnps     xmm2, xmm3
0x416320: cmpltps    xmm1, xmm2
0x416324: andps      xmm0, xmm1
0x416327: andnps     xmm1, xmm2
0x41632a: orps       xmm1, xmm0
0x41632d: movups     xmmword ptr [rax - 0x10], xmm1
0x416331: cmp        esi, ecx
0x416333: jle        0x4163ca
0x416339: lea        rdx, [rdi + rax]
0x41633d: cmp        rdx, 8
0x416341: ja         0x416240
0x416347: movss      xmm3, dword ptr [rip + 0x4c3dd]
0x41634f: xor        edx, edx
0x416351: pxor       xmm2, xmm2
0x416355: nop        word ptr cs:[rax + rax]
0x41635f: nop        word ptr cs:[rax + rax]
0x41636a: nop        word ptr cs:[rax + rax]
0x416375: nop        word ptr cs:[rax + rax]
0x416380: movss      xmm1, dword ptr [rbx + rdx]
0x416385: addss      xmm1, dword ptr [rax + rdx]
0x41638a: movaps     xmm4, xmm3
0x41638d: movaps     xmm0, xmm1
0x416390: cmpnltss   xmm0, xmm2
0x416395: andps      xmm1, xmm0
0x416398: movaps     xmm0, xmm1
0x41639b: movaps     xmm1, xmm3
0x41639e: cmpltss    xmm1, xmm0
0x4163a3: andps      xmm4, xmm1
0x4163a6: andnps     xmm1, xmm0
0x4163a9: orps       xmm1, xmm4
0x4163ac: movss      dword ptr [rax + rdx], xmm1
0x4163b1: add        rdx, 4
0x4163b5: cmp        rdx, 0x50
0x4163b9: jne        0x416380
0x4163bb: add        ecx, 0x14
0x4163be: add        rax, 0x50
0x4163c2: cmp        esi, ecx
0x4163c4: jg         0x416339
0x4163ca: add        rsp, 0x18
0x4163ce: mov        rax, rbp
0x4163d1: pop        rbx
0x4163d2: pop        rbp
0x4163d3: pop        r12
0x4163d5: pop        r13
0x4163d7: pop        r14
0x4163d9: pop        r15
0x4163db: ret        

# coder @ 0x4163e0, size=235
0x4163e0: endbr64    
0x4163e4: push       r13
0x4163e6: push       r12
0x4163e8: push       rbp
0x4163e9: mov        rbp, rdi
0x4163ec: mov        edi, 0xffffffff
0x4163f1: push       rbx
0x4163f2: sub        rsp, 8
0x4163f6: call       0x439aa0
0x4163fb: mov        edi, 0x28
0x416400: mov        r12, rax
0x416403: call       0x4037e0
0x416408: mov        rdi, rax
0x41640b: mov        rbx, rax
0x41640e: call       0x431b60
0x416413: mov        rdi, rbx
0x416416: mov        esi, 0xffffffff
0x41641b: call       0x431930
0x416420: mov        rsi, r12
0x416423: mov        rdi, rbp
0x416426: call       0x416160
0x41642b: mov        rdi, rax
0x41642e: mov        r13, rax
0x416431: call       0x4077a0
0x416436: mov        rdi, r13
0x416439: mov        rbp, rax
0x41643c: call       0x403830
0x416441: mov        rsi, r12
0x416444: mov        rdi, rbp
0x416447: call       0x415d70
0x41644c: mov        rdi, rbp
0x41644f: mov        r12, rax
0x416452: call       0x403830
0x416457: mov        rdi, r12
0x41645a: call       0x407860
0x41645f: mov        rdi, r12
0x416462: mov        rbp, rax
0x416465: call       0x403830
0x41646a: mov        rsi, rbx
0x41646d: mov        rdi, rbp
0x416470: call       0x408120
0x416475: mov        rdi, rbp
0x416478: mov        r12, rax
0x41647b: call       0x403830
0x416480: mov        rsi, rbx
0x416483: mov        rdi, r12
0x416486: call       0x408050
0x41648b: mov        rdi, r12
0x41648e: mov        rbp, rax
0x416491: call       0x403830
0x416496: mov        rdi, rbx
0x416499: call       0x431ad0
0x41649e: mov        rdi, rbp
0x4164a1: call       0x407960
0x4164a6: mov        rdi, rbp
0x4164a9: mov        rbx, rax
0x4164ac: call       0x403830
0x4164b1: add        rsp, 8
0x4164b5: mov        rax, rbx
0x4164b8: pop        rbx
0x4164b9: pop        rbp
0x4164ba: pop        r12
0x4164bc: pop        r13
0x4164be: ret        
0x4164bf: endbr64    
0x4164c3: mov        rbp, rax
0x4164c6: jmp        0x403dd1

# tflite::optimized_ops::MaxPool(tflite::PoolParams const&, tflite::RuntimeShape const&, float const*, tflite::RuntimeShape const&, float*) @ 0x41c680, size=2953
0x41c680: endbr64    
0x41c684: push       r15
0x41c686: mov        rax, rsi
0x41c689: mov        rsi, rcx
0x41c68c: push       r14
0x41c68e: mov        r14, rdx
0x41c691: push       r13
0x41c693: mov        r13, r8
0x41c696: push       r12
0x41c698: push       rbp
0x41c699: push       rbx
0x41c69a: sub        rsp, 0x20
0x41c69e: mov        qword ptr [rsp - 0x48], rdi
0x41c6a3: mov        edi, dword ptr [rcx]
0x41c6a5: cmp        edi, 5
0x41c6a8: jle        0x41cf44
0x41c6ae: mov        r9, qword ptr [rcx + 8]
0x41c6b2: mov        ecx, dword ptr [rax]
0x41c6b4: mov        edx, dword ptr [r9]
0x41c6b7: cmp        ecx, 5
0x41c6ba: jg         0x41cf52
0x41c6c0: mov        r8d, dword ptr [rax + 8]
0x41c6c4: mov        r10d, dword ptr [rax + 0xc]
0x41c6c8: mov        ebp, dword ptr [rax + 0x10]
0x41c6cb: cmp        edx, r8d
0x41c6ce: cmovle     r8d, edx
0x41c6d2: mov        ebx, dword ptr [r9 + 4]
0x41c6d6: mov        dword ptr [rsp - 0x38], ebx
0x41c6da: mov        ebx, dword ptr [r9 + 8]
0x41c6de: mov        dword ptr [rsp - 0x34], ebx
0x41c6e2: mov        rbx, qword ptr [rsp - 0x48]
0x41c6e7: mov        edx, dword ptr [rbx + 0xc]
0x41c6ea: mov        ebx, dword ptr [rbx + 0x10]
0x41c6ed: mov        dword ptr [rsp - 0x40], edx
0x41c6f1: lea        edx, [rcx - 1]
0x41c6f4: mov        dword ptr [rsp - 0x3c], ebx
0x41c6f8: cmp        ecx, 5
0x41c6fb: jg         0x41d159
0x41c701: movsxd     rdx, edx
0x41c704: lea        r9d, [rdi - 1]
0x41c708: mov        r12d, dword ptr [rax + rdx*4 + 8]
0x41c70d: cmp        edi, 5
0x41c710: jle        0x41cfa9
0x41c716: mov        rcx, qword ptr [rsi + 8]
0x41c71a: movsxd     rax, r9d
0x41c71d: mov        r11d, dword ptr [rcx + rax*4]
0x41c721: xor        edx, edx
0x41c723: mov        eax, 1
0x41c728: cmp        r9d, edx
0x41c72b: je         0x41c731
0x41c72d: imul       eax, dword ptr [rcx + rdx*4]
0x41c731: add        rdx, 1
0x41c735: cmp        edi, edx
0x41c737: jg         0x41c728
0x41c739: cdqe       
0x41c73b: movsxd     r15, r11d
0x41c73e: mov        r11, r13
0x41c741: mov        qword ptr [rsp - 0x20], r13
0x41c746: imul       rax, r15
0x41c74a: mov        rdx, rax
0x41c74d: and        r11d, 3
0x41c751: jne        0x41d072
0x41c757: mov        rax, r13
0x41c75a: mov        r9, rdx
0x41c75d: shr        rax, 2
0x41c761: neg        rax
0x41c764: and        eax, 3
0x41c767: cmp        rax, rdx
0x41c76a: cmovg      rax, rdx
0x41c76e: sub        r9, rax
0x41c771: lea        rcx, [r9 + 3]
0x41c775: cmovns     rcx, r9
0x41c779: and        rcx, 0xfffffffffffffffc
0x41c77d: add        rcx, rax
0x41c780: test       rax, rax
0x41c783: jle        0x41c7b3
0x41c785: movss      xmm0, dword ptr [rip + 0x45f9b]
0x41c78d: xor        r9d, r9d
0x41c790: movss      dword ptr [r13], xmm0
0x41c796: cmp        rax, 1
0x41c79a: je         0x41c7b3
0x41c79c: add        r9, 2
0x41c7a0: movss      dword ptr [r13 + r11 + 4], xmm0
0x41c7a7: cmp        r9, rax
0x41c7aa: jge        0x41c7b3
0x41c7ac: movss      dword ptr [r13 + r11 + 8], xmm0
0x41c7b3: cmp        rcx, rax
0x41c7b6: jle        0x41c80a
0x41c7b8: mov        r9, rax
0x41c7bb: movss      xmm0, dword ptr [rip + 0x45f65]
0x41c7c3: not        r9
0x41c7c6: add        r9, rcx
0x41c7c9: shufps     xmm0, xmm0, 0
0x41c7cd: movaps     xmmword ptr [r13 + rax*4], xmm0
0x41c7d3: add        rax, 4
0x41c7d7: shr        r9, 2
0x41c7db: cmp        rcx, rax
0x41c7de: jle        0x41c80a
0x41c7e0: and        r9d, 1
0x41c7e4: je         0x41c7f5
0x41c7e6: movaps     xmmword ptr [r13 + rax*4], xmm0
0x41c7ec: add        rax, 4
0x41c7f0: cmp        rcx, rax
0x41c7f3: jle        0x41c80a
0x41c7f5: movaps     xmmword ptr [r13 + rax*4], xmm0
0x41c7fb: movaps     xmmword ptr [r13 + rax*4 + 0x10], xmm0
0x41c801: add        rax, 8
0x41c805: cmp        rcx, rax
0x41c808: jg         0x41c7f5
0x41c80a: cmp        rdx, rcx
0x41c80d: jle        0x41c8a4
0x41c813: mov        r11, rdx
0x41c816: sub        r11, rcx
0x41c819: lea        rax, [r11 - 1]
0x41c81d: cmp        rax, 2
0x41c821: jbe        0x41c875
0x41c823: mov        r9, r11
0x41c826: movss      xmm0, dword ptr [rip + 0x45efa]
0x41c82e: lea        rax, [r13 + rcx*4]
0x41c833: shr        r9, 2
0x41c837: shl        r9, 4
0x41c83b: shufps     xmm0, xmm0, 0
0x41c83f: lea        rbx, [r9 + rax]
0x41c843: and        r9d, 0x10
0x41c847: je         0x41c855
0x41c849: movups     xmmword ptr [rax], xmm0
0x41c84c: add        rax, 0x10
0x41c850: cmp        rbx, rax
0x41c853: je         0x41c865
0x41c855: movups     xmmword ptr [rax], xmm0
0x41c858: add        rax, 0x20
0x41c85c: movups     xmmword ptr [rax - 0x10], xmm0
0x41c860: cmp        rbx, rax
0x41c863: jne        0x41c855
0x41c865: test       r11b, 3
0x41c869: je         0x41c8a4
0x41c86b: mov        rax, r11
0x41c86e: and        rax, 0xfffffffffffffffc
0x41c872: add        rcx, rax
0x41c875: movss      xmm0, dword ptr [rip + 0x45eab]
0x41c87d: lea        rax, [rcx + 1]
0x41c881: movss      dword ptr [r13 + rcx*4], xmm0
0x41c888: cmp        rdx, rax
0x41c88b: jle        0x41c8a4
0x41c88d: lea        rax, [rcx + 2]
0x41c891: movss      dword ptr [r13 + rcx*4 + 4], xmm0
0x41c898: cmp        rdx, rax
0x41c89b: jle        0x41c8a4
0x41c89d: movss      dword ptr [r13 + rcx*4 + 8], xmm0
0x41c8a4: test       r8d, r8d
0x41c8a7: jle        0x41cd1c
0x41c8ad: test       r10d, r10d
0x41c8b0: jle        0x41cd1c
0x41c8b6: test       ebp, ebp
0x41c8b8: jle        0x41cd1c
0x41c8be: movsxd     rdx, r12d
0x41c8c1: movsxd     rax, dword ptr [rsp - 0x34]
0x41c8c6: mov        ecx, r10d
0x41c8c9: mov        qword ptr [rsp - 8], rsi
0x41c8ce: mov        qword ptr [rsp - 0x18], rdx
0x41c8d3: mov        rdx, r13
0x41c8d6: imul       ecx, ebp
0x41c8d9: xor        ebx, ebx
0x41c8db: imul       rax, r15
0x41c8df: sub        rdx, r14
0x41c8e2: xor        edi, edi
0x41c8e4: mov        r12d, ebp
0x41c8e7: mov        dword ptr [rsp - 0x30], 0
0x41c8ef: mov        qword ptr [rsp - 0x10], rdx
0x41c8f4: mov        esi, ecx
0x41c8f6: mov        rcx, rax
0x41c8f9: mov        dword ptr [rsp - 0x2c], ebx
0x41c8fd: xor        ebp, ebp
0x41c8ff: mov        dword ptr [rsp], edi
0x41c902: mov        r9d, ebp
0x41c905: mov        dword ptr [rsp + 4], ebx
0x41c909: mov        dword ptr [rsp + 8], esi
0x41c90d: mov        dword ptr [rsp - 0x28], r10d
0x41c912: xor        ebx, ebx
0x41c914: mov        dword ptr [rsp - 0x24], r8d
# ... excerpt ends ...
