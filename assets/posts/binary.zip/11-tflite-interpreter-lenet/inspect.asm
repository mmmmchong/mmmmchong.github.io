# Symbols and machine instructions from this delivered ELF.
# Each function excerpt is limited to its first 180 instructions.

# main @ 0x4158e0, size=958
0x4158e0: endbr64    
0x4158e4: push       r15
0x4158e6: push       r14
0x4158e8: mov        r14, rsi
0x4158eb: push       r13
0x4158ed: push       r12
0x4158ef: push       rbp
0x4158f0: push       rbx
0x4158f1: sub        rsp, 0x198
0x4158f8: mov        rax, qword ptr fs:[0x28]
0x415901: mov        qword ptr [rsp + 0x188], rax
0x415909: xor        eax, eax
0x41590b: cmp        edi, 3
0x41590e: jne        0x415ae1
0x415914: mov        ebp, edi
0x415916: mov        edi, 0x6000
0x41591b: call       0x405540
0x415920: xor        esi, esi
0x415922: mov        edx, 0x5ffc
0x415927: mov        dword ptr [rax], 0
0x41592d: lea        rdi, [rax + 4]
0x415931: mov        r12, rax
0x415934: call       0x4052a0
0x415939: mov        rdi, qword ptr [r14 + 8]
0x41593d: mov        esi, 0x82e328
0x415942: call       0x4055e0
0x415947: mov        rbx, rax
0x41594a: test       rax, rax
0x41594d: je         0x405b40
0x415953: mov        rcx, rax
0x415956: mov        edx, 0x1800
0x41595b: mov        esi, 4
0x415960: mov        rdi, r12
0x415963: call       0x4057c0
0x415968: xor        r13d, r13d
0x41596b: cmp        rax, 0x1800
0x415971: je         0x415c51
0x415977: mov        rdi, rbx
0x41597a: call       0x405530
0x41597f: test       r13b, r13b
0x415982: je         0x415a7a
0x415988: call       0x4fe550
0x41598d: mov        edx, 0xe68da0
0x415992: mov        rcx, rax
0x415995: mov        esi, 0x831730
0x41599a: mov        rdi, rsp
0x41599d: sub        rdx, 0x831730
0x4159a4: call       0x4f5380
0x4159a9: cmp        qword ptr [rsp], 0
0x4159ae: je         0x415a70
0x4159b4: lea        rdi, [rsp + 0x10]
0x4159b9: call       0x416870
0x4159be: mov        rax, qword ptr [rsp + 0x20]
0x4159c3: mov        r13, qword ptr [rsp + 0x28]
0x4159c8: mov        qword ptr [rsp + 0x10], 0x8316f0
0x4159d1: mov        r15, rax
0x4159d4: cmp        rax, r13
0x4159d7: je         0x415a08
0x4159d9: mov        rbx, rax
0x4159dc: nop        dword ptr [rax]
0x4159e0: mov        rax, qword ptr [rbx + 0x10]
0x4159e4: test       rax, rax
0x4159e7: je         0x415acf
0x4159ed: mov        rsi, rbx
0x4159f0: mov        rdi, rbx
0x4159f3: add        rbx, 0x20
0x4159f7: mov        edx, 3
0x4159fc: call       rax
0x4159fe: cmp        r13, rbx
0x415a01: jne        0x4159e0
0x415a03: mov        qword ptr [rsp + 0x28], r15
0x415a08: mov        rsi, qword ptr [rsp]
0x415a0c: xor        eax, eax
0x415a0e: xor        ecx, ecx
0x415a10: lea        rdx, [rsp + 0x10]
0x415a15: lea        rdi, [rsp + 0xc0]
0x415a1d: mov        qword ptr [rsp + 8], rax
0x415a22: lea        rbx, [rsp + 8]
0x415a27: call       0x4f07d0
0x415a2c: mov        rsi, rbx
0x415a2f: lea        rdi, [rsp + 0xc0]
0x415a37: call       0x4f2d20
0x415a3c: mov        r13d, eax
0x415a3f: lea        rdi, [rsp + 0xc0]
0x415a47: call       0x4f09a0
0x415a4c: test       r13d, r13d
0x415a4f: je         0x415b01
0x415a55: mov        rdi, rbx
0x415a58: call       0x416790
0x415a5d: lea        rdi, [rsp + 0x10]
0x415a62: mov        qword ptr [rsp + 0x10], 0x8316a8
0x415a6b: call       0x416490
0x415a70: mov        rdi, rsp
0x415a73: call       0x416750
0x415a78: jmp        0x415a97
0x415a7a: mov        rdi, qword ptr [rip + 0xa9df3f]
0x415a81: mov        edx, 0x82e32b
0x415a86: mov        esi, 2
0x415a8b: xor        eax, eax
0x415a8d: call       0x4058a0
0x415a92: mov        ebp, 2
0x415a97: mov        esi, 0x6000
0x415a9c: mov        rdi, r12
0x415a9f: call       0x405550
0x415aa4: mov        rax, qword ptr [rsp + 0x188]
0x415aac: sub        rax, qword ptr fs:[0x28]
0x415ab5: jne        0x415c6f
0x415abb: add        rsp, 0x198
0x415ac2: mov        eax, ebp
0x415ac4: pop        rbx
0x415ac5: pop        rbp
0x415ac6: pop        r12
0x415ac8: pop        r13
0x415aca: pop        r14
0x415acc: pop        r15
0x415ace: ret        
0x415acf: add        rbx, 0x20
0x415ad3: cmp        r13, rbx
0x415ad6: jne        0x4159e0
0x415adc: jmp        0x415a03
0x415ae1: mov        rcx, qword ptr [rsi]
0x415ae4: mov        edx, 0x821150
0x415ae9: mov        esi, 2
0x415aee: mov        rdi, qword ptr [rip + 0xa9decb]
0x415af5: mov        ebp, 2
0x415afa: call       0x4058a0
0x415aff: jmp        0x415aa4
0x415b01: mov        rdi, qword ptr [rsp + 8]
0x415b06: mov        esi, 1
0x415b0b: call       0x4eded0
0x415b10: mov        rdi, qword ptr [rsp + 8]
0x415b15: call       0x4eea30
0x415b1a: test       eax, eax
0x415b1c: jne        0x415a55
0x415b22: mov        rax, qword ptr [rsp + 8]
0x415b27: mov        rax, qword ptr [rax + 0x68]
0x415b2b: mov        rdx, qword ptr [rax]
0x415b2e: mov        rax, qword ptr [rdx + 0x108]
0x415b35: movsxd     rax, dword ptr [rax]
0x415b38: test       eax, eax
0x415b3a: js         0x415c65
0x415b40: cmp        rax, qword ptr [rdx + 0x28]
0x415b44: jae        0x415c65
0x415b4a: imul       rax, rax, 0x70
0x415b4e: add        rax, qword ptr [rdx + 0x38]
0x415b52: cmp        qword ptr [rax + 0x28], 0x6000
0x415b5a: jne        0x415a55
0x415b60: xor        edi, edi
0x415b62: cmp        dword ptr [rax], 1
0x415b65: jne        0x415b6b
0x415b67: mov        rdi, qword ptr [rax + 8]
0x415b6b: mov        edx, 0x6000
0x415b70: mov        rsi, r12
0x415b73: call       0x405420
0x415b78: mov        rdi, qword ptr [rsp + 8]
0x415b7d: call       0x4ed5e0
0x415b82: test       eax, eax
0x415b84: jne        0x415a55
0x415b8a: mov        rax, qword ptr [rsp + 8]
0x415b8f: mov        rax, qword ptr [rax + 0x68]
0x415b93: mov        rdx, qword ptr [rax]
0x415b96: mov        rax, qword ptr [rdx + 0x120]
0x415b9d: movsxd     rax, dword ptr [rax]
0x415ba0: test       eax, eax
0x415ba2: js         0x415c65
0x415ba8: cmp        rax, qword ptr [rdx + 0x28]
0x415bac: jae        0x415c65
0x415bb2: imul       rax, rax, 0x70
0x415bb6: add        rax, qword ptr [rdx + 0x38]
0x415bba: je         0x415a55
0x415bc0: cmp        dword ptr [rax], 1
0x415bc3: jne        0x415a55
0x415bc9: mov        rcx, qword ptr [rax + 8]
0x415bcd: mov        r15, rcx
0x415bd0: test       rcx, rcx
0x415bd3: je         0x415a55
0x415bd9: mov        rdi, qword ptr [r14 + 0x10]
0x415bdd: mov        esi, 0x82e349
0x415be2: mov        r13, qword ptr [rax + 0x28]
0x415be6: call       0x4055e0
# ... excerpt ends ...

# tflite::Interpreter::Invoke() @ 0x4ed5e0, size=1729
0x4ed5e0: endbr64    
0x4ed5e4: push       r14
0x4ed5e6: push       r13
0x4ed5e8: push       r12
0x4ed5ea: push       rbp
0x4ed5eb: push       rbx
0x4ed5ec: sub        rsp, 0x60
0x4ed5f0: mov        rbx, qword ptr [rdi + 0x30]
0x4ed5f4: mov        r14, qword ptr fs:[0x28]
0x4ed5fd: mov        qword ptr [rsp + 0x58], r14
0x4ed602: mov        r14, rdi
0x4ed605: mov        qword ptr [rsp + 0x30], rbx
0x4ed60a: test       rbx, rbx
0x4ed60d: je         0x4ed9d0
0x4ed613: mov        rax, qword ptr [rbx]
0x4ed616: mov        r9, qword ptr [rax + 0x10]
0x4ed61a: mov        rax, 0x4eebd0
0x4ed621: cmp        r9, rax
0x4ed624: jne        0x4edae0
0x4ed62a: mov        rdi, qword ptr [rbx + 8]
0x4ed62e: test       rdi, rdi
0x4ed631: je         0x4ed730
0x4ed637: mov        rdx, qword ptr [rdi]
0x4ed63a: mov        r9, qword ptr [rdx + 0x10]
0x4ed63e: cmp        r9, rax
0x4ed641: jne        0x4edbe0
0x4ed647: mov        r9, qword ptr [rdi + 8]
0x4ed64b: test       r9, r9
0x4ed64e: je         0x4ed730
0x4ed654: mov        rdx, qword ptr [r9]
0x4ed657: mov        r10, qword ptr [rdx + 0x10]
0x4ed65b: cmp        r10, rax
0x4ed65e: jne        0x4eda90
0x4ed664: mov        rdi, qword ptr [r9 + 8]
0x4ed668: test       rdi, rdi
0x4ed66b: je         0x4ed730
0x4ed671: mov        rdx, qword ptr [rdi]
0x4ed674: mov        r10, qword ptr [rdx + 0x10]
0x4ed678: cmp        r10, rax
0x4ed67b: jne        0x4edc18
0x4ed681: mov        r9, qword ptr [rdi + 8]
0x4ed685: test       r9, r9
0x4ed688: je         0x4ed730
0x4ed68e: mov        rdx, qword ptr [r9]
0x4ed691: mov        r10, qword ptr [rdx + 0x10]
0x4ed695: cmp        r10, rax
0x4ed698: jne        0x4eda90
0x4ed69e: mov        rdi, qword ptr [r9 + 8]
0x4ed6a2: test       rdi, rdi
0x4ed6a5: je         0x4ed730
0x4ed6ab: mov        rdx, qword ptr [rdi]
0x4ed6ae: mov        r10, qword ptr [rdx + 0x10]
0x4ed6b2: cmp        r10, rax
0x4ed6b5: jne        0x4edc18
0x4ed6bb: mov        r9, qword ptr [rdi + 8]
0x4ed6bf: test       r9, r9
0x4ed6c2: je         0x4ed730
0x4ed6c4: mov        rdx, qword ptr [r9]
0x4ed6c7: mov        r10, qword ptr [rdx + 0x10]
0x4ed6cb: cmp        r10, rax
0x4ed6ce: jne        0x4eda90
0x4ed6d4: mov        rdi, qword ptr [r9 + 8]
0x4ed6d8: test       rdi, rdi
0x4ed6db: je         0x4ed730
0x4ed6dd: mov        rdx, qword ptr [rdi]
0x4ed6e0: mov        r10, qword ptr [rdx + 0x10]
0x4ed6e4: cmp        r10, rax
0x4ed6e7: jne        0x4edc18
0x4ed6ed: mov        r9, qword ptr [rdi + 8]
0x4ed6f1: test       r9, r9
0x4ed6f4: je         0x4ed730
0x4ed6f6: mov        rdx, qword ptr [r9]
0x4ed6f9: mov        r8, qword ptr [rdi + 0x10]
0x4ed6fd: mov        rcx, 0xffffffffffffffff
0x4ed704: lea        rsi, [rip + 0x342496]
0x4ed70b: mov        rdi, r9
0x4ed70e: mov        r10, qword ptr [rdx + 0x10]
0x4ed712: mov        edx, 8
0x4ed717: cmp        r10, rax
0x4ed71a: jne        0x4edaaa
0x4ed720: call       0x4eebd0
0x4ed725: mov        r13d, eax
0x4ed728: jmp        0x4ed733
0x4ed72a: nop        word ptr [rax + rax]
0x4ed730: xor        r13d, r13d
0x4ed733: lea        r12, [rsp + 0x2c]
0x4ed738: mov        rdi, r12
0x4ed73b: call       0x818750
0x4ed740: mov        rax, qword ptr [r14 + 0x68]
0x4ed744: mov        rdi, qword ptr [rax]
0x4ed747: call       0x507630
0x4ed74c: mov        ebp, eax
0x4ed74e: test       eax, eax
0x4ed750: jne        0x4eda20
0x4ed756: cmp        byte ptr [r14 + 0x38], 0
0x4ed75b: jne        0x4ed9a8
0x4ed761: mov        rax, qword ptr [r14 + 0x68]
0x4ed765: mov        r9, qword ptr [rax]
0x4ed768: mov        r10, qword ptr [r9 + 0x128]
0x4ed76f: mov        r8, qword ptr [r9 + 0x120]
0x4ed776: cmp        r8, r10
0x4ed779: jne        0x4ed7f0
0x4ed77b: jmp        0x4edc54
0x4ed780: cmp        byte ptr [rax + 0x4c], 0
0x4ed784: je         0x4ed7dc
0x4ed786: mov        rsi, qword ptr [rax + 0x40]
0x4ed78a: test       rsi, rsi
0x4ed78d: je         0x4eda30
0x4ed793: mov        edx, dword ptr [rax + 0x48]
0x4ed796: cmp        edx, -1
0x4ed799: je         0x4eda60
0x4ed79f: mov        rax, qword ptr [rsi + 0x10]
0x4ed7a3: test       rax, rax
0x4ed7a6: je         0x4edb08
0x4ed7ac: mov        qword ptr [rsp + 0x18], r10
0x4ed7b1: lea        rdi, [r9 + 0x28]
0x4ed7b5: mov        qword ptr [rsp + 0x10], r8
0x4ed7ba: mov        qword ptr [rsp + 8], rcx
0x4ed7bf: call       rax
0x4ed7c1: test       eax, eax
0x4ed7c3: jne        0x4edab8
0x4ed7c9: mov        rcx, qword ptr [rsp + 8]
0x4ed7ce: mov        r8, qword ptr [rsp + 0x10]
0x4ed7d3: mov        r10, qword ptr [rsp + 0x18]
0x4ed7d8: mov        byte ptr [rcx + 0x4c], 0
0x4ed7dc: add        r8, 4
0x4ed7e0: cmp        r10, r8
0x4ed7e3: je         0x4ed9a8
0x4ed7e9: mov        rax, qword ptr [r14 + 0x68]
0x4ed7ed: mov        r9, qword ptr [rax]
0x4ed7f0: movsxd     rax, dword ptr [r8]
0x4ed7f3: imul       rax, rax, 0x70
0x4ed7f7: add        rax, qword ptr [r9 + 8]
0x4ed7fb: mov        rcx, rax
0x4ed7fe: jne        0x4ed780
0x4ed800: lea        rdi, [r9 + 0x28]
0x4ed804: lea        r8, [rip + 0x341b98]
0x4ed80b: xor        eax, eax
0x4ed80d: mov        ecx, 0x11a
0x4ed812: lea        rdx, [rip + 0x337247]
0x4ed819: lea        rsi, [rip + 0x340c07]
0x4ed820: call       qword ptr [r9 + 0x50]
0x4ed824: mov        rdi, r12
0x4ed827: test       rbx, rbx
0x4ed82a: je         0x4ed9c0
0x4ed830: call       0x818780
0x4ed835: mov        r14d, 1
0x4ed83b: mov        ebp, 1
0x4ed840: mov        rax, qword ptr [rbx]
0x4ed843: xor        edx, edx
0x4ed845: mov        rcx, r14
0x4ed848: mov        esi, r13d
0x4ed84b: mov        rdi, rbx
0x4ed84e: call       qword ptr [rax + 0x18]
0x4ed851: mov        rax, qword ptr [rbx]
0x4ed854: mov        rdx, qword ptr [rax + 0x20]
0x4ed858: mov        rax, 0x4eeb30
0x4ed85f: cmp        rdx, rax
0x4ed862: jne        0x4edad0
0x4ed868: mov        rdi, qword ptr [rbx + 8]
0x4ed86c: test       rdi, rdi
0x4ed86f: je         0x4ed980
0x4ed875: mov        rdx, qword ptr [rdi]
0x4ed878: mov        rdx, qword ptr [rdx + 0x20]
0x4ed87c: cmp        rdx, rax
0x4ed87f: jne        0x4eda10
0x4ed885: mov        rdi, qword ptr [rdi + 8]
0x4ed889: test       rdi, rdi
0x4ed88c: je         0x4ed980
0x4ed892: mov        rdx, qword ptr [rdi]
0x4ed895: mov        rdx, qword ptr [rdx + 0x20]
0x4ed899: cmp        rdx, rax
0x4ed89c: jne        0x4eda10
0x4ed8a2: mov        rdi, qword ptr [rdi + 8]
0x4ed8a6: test       rdi, rdi
0x4ed8a9: je         0x4ed980
0x4ed8af: mov        rdx, qword ptr [rdi]
0x4ed8b2: mov        rdx, qword ptr [rdx + 0x20]
0x4ed8b6: cmp        rdx, rax
0x4ed8b9: jne        0x4eda10
# ... excerpt ends ...

# tflite::InterpreterBuilder::operator()(std::unique_ptr<tflite::Interpreter, std::default_delete<tflite::Interpreter> >*) @ 0x4f2d20, size=2439
0x4f2d20: endbr64    
0x4f2d24: push       r15
0x4f2d26: mov        r8, rdi
0x4f2d29: push       r14
0x4f2d2b: push       r13
0x4f2d2d: push       r12
0x4f2d2f: push       rbp
0x4f2d30: push       rbx
0x4f2d31: sub        rsp, 0x78
0x4f2d35: mov        rax, qword ptr fs:[0x28]
0x4f2d3e: mov        qword ptr [rsp + 0x68], rax
0x4f2d43: xor        eax, eax
0x4f2d45: test       rsi, rsi
0x4f2d48: je         0x4f2e20
0x4f2d4e: mov        rax, qword ptr [rdi]
0x4f2d51: mov        rbx, rsi
0x4f2d54: test       rax, rax
0x4f2d57: je         0x4f2df8
0x4f2d5d: movsxd     rcx, dword ptr [rax]
0x4f2d60: mov        rdx, rax
0x4f2d63: sub        rdx, rcx
0x4f2d66: cmp        word ptr [rdx], 4
0x4f2d6a: ja         0x4f2dd8
0x4f2d6c: mov        rdi, qword ptr [r8 + 0x10]
0x4f2d70: xor        edx, edx
0x4f2d72: mov        ecx, 3
0x4f2d77: lea        rsi, [rip + 0x3324a2]
0x4f2d7e: xor        eax, eax
0x4f2d80: call       0x4ff5e0
0x4f2d85: mov        rdi, qword ptr [rbx]
0x4f2d88: mov        qword ptr [rbx], 0
0x4f2d8f: test       rdi, rdi
0x4f2d92: je         0x4f2dad
0x4f2d94: mov        qword ptr [rsp + 8], rdi
0x4f2d99: call       0x4ecaf0
0x4f2d9e: mov        rdi, qword ptr [rsp + 8]
0x4f2da3: mov        esi, 0x1b0
0x4f2da8: call       0x405550
0x4f2dad: mov        eax, 1
0x4f2db2: mov        rdx, qword ptr [rsp + 0x68]
0x4f2db7: sub        rdx, qword ptr fs:[0x28]
0x4f2dc0: jne        0x4f3651
0x4f2dc6: add        rsp, 0x78
0x4f2dca: pop        rbx
0x4f2dcb: pop        rbp
0x4f2dcc: pop        r12
0x4f2dce: pop        r13
0x4f2dd0: pop        r14
0x4f2dd2: pop        r15
0x4f2dd4: ret        
0x4f2dd5: nop        dword ptr [rax]
0x4f2dd8: movzx      edx, word ptr [rdx + 4]
0x4f2ddc: test       dx, dx
0x4f2ddf: je         0x4f2d6c
0x4f2de1: mov        edx, dword ptr [rax + rdx]
0x4f2de4: cmp        edx, 3
0x4f2de7: je         0x4f2e38
0x4f2de9: mov        rdi, qword ptr [rdi + 0x10]
0x4f2ded: jmp        0x4f2d72
0x4f2df2: nop        word ptr [rax + rax]
0x4f2df8: mov        rdi, qword ptr [rdi + 0x10]
0x4f2dfc: lea        rsi, [rip + 0x3323f5]
0x4f2e03: call       0x4ff5e0
0x4f2e08: mov        rdi, qword ptr [rbx]
0x4f2e0b: mov        qword ptr [rbx], 0
0x4f2e12: test       rdi, rdi
0x4f2e15: jne        0x4f2d94
0x4f2e1b: jmp        0x4f2dad
0x4f2e1d: nop        dword ptr [rax]
0x4f2e20: mov        rdi, qword ptr [rdi + 0x10]
0x4f2e24: lea        rsi, [rip + 0x332395]
0x4f2e2b: call       0x4ff5e0
0x4f2e30: jmp        0x4f2dad
0x4f2e35: nop        dword ptr [rax]
0x4f2e38: mov        qword ptr [rsp + 8], rdi
0x4f2e3d: call       0x4f0a80
0x4f2e42: mov        r8, qword ptr [rsp + 8]
0x4f2e47: test       eax, eax
0x4f2e49: jne        0x4f3468
0x4f2e4f: mov        rax, qword ptr [r8]
0x4f2e52: movsxd     rdx, dword ptr [rax]
0x4f2e55: mov        rcx, rax
0x4f2e58: sub        rcx, rdx
0x4f2e5b: movzx      esi, word ptr [rcx]
0x4f2e5e: cmp        si, 8
0x4f2e62: jbe        0x40bb69
0x4f2e68: movzx      edx, word ptr [rcx + 8]
0x4f2e6c: xor        ebp, ebp
0x4f2e6e: test       dx, dx
0x4f2e71: je         0x4f2e7c
0x4f2e73: add        rdx, rax
0x4f2e76: mov        edi, dword ptr [rdx]
0x4f2e78: lea        rbp, [rdx + rdi]
0x4f2e7c: mov        edi, dword ptr [rbp]
0x4f2e7f: cmp        si, 0xc
0x4f2e83: jbe        0x4f360f
0x4f2e89: movzx      edx, word ptr [rcx + 0xc]
0x4f2e8d: test       dx, dx
0x4f2e90: je         0x4f360f
0x4f2e96: test       edi, edi
0x4f2e98: je         0x4f34c0
0x4f2e9e: mov        edi, 0x1b0
0x4f2ea3: mov        qword ptr [rsp + 8], r8
0x4f2ea8: mov        r12d, dword ptr [rax + rdx]
0x4f2eac: lea        r13, [rax + rdx]
0x4f2eb0: call       0x405540
0x4f2eb5: mov        r8, qword ptr [rsp + 8]
0x4f2eba: mov        rdi, rax
0x4f2ebd: mov        r14, rax
0x4f2ec0: mov        r15, rax
0x4f2ec3: mov        rsi, qword ptr [r8 + 0x10]
0x4f2ec7: call       0x4ee500
0x4f2ecc: mov        rdi, qword ptr [rbx]
0x4f2ecf: mov        r8, qword ptr [rsp + 8]
0x4f2ed4: mov        qword ptr [rbx], r14
0x4f2ed7: test       rdi, rdi
0x4f2eda: je         0x4f2f02
0x4f2edc: mov        qword ptr [rsp + 0x10], r8
0x4f2ee1: mov        qword ptr [rsp + 8], rdi
0x4f2ee6: call       0x4ecaf0
0x4f2eeb: mov        rdi, qword ptr [rsp + 8]
0x4f2ef0: mov        esi, 0x1b0
0x4f2ef5: call       0x405550
0x4f2efa: mov        r15, qword ptr [rbx]
0x4f2efd: mov        r8, qword ptr [rsp + 0x10]
0x4f2f02: mov        eax, dword ptr [rbp]
0x4f2f05: cmp        eax, 1
0x4f2f08: jbe        0x4f2f24
0x4f2f0a: mov        rdi, r15
0x4f2f0d: lea        esi, [rax - 1]
0x4f2f10: xor        edx, edx
0x4f2f12: mov        qword ptr [rsp + 8], r8
0x4f2f17: call       0x4ed2c0
0x4f2f1c: mov        r15, qword ptr [rbx]
0x4f2f1f: mov        r8, qword ptr [rsp + 8]
0x4f2f24: mov        esi, dword ptr [r8 + 0xb8]
0x4f2f2b: mov        rdi, r15
0x4f2f2e: mov        qword ptr [rsp + 8], r8
0x4f2f33: lea        r14, [rsp + 0x50]
0x4f2f38: call       0x4eded0
0x4f2f3d: mov        r8, qword ptr [rsp + 8]
0x4f2f42: mov        rdi, qword ptr [rbx]
0x4f2f45: lea        rsi, [r8 + 0xbc]
0x4f2f4c: mov        qword ptr [rsp + 0x10], r8
0x4f2f51: call       0x4ee430
0x4f2f56: mov        r15, qword ptr [rbx]
0x4f2f59: mov        rdi, r14
0x4f2f5c: mov        qword ptr [rsp + 8], r14
0x4f2f61: call       0x4ff540
0x4f2f66: mov        rsi, r14
0x4f2f69: mov        rdi, r15
0x4f2f6c: call       0x4ee3c0
0x4f2f71: mov        rdi, qword ptr [rsp + 0x50]
0x4f2f76: mov        r8, qword ptr [rsp + 0x10]
0x4f2f7b: test       rdi, rdi
0x4f2f7e: je         0x4f2fa3
0x4f2f80: mov        rax, qword ptr [rdi]
0x4f2f83: mov        rax, qword ptr [rax + 8]
0x4f2f87: cmp        rax, 0x4eead0
0x4f2f8e: jne        0x4f3631
0x4f2f94: mov        esi, 0x18
0x4f2f99: call       0x405550
0x4f2f9e: mov        r8, qword ptr [rsp + 0x10]
0x4f2fa3: mov        esi, dword ptr [rbp]
0x4f2fa6: test       esi, esi
0x4f2fa8: je         0x4f32be
0x4f2fae: mov        eax, r12d
0x4f2fb1: xor        r12d, r12d
0x4f2fb4: lea        rcx, [r13 + rax]
0x4f2fb9: lea        r13, [rbp + 4]
0x4f2fbd: mov        qword ptr [rsp + 0x18], rcx
0x4f2fc2: mov        eax, dword ptr [r13]
0x4f2fc6: lea        r14, [r13 + rax]
0x4f2fcb: mov        rax, qword ptr [rbx]
0x4f2fce: mov        rdx, qword ptr [rax + 0x68]
0x4f2fd2: mov        rax, qword ptr [rax + 0x70]
0x4f2fd6: sub        rax, rdx
0x4f2fd9: sar        rax, 3
0x4f2fdd: cmp        r12, rax
0x4f2fe0: jae        0x4f3629
# ... excerpt ends ...

# tflite::InterpreterBuilder::operator()(std::unique_ptr<tflite::Interpreter, std::default_delete<tflite::Interpreter> >*, int) @ 0x4f36b0, size=101
0x4f36b0: endbr64    
0x4f36b4: push       rbp
0x4f36b5: mov        rbp, rsi
0x4f36b8: mov        esi, edx
0x4f36ba: push       rbx
0x4f36bb: mov        rbx, rdi
0x4f36be: sub        rsp, 0x18
0x4f36c2: call       0x4f23c0
0x4f36c7: test       eax, eax
0x4f36c9: jne        0x4f36e0
0x4f36cb: add        rsp, 0x18
0x4f36cf: mov        rsi, rbp
0x4f36d2: mov        rdi, rbx
0x4f36d5: pop        rbx
0x4f36d6: pop        rbp
0x4f36d7: jmp        0x4f2d20
0x4f36dc: nop        dword ptr [rax]
0x4f36e0: mov        rbx, qword ptr [rbp]
0x4f36e4: mov        qword ptr [rbp], 0
0x4f36ec: test       rbx, rbx
0x4f36ef: je         0x4f370e
0x4f36f1: mov        rdi, rbx
0x4f36f4: mov        dword ptr [rsp + 0xc], eax
0x4f36f8: call       0x4ecaf0
0x4f36fd: mov        esi, 0x1b0
0x4f3702: mov        rdi, rbx
0x4f3705: call       0x405550
0x4f370a: mov        eax, dword ptr [rsp + 0xc]
0x4f370e: add        rsp, 0x18
0x4f3712: pop        rbx
0x4f3713: pop        rbp
0x4f3714: ret        

# tflite::Subgraph::Invoke() @ 0x507630, size=2823
0x507630: endbr64    
0x507634: push       r15
0x507636: push       r14
0x507638: push       r13
0x50763a: push       r12
0x50763c: push       rbp
0x50763d: push       rbx
0x50763e: mov        rbx, rdi
0x507641: sub        rsp, 0x38
0x507645: cmp        byte ptr [rdi + 0x100], 0
0x50764c: je         0x5078d8
0x507652: call       0x5075b0
0x507657: mov        eax, dword ptr [rbx + 0x20]
0x50765a: test       eax, eax
0x50765c: je         0x507bf8
0x507662: mov        rdi, qword ptr [rbx + 0x1d8]
0x507669: test       rdi, rdi
0x50766c: je         0x50767c
0x50766e: mov        rax, qword ptr [rdi]
0x507671: call       qword ptr [rax + 0x40]
0x507674: test       al, al
0x507676: je         0x507dc0
0x50767c: mov        r12, qword ptr [rbx + 0x218]
0x507683: mov        dword ptr [rsp + 0xc], 0
0x50768b: test       r12, r12
0x50768e: je         0x507780
0x507694: mov        rax, qword ptr [r12]
0x507698: mov        r9, qword ptr [rax + 0x10]
0x50769c: mov        rax, 0x4eebd0
0x5076a3: cmp        r9, rax
0x5076a6: jne        0x507e20
0x5076ac: mov        rdi, qword ptr [r12 + 8]
0x5076b1: test       rdi, rdi
0x5076b4: je         0x507780
0x5076ba: mov        rdx, qword ptr [rdi]
0x5076bd: mov        r9, qword ptr [rdx + 0x10]
0x5076c1: cmp        r9, rax
0x5076c4: jne        0x507ea0
0x5076ca: mov        r9, qword ptr [rdi + 8]
0x5076ce: test       r9, r9
0x5076d1: je         0x507780
0x5076d7: mov        rdx, qword ptr [r9]
0x5076da: mov        r10, qword ptr [rdx + 0x10]
0x5076de: cmp        r10, rax
0x5076e1: jne        0x507f10
0x5076e7: mov        rdi, qword ptr [r9 + 8]
0x5076eb: test       rdi, rdi
0x5076ee: je         0x507780
0x5076f4: mov        rdx, qword ptr [rdi]
0x5076f7: mov        r10, qword ptr [rdx + 0x10]
0x5076fb: cmp        r10, rax
0x5076fe: jne        0x507f72
0x507704: mov        r9, qword ptr [rdi + 8]
0x507708: test       r9, r9
0x50770b: je         0x507780
0x50770d: mov        rdx, qword ptr [r9]
0x507710: mov        r10, qword ptr [rdx + 0x10]
0x507714: cmp        r10, rax
0x507717: jne        0x507f10
0x50771d: mov        rdi, qword ptr [r9 + 8]
0x507721: test       rdi, rdi
0x507724: je         0x508003
0x50772a: mov        rdx, qword ptr [rdi]
0x50772d: mov        r10, qword ptr [rdx + 0x10]
0x507731: cmp        r10, rax
0x507734: jne        0x507f72
0x50773a: mov        r9, qword ptr [rdi + 8]
0x50773e: test       r9, r9
0x507741: je         0x508003
0x507747: mov        rdx, qword ptr [r9]
0x50774a: mov        r8, qword ptr [rdi + 0x10]
0x50774e: xor        ecx, ecx
0x507750: lea        rsi, [rip + 0x32841e]
0x507757: mov        rdi, r9
0x50775a: mov        r10, qword ptr [rdx + 0x10]
0x50775e: mov        edx, 1
0x507763: cmp        r10, rax
0x507766: jne        0x507f25
0x50776c: call       0x4eebd0
0x507771: mov        dword ptr [rsp + 0xc], eax
0x507775: nop        word ptr cs:[rax + rax]
0x507780: mov        rdx, qword ptr [rbx + 0x168]
0x507787: mov        rax, qword ptr [rbx + 0x170]
0x50778e: xor        r13d, r13d
0x507791: sub        rax, rdx
0x507794: sar        rax, 2
0x507798: cmp        r13, rax
0x50779b: jae        0x508079
0x5077a1: cmp        dword ptr [rbx + 0x158], r13d
0x5077a8: je         0x507c10
0x5077ae: movsxd     r14, dword ptr [rdx + r13*4]
0x5077b2: mov        rbp, qword ptr [rbx + 0x218]
0x5077b9: lea        r9, [r14 + r14*8]
0x5077bd: mov        r15, r14
0x5077c0: shl        r9, 4
0x5077c4: add        r9, qword ptr [rbx + 0xe8]
0x5077cb: test       rbp, rbp
0x5077ce: je         0x507900
0x5077d4: movsxd     rax, dword ptr [r9 + 0x78]
0x5077d8: mov        ecx, r14d
0x5077db: cmp        eax, 0x20
0x5077de: je         0x507dd8
0x5077e4: cmp        eax, 0x33
0x5077e7: je         0x507b50
0x5077ed: mov        rdx, 0xeadba0
0x5077f4: mov        rsi, qword ptr [rdx + rax*8]
0x5077f8: mov        rax, qword ptr [rbp]
0x5077fc: mov        r10, qword ptr [rax + 0x10]
0x507800: mov        rax, 0x4eebd0
0x507807: cmp        r10, rax
0x50780a: jne        0x507df8
0x507810: mov        rdi, qword ptr [rbp + 8]
0x507814: test       rdi, rdi
0x507817: je         0x507900
0x50781d: mov        rdx, qword ptr [rdi]
0x507820: mov        r10, qword ptr [rdx + 0x10]
0x507824: cmp        r10, rax
0x507827: jne        0x507e80
0x50782d: mov        r10, qword ptr [rdi + 8]
0x507831: test       r10, r10
0x507834: je         0x507900
0x50783a: mov        rdx, qword ptr [r10]
0x50783d: mov        r11, qword ptr [rdx + 0x10]
0x507841: cmp        r11, rax
0x507844: jne        0x507f31
0x50784a: mov        rdi, qword ptr [r10 + 8]
0x50784e: test       rdi, rdi
0x507851: je         0x507900
0x507857: mov        rdx, qword ptr [rdi]
0x50785a: mov        r11, qword ptr [rdx + 0x10]
0x50785e: cmp        r11, rax
0x507861: jne        0x507fb6
0x507867: mov        r11, qword ptr [rdi + 8]
0x50786b: test       r11, r11
0x50786e: je         0x507900
0x507874: mov        rdx, qword ptr [r11]
0x507877: mov        r10, qword ptr [rdx + 0x10]
0x50787b: cmp        r10, rax
0x50787e: jne        0x508060
0x507884: mov        rdi, qword ptr [r11 + 8]
0x507888: test       rdi, rdi
0x50788b: je         0x507900
0x50788d: mov        rdx, qword ptr [rdi]
0x507890: mov        r10, qword ptr [rdx + 0x10]
0x507894: cmp        r10, rax
0x507897: jne        0x508080
0x50789d: mov        r10, qword ptr [rdi + 8]
0x5078a1: test       r10, r10
0x5078a4: je         0x507900
0x5078a6: mov        rdx, qword ptr [r10]
0x5078a9: mov        r8, qword ptr [rdi + 0x10]
0x5078ad: mov        qword ptr [rsp + 0x10], r9
0x5078b2: mov        rdi, r10
0x5078b5: mov        r11, qword ptr [rdx + 0x10]
0x5078b9: mov        edx, 2
0x5078be: cmp        r11, rax
0x5078c1: jne        0x507f42
0x5078c7: call       0x4eebd0
0x5078cc: jmp        0x507e0b
0x5078d1: nop        dword ptr [rax]
0x5078d8: lea        rsi, [rip + 0x31e549]
0x5078df: xor        eax, eax
0x5078e1: call       0x505290
0x5078e6: mov        edx, 1
0x5078eb: add        rsp, 0x38
0x5078ef: mov        eax, edx
0x5078f1: pop        rbx
0x5078f2: pop        rbp
0x5078f3: pop        r12
0x5078f5: pop        r13
0x5078f7: pop        r14
0x5078f9: pop        r15
0x5078fb: ret        
0x5078fc: nop        dword ptr [rax]
0x507900: mov        dword ptr [rsp + 0x20], 0
0x507908: mov        rax, qword ptr [r9]
0x50790b: xor        r8d, r8d
0x50790e: mov        ecx, dword ptr [rax]
0x507910: test       ecx, ecx
0x507912: jg         0x507932
# ... excerpt ends ...

# tflite::ops::builtin::Register_CONV_2D() @ 0x5d93c0, size=9
0x5d93c0: endbr64    
0x5d93c4: jmp        0x5d93a0

# tflite::multithreaded_ops::EigenTensorConvFunctor<float>::operator()(EigenForTFLite::ThreadPoolDevice const&, float const*, int, int, int, int, float const*, int, int, int, int, int, int, int, tflite::PaddingType, float*, int, int) [clone .isra.0] @ 0x5ec480, size=1698
0x5ec480: push       r15
0x5ec482: mov        r15, rdi
0x5ec485: push       r14
0x5ec487: push       r13
0x5ec489: push       r12
0x5ec48b: movsxd     r12, edx
0x5ec48e: push       rbp
0x5ec48f: push       rbx
0x5ec490: mov        rbx, rsi
0x5ec493: sub        rsp, 0x3e8
0x5ec49a: mov        qword ptr [rsp + 0x40], rdi
0x5ec49f: mov        eax, dword ptr [rsp + 0x428]
0x5ec4a6: mov        edi, ecx
0x5ec4a8: mov        qword ptr [rsp + 8], rsi
0x5ec4ad: mov        r10, qword ptr [rsp + 0x420]
0x5ec4b5: mov        ecx, dword ptr [rsp + 0x430]
0x5ec4bc: mov        esi, dword ptr [rsp + 0x460]
0x5ec4c3: movsxd     r14, dword ptr [rsp + 0x438]
0x5ec4cb: mov        rdx, qword ptr fs:[0x28]
0x5ec4d4: mov        qword ptr [rsp + 0x3d8], rdx
0x5ec4dc: mov        rdx, qword ptr [rsp + 0x468]
0x5ec4e4: cmp        eax, 1
0x5ec4e7: jne        0x5ec506
0x5ec4e9: cmp        ecx, 1
0x5ec4ec: jne        0x5ec506
0x5ec4ee: cmp        dword ptr [rsp + 0x440], 1
0x5ec4f6: jne        0x5ec506
0x5ec4f8: cmp        dword ptr [rsp + 0x448], 1
0x5ec500: je         0x5ec9d0
0x5ec506: cmp        eax, edi
0x5ec508: jne        0x5ec525
0x5ec50a: cmp        ecx, r8d
0x5ec50d: jne        0x5ec525
0x5ec50f: mov        r11d, dword ptr [rsp + 0x458]
0x5ec517: or         r11d, dword ptr [rsp + 0x450]
0x5ec51f: je         0x5eca68
0x5ec525: mov        qword ptr [rsp + 0x70], rdx
0x5ec52a: movsxd     r11, eax
0x5ec52d: xor        r15d, r15d
0x5ec530: movsxd     rax, ecx
0x5ec533: movsxd     rdx, dword ptr [rsp + 0x470]
0x5ec53b: and        esi, 0xfd
0x5ec541: movsxd     r13, edi
0x5ec544: movsxd     rbp, r9d
0x5ec547: mov        edi, 0x68
0x5ec54c: mov        qword ptr [rsp + 0x58], r13
0x5ec551: setne      r15b
0x5ec555: movsxd     rsi, dword ptr [rsp + 0x440]
0x5ec55d: mov        qword ptr [rsp + 0x80], rdx
0x5ec565: movsxd     rdx, dword ptr [rsp + 0x478]
0x5ec56d: add        r15d, 1
0x5ec571: movsxd     rcx, dword ptr [rsp + 0x448]
0x5ec579: mov        qword ptr [rsp + 0x20], rsi
0x5ec57e: mov        qword ptr [rsp + 0x88], rdx
0x5ec586: movsxd     rdx, r8d
0x5ec589: mov        qword ptr [rsp + 0x10], rdx
0x5ec58e: mov        qword ptr [rsp + 0x50], r10
0x5ec593: mov        qword ptr [rsp + 0x78], r12
0x5ec598: mov        qword ptr [rsp + 0x90], r14
0x5ec5a0: mov        qword ptr [rsp + 0x48], r11
0x5ec5a5: mov        qword ptr [rsp + 0x18], rax
0x5ec5aa: mov        qword ptr [rsp + 0x38], rcx
0x5ec5af: call       0x405540
0x5ec5b4: mov        rdx, qword ptr [rsp + 0x10]
0x5ec5b9: mov        rdi, qword ptr [rsp + 8]
0x5ec5be: mov        qword ptr [rax + 0x20], r13
0x5ec5c2: lea        r13, [rsp + 0x60]
0x5ec5c7: mov        rbx, rax
0x5ec5ca: mov        rsi, 0xeaeae8
0x5ec5d1: mov        qword ptr [rax + 0x18], r12
0x5ec5d5: movdqu     xmm0, xmmword ptr [rax + 0x18]
0x5ec5da: mov        qword ptr [rax + 0x28], rdx
0x5ec5de: mov        qword ptr [rax + 0x30], rbp
0x5ec5e2: movups     xmmword ptr [rax + 0x40], xmm0
0x5ec5e6: movdqu     xmm0, xmmword ptr [rax + 0x28]
0x5ec5eb: mov        qword ptr [rax + 0x10], rdi
0x5ec5ef: mov        edi, 0x68
0x5ec5f4: mov        qword ptr [rax + 0x38], r13
0x5ec5f8: mov        dword ptr [rax + 0x60], 0
0x5ec5ff: movups     xmmword ptr [rax + 0x50], xmm0
0x5ec603: lea        rax, [rsi + 0x10]
0x5ec607: mov        qword ptr [rbx], rax
0x5ec60a: call       0x405540
0x5ec60f: mov        r8, rax
0x5ec612: lea        rax, [rsp + 0x70]
0x5ec617: mov        r11, qword ptr [rsp + 0x48]
0x5ec61c: mov        r10, qword ptr [rsp + 0x50]
0x5ec621: movq       xmm5, rax
0x5ec626: mov        qword ptr [r8 + 0x28], rbp
0x5ec62a: mov        rax, qword ptr [rsp + 0x18]
0x5ec62f: lea        rdi, [rsp + 0x2c0]
0x5ec637: mov        qword ptr [r8 + 0x18], r11
0x5ec63b: movq       xmm3, qword ptr [rsp + 0x38]
0x5ec641: movhps     xmm3, qword ptr [rsp + 0x20]
0x5ec646: mov        qword ptr [r8 + 0x20], rax
0x5ec64a: mov        rax, 0xeaeae8
0x5ec651: movdqu     xmm0, xmmword ptr [r8 + 0x18]
0x5ec657: mov        qword ptr [r8 + 0x30], r14
0x5ec65b: movdqu     xmm1, xmmword ptr [r8 + 0x28]
0x5ec661: add        rax, 0x10
0x5ec665: mov        qword ptr [rsp + 0x30], rdi
0x5ec66a: movhps     xmm5, qword ptr [rsp + 0x30]
0x5ec66f: movdqa     xmm4, xmm0
0x5ec673: mov        qword ptr [r8], rax
0x5ec676: mov        rcx, qword ptr [rbx + 0x50]
0x5ec67a: movq       rdi, xmm0
0x5ec67f: movups     xmmword ptr [r8 + 0x50], xmm1
0x5ec684: mov        r9, qword ptr [rbx + 0x48]
0x5ec688: mov        rsi, qword ptr [r8 + 0x50]
0x5ec68c: shufpd     xmm4, xmm0, 1
0x5ec691: mov        qword ptr [r8 + 0x10], r10
0x5ec695: movq       xmm2, qword ptr [r8 + 0x58]
0x5ec69b: mov        qword ptr [r8 + 0x38], r13
0x5ec69f: mov        dword ptr [r8 + 0x60], 0
0x5ec6a7: movups     xmmword ptr [r8 + 0x40], xmm0
0x5ec6ac: movhps     qword ptr [rsp + 0x48], xmm0
0x5ec6b1: cmp        r15d, 2
0x5ec6b5: jne        0x5ec988
0x5ec6bb: test       rcx, rcx
0x5ec6be: je         0x5ec6cf
0x5ec6c0: lea        rax, [rcx - 1]
0x5ec6c4: cqo        
0x5ec6c6: idiv       qword ptr [rsp + 0x38]
0x5ec6cb: lea        rcx, [rax + 1]
0x5ec6cf: xor        edx, edx
0x5ec6d1: test       r9, r9
0x5ec6d4: jne        0x5ecb08
0x5ec6da: imul       rsi, qword ptr [rsp + 0x48]
0x5ec6e0: mov        rax, qword ptr [rbx + 0x40]
0x5ec6e4: pxor       xmm1, xmm1
0x5ec6e8: mov        qword ptr [rsp + 0xa8], r12
0x5ec6f0: movdqa     xmm6, xmmword ptr [rip + 0x87c9d8]
0x5ec6f8: movaps     xmmword ptr [rsp + 0x20], xmm5
0x5ec6fd: imul       rdx, rax
0x5ec701: mov        qword ptr [rsp + 0x148], r10
0x5ec709: imul       rsi, rdi
0x5ec70d: mov        rdi, qword ptr [rsp + 8]
0x5ec712: mov        qword ptr [rsp + 0x150], r11
0x5ec71a: movups     xmmword ptr [rsp + 0xc8], xmm4
0x5ec722: mov        qword ptr [rsp + 0xa0], rdi
0x5ec72a: mov        rdi, qword ptr [rsp + 0x58]
0x5ec72f: mov        qword ptr [rsp + 0x140], rsi
0x5ec737: movq       xmm7, rsi
0x5ec73c: movdqa     xmm8, xmmword ptr [rsp + 0xa0]
0x5ec746: mov        qword ptr [rsp + 0xb0], rdi
0x5ec74e: mov        rdi, qword ptr [rsp + 0x10]
0x5ec753: punpcklqdq xmm7, xmm2
0x5ec757: mov        rsi, qword ptr [rsp + 0x18]
0x5ec75c: movups     xmmword ptr [rsp + 0xd8], xmm3
0x5ec764: mov        qword ptr [rsp + 0xb8], rdi
0x5ec76c: mov        edi, 1
0x5ec771: movq       xmm0, rdi
0x5ec776: movaps     xmmword ptr [rsp + 0x110], xmm1
0x5ec77e: punpcklqdq xmm0, xmm0
0x5ec782: movaps     xmmword ptr [rsp + 0x120], xmm1
0x5ec78a: movaps     xmmword ptr [rsp + 0x170], xmm7
0x5ec792: mov        qword ptr [rsp + 0x138], rdx
0x5ec79a: mov        qword ptr [rsp + 0x158], rsi
0x5ec7a2: movups     xmmword ptr [rsp + 0xe8], xmm0
0x5ec7aa: movups     xmmword ptr [rsp + 0xf8], xmm0
0x5ec7b2: movaps     xmmword ptr [rsp + 0x180], xmm6
0x5ec7ba: mov        qword ptr [rsp + 0xc0], rbp
0x5ec7c2: mov        byte ptr [rsp + 0x108], 0
0x5ec7ca: mov        dword ptr [rsp + 0x130], r15d
0x5ec7d2: mov        dword ptr [rsp + 0x134], 0
0x5ec7dd: mov        qword ptr [rsp + 0x160], rbp
0x5ec7e5: mov        qword ptr [rsp + 0x168], r14
0x5ec7ed: movaps     xmmword ptr [rsp + 0x1a0], xmm8
0x5ec7f6: mov        rdi, qword ptr [rsp + 0x30]
0x5ec7fb: movdqa     xmm8, xmmword ptr [rsp + 0xb0]
0x5ec805: movups     xmmword ptr [rsp + 0x1e8], xmm0
0x5ec80d: mov        rdx, qword ptr [rsp + 0x190]
0x5ec815: movaps     xmmword ptr [rsp + 0x1b0], xmm8
0x5ec81e: movdqa     xmm8, xmmword ptr [rsp + 0xc0]
0x5ec828: movaps     xmmword ptr [rsp + 0x280], xmm6
0x5ec830: movq       xmm6, r9
0x5ec835: movaps     xmmword ptr [rsp + 0x1c0], xmm8
0x5ec83e: movdqa     xmm8, xmmword ptr [rsp + 0x100]
0x5ec848: mov        qword ptr [rsp + 0x290], rdx
0x5ec850: movaps     xmmword ptr [rsp + 0x200], xmm8
# ... excerpt ends ...

# TfLiteStatus tflite::ops::builtin::conv::EvalImpl<(tflite::ops::builtin::conv::KernelType)2, (TfLiteType)1>(TfLiteContext*, TfLiteNode*) @ 0x642790, size=574
0x642790: endbr64    
0x642794: push       r14
0x642796: xor        edx, edx
0x642798: push       r12
0x64279a: push       rbp
0x64279b: mov        rbp, rdi
0x64279e: push       rbx
0x64279f: sub        rsp, 0x48
0x6427a3: mov        r14, qword ptr [rsi + 0x28]
0x6427a7: mov        r12, qword ptr [rsi + 0x20]
0x6427ab: mov        rbx, qword ptr fs:[0x28]
0x6427b4: mov        qword ptr [rsp + 0x38], rbx
0x6427b9: mov        rbx, rsi
0x6427bc: lea        rcx, [rsp + 0x20]
0x6427c1: call       0x6f51e0
0x6427c6: mov        r10d, eax
0x6427c9: test       eax, eax
0x6427cb: je         0x6427f0
0x6427cd: mov        rax, qword ptr [rsp + 0x38]
0x6427d2: sub        rax, qword ptr fs:[0x28]
0x6427db: jne        0x6429c9
0x6427e1: add        rsp, 0x48
0x6427e5: mov        eax, r10d
0x6427e8: pop        rbx
0x6427e9: pop        rbp
0x6427ea: pop        r12
0x6427ec: pop        r14
0x6427ee: ret        
0x6427ef: nop        
0x6427f0: lea        rcx, [rsp + 0x28]
0x6427f5: xor        edx, edx
0x6427f7: mov        rsi, rbx
0x6427fa: mov        rdi, rbp
0x6427fd: call       0x6f50a0
0x642802: mov        r10d, eax
0x642805: test       eax, eax
0x642807: jne        0x6427cd
0x642809: lea        rcx, [rsp + 0x30]
0x64280e: mov        edx, 1
0x642813: mov        rsi, rbx
0x642816: mov        rdi, rbp
0x642819: call       0x6f50a0
0x64281e: mov        r10d, eax
0x642821: test       eax, eax
0x642823: jne        0x6427cd
0x642825: mov        rax, qword ptr [rbx]
0x642828: xor        r9d, r9d
0x64282b: cmp        dword ptr [rax], 3
0x64282e: je         0x642918
0x642834: xor        eax, eax
0x642836: cmp        byte ptr [r12 + 0x8e], 0
0x64283f: je         0x642857
0x642841: mov        rax, qword ptr [rbx + 0x18]
0x642845: movsxd     rdx, dword ptr [r12 + 0x70]
0x64284a: movsxd     rax, dword ptr [rax + rdx*4 + 4]
0x64284f: imul       rax, rax, 0x70
0x642853: add        rax, qword ptr [rbp + 0x10]
0x642857: xor        edx, edx
0x642859: cmp        byte ptr [r12 + 0x8c], 0
0x642862: je         0x642889
0x642864: mov        rdx, qword ptr [rbx + 0x18]
0x642868: movsxd     rcx, dword ptr [r12 + 0x74]
0x64286d: movsxd     rdx, dword ptr [rdx + rcx*4 + 4]
0x642872: imul       rdx, rdx, 0x70
0x642876: add        rdx, qword ptr [rbp + 0x10]
0x64287a: cmp        byte ptr [r12 + 0x8d], 0
0x642883: je         0x642940
0x642889: mov        r8, qword ptr [rsp + 0x30]
0x64288e: mov        rcx, qword ptr [rsp + 0x28]
0x642893: mov        rdi, qword ptr [rsp + 0x20]
0x642898: mov        esi, dword ptr [r8]
0x64289b: cmp        esi, 3
0x64289e: je         0x6428d0
0x6428a0: cmp        esi, 9
0x6428a3: je         0x6428d0
0x6428a5: mov        dword ptr [rsp], r10d
0x6428a9: sub        rsp, 8
0x6428ad: mov        rsi, r14
0x6428b0: push       rdi
0x6428b1: mov        rdi, rbp
0x6428b4: push       rdx
0x6428b5: mov        rdx, r12
0x6428b8: push       rax
0x6428b9: call       0x640780
0x6428be: add        rsp, 0x20
0x6428c2: mov        r10d, dword ptr [rsp]
0x6428c6: jmp        0x6427cd
0x6428cb: nop        dword ptr [rax + rax]
0x6428d0: cmp        byte ptr [r12 + 0x91], 0
0x6428d9: jne        0x6428ea
0x6428db: cmp        dword ptr [r12 + 0x94], 1
0x6428e4: je         0x642988
0x6428ea: sub        rsp, 8
0x6428ee: mov        rdx, r14
0x6428f1: mov        rsi, rbx
0x6428f4: push       rdi
0x6428f5: mov        rdi, rbp
0x6428f8: push       rax
0x6428f9: push       r9
0x6428fb: mov        r9, r8
0x6428fe: mov        r8, rcx
0x642901: mov        rcx, r12
0x642904: call       0x60c620
0x642909: add        rsp, 0x20
0x64290d: mov        r10d, eax
0x642910: jmp        0x6427cd
0x642915: nop        dword ptr [rax]
0x642918: mov        edx, 2
0x64291d: mov        rsi, rbx
0x642920: mov        rdi, rbp
0x642923: mov        dword ptr [rsp], r10d
0x642927: call       0x6f5050
0x64292c: mov        r10d, dword ptr [rsp]
0x642930: mov        r9, rax
0x642933: jmp        0x642834
0x642938: nop        dword ptr [rax + rax]
0x642940: mov        rdi, qword ptr [rsp + 0x30]
0x642945: mov        rsi, rdx
0x642948: mov        dword ptr [rsp + 0x1c], r10d
0x64294d: mov        qword ptr [rsp + 0x10], r9
0x642952: mov        qword ptr [rsp + 8], rax
0x642957: mov        qword ptr [rsp], rdx
0x64295b: call       0x5d91c0
0x642960: mov        r10d, dword ptr [rsp + 0x1c]
0x642965: mov        r9, qword ptr [rsp + 0x10]
0x64296a: mov        byte ptr [r12 + 0x8d], 1
0x642973: mov        rax, qword ptr [rsp + 8]
0x642978: mov        rdx, qword ptr [rsp]
0x64297c: jmp        0x642889
0x642981: nop        dword ptr [rax]
0x642988: movsxd     rsi, dword ptr [r12 + 0x80]
0x642990: mov        rdx, qword ptr [rbx + 0x18]
0x642994: push       rdi
0x642995: mov        rdi, rbp
0x642998: movsxd     rdx, dword ptr [rdx + rsi*4 + 4]
0x64299d: mov        rsi, rbx
0x6429a0: imul       rdx, rdx, 0x70
0x6429a4: add        rdx, qword ptr [rbp + 0x10]
0x6429a8: push       rdx
0x6429a9: mov        rdx, r14
0x6429ac: push       rax
0x6429ad: push       r9
0x6429af: mov        r9, r8
0x6429b2: mov        r8, rcx
0x6429b5: mov        rcx, r12
0x6429b8: call       0x601780
0x6429bd: add        rsp, 0x20
0x6429c1: mov        r10d, eax
0x6429c4: jmp        0x6427cd
0x6429c9: call       0x4055b0

# TfLiteStatus tflite::ops::builtin::conv::Eval<(tflite::ops::builtin::conv::KernelType)2>(TfLiteContext*, TfLiteNode*) @ 0x64d8d0, size=226
0x64d8d0: endbr64    
0x64d8d4: push       rbp
0x64d8d5: xor        edx, edx
0x64d8d7: push       rbx
0x64d8d8: mov        rbx, rdi
0x64d8db: sub        rsp, 0x18
0x64d8df: mov        rbp, qword ptr fs:[0x28]
0x64d8e8: mov        qword ptr [rsp + 8], rbp
0x64d8ed: mov        rbp, rsi
0x64d8f0: mov        rcx, rsp
0x64d8f3: call       0x6f50a0
0x64d8f8: test       eax, eax
0x64d8fa: jne        0x64d930
0x64d8fc: mov        rax, qword ptr [rsp]
0x64d900: mov        edi, dword ptr [rax]
0x64d902: cmp        edi, 7
0x64d905: je         0x64d9a0
0x64d90b: ja         0x64d950
0x64d90d: cmp        edi, 1
0x64d910: je         0x64d968
0x64d912: cmp        edi, 3
0x64d915: jne        0x64d978
0x64d917: mov        rsi, rbp
0x64d91a: mov        rdi, rbx
0x64d91d: call       0x64d730
0x64d922: nop        dword ptr [rax]
0x64d925: nop        word ptr cs:[rax + rax]
0x64d930: mov        rdx, qword ptr [rsp + 8]
0x64d935: sub        rdx, qword ptr fs:[0x28]
0x64d93e: jne        0x64d9ad
0x64d940: add        rsp, 0x18
0x64d944: pop        rbx
0x64d945: pop        rbp
0x64d946: ret        
0x64d947: nop        word ptr [rax + rax]
0x64d950: cmp        edi, 9
0x64d953: jne        0x64d978
0x64d955: mov        rsi, rbp
0x64d958: mov        rdi, rbx
0x64d95b: call       0x628ad0
0x64d960: jmp        0x64d930
0x64d962: nop        word ptr [rax + rax]
0x64d968: mov        rsi, rbp
0x64d96b: mov        rdi, rbx
0x64d96e: call       0x642790
0x64d973: jmp        0x64d930
0x64d975: nop        dword ptr [rax]
0x64d978: mov        rbp, qword ptr [rbx + 0x28]
0x64d97c: call       0x50b590
0x64d981: lea        rsi, [rip + 0x1d58e8]
0x64d988: mov        rdi, rbx
0x64d98b: mov        rdx, rax
0x64d98e: xor        eax, eax
0x64d990: call       rbp
0x64d992: mov        eax, 1
0x64d997: jmp        0x64d930
0x64d999: nop        dword ptr [rax]
0x64d9a0: mov        rsi, rbp
0x64d9a3: mov        rdi, rbx
0x64d9a6: call       0x61a730
0x64d9ab: jmp        0x64d930
0x64d9ad: call       0x4055b0

# tflite::optimized_ops::FullyConnected(tflite::FullyConnectedParams const&, tflite::RuntimeShape const&, unsigned char const*, tflite::RuntimeShape const&, unsigned char const*, tflite::RuntimeShape const&, int const*, tflite::RuntimeShape const&, unsigned char*, tflite::CpuBackendContext*) [clone .isra.0] @ 0x6ca860, size=2125
0x6ca860: push       r15
0x6ca862: push       r14
0x6ca864: push       r13
0x6ca866: push       r12
0x6ca868: push       rbp
0x6ca869: mov        ebp, esi
0x6ca86b: push       rbx
0x6ca86c: sub        rsp, 0x268
0x6ca873: mov        rax, qword ptr [rsp + 0x2b8]
0x6ca87b: mov        r10, qword ptr [rsp + 0x2d8]
0x6ca883: mov        dword ptr [rsp + 0x28], ecx
0x6ca887: mov        dword ptr [rsp + 0x14], edx
0x6ca88b: mov        r13, qword ptr [rsp + 0x2c0]
0x6ca893: mov        ecx, dword ptr [r10]
0x6ca896: mov        qword ptr [rsp], rax
0x6ca89a: mov        rax, qword ptr [rsp + 0x2c8]
0x6ca8a2: mov        r11, qword ptr [rsp + 0x2d0]
0x6ca8aa: mov        r12, qword ptr [rsp + 0x2e0]
0x6ca8b2: mov        ebx, dword ptr [r13]
0x6ca8b6: mov        qword ptr [rsp + 8], rax
0x6ca8bb: mov        rsi, qword ptr fs:[0x28]
0x6ca8c4: mov        qword ptr [rsp + 0x258], rsi
0x6ca8cc: mov        rsi, qword ptr [rsp + 0x2e8]
0x6ca8d4: cmp        ecx, 5
0x6ca8d7: jle        0x6cac70
0x6ca8dd: mov        r10, qword ptr [r10 + 8]
0x6ca8e1: lea        r14d, [rcx - 1]
0x6ca8e5: xor        eax, eax
0x6ca8e7: mov        edx, 1
0x6ca8ec: nop        word ptr [rax + rax]
0x6ca8f5: nop        word ptr cs:[rax + rax]
0x6ca900: cmp        r14d, eax
0x6ca903: je         0x6ca90a
0x6ca905: imul       edx, dword ptr [r10 + rax*4]
0x6ca90a: add        rax, 1
0x6ca90e: cmp        ecx, eax
0x6ca910: jg         0x6ca900
0x6ca912: test       edx, edx
0x6ca914: setg       r15b
0x6ca918: lea        eax, [rbx - 2]
0x6ca91b: cmp        ebx, 5
0x6ca91e: jle        0x6cac48
0x6ca924: mov        rcx, qword ptr [r13 + 8]
0x6ca928: cdqe       
0x6ca92a: lea        r10, [rcx + rax*4]
0x6ca92e: mov        r13d, dword ptr [rcx + rax*4 + 4]
0x6ca933: movq       xmm0, qword ptr [r10]
0x6ca938: mov        r10d, dword ptr [r10]
0x6ca93b: pshufd     xmm2, xmm0, 0xe1
0x6ca940: movd       ecx, xmm0
0x6ca944: pshufd     xmm4, xmm0, 0xe5
0x6ca949: movd       ebx, xmm4
0x6ca94d: test       ecx, ecx
0x6ca94f: setg       r14b
0x6ca953: test       ebx, ebx
0x6ca955: setg       al
0x6ca958: test       r14b, al
0x6ca95b: je         0x6cac19
0x6ca961: test       r15b, r15b
0x6ca964: je         0x6cac19
0x6ca96a: mov        r14d, edi
0x6ca96d: neg        ebp
0x6ca96f: neg        r14d
0x6ca972: cmp        byte ptr [rsi + 0x20], 0
0x6ca976: je         0x6cac88
0x6ca97c: mov        eax, dword ptr [rsp + 0x28]
0x6ca980: pxor       xmm1, xmm1
0x6ca984: mov        qword ptr [rsp + 0xe0], r11
0x6ca98c: movups     xmmword ptr [rsp + 0xe8], xmm1
0x6ca994: mov        rdi, qword ptr [rsi + 8]
0x6ca998: mov        dword ptr [rsp + 0xf0], eax
0x6ca99f: movzx      eax, r9b
0x6ca9a3: mov        ah, byte ptr [rsp + 0x2a0]
0x6ca9aa: movups     xmmword ptr [rsp + 0xf8], xmm1
0x6ca9b2: mov        word ptr [rsp + 0x104], ax
0x6ca9ba: mov        rax, qword ptr [rsp]
0x6ca9be: mov        qword ptr [rsp + 0x95], 0
0x6ca9ca: mov        qword ptr [rsp + 0x80], rax
0x6ca9d2: movzx      eax, byte ptr [rsp + 0x2b0]
0x6ca9da: movq       qword ptr [rsp + 0x20], xmm0
0x6ca9e0: movd       dword ptr [rsp + 0xb0], xmm0
0x6ca9e9: mov        dword ptr [rsp + 0x100], r8d
0x6ca9f1: mov        dword ptr [rsp + 0x8c], edx
0x6ca9f8: mov        dword ptr [rsp + 0xa8], r10d
0x6caa00: mov        dword ptr [rsp + 0xac], edx
0x6caa07: movq       qword ptr [rsp + 0x18], xmm2
0x6caa0d: movd       dword ptr [rsp + 0x90], xmm4
0x6caa16: mov        qword ptr [rsp + 0x75], 0
0x6caa1f: mov        dword ptr [rsp + 0x88], r13d
0x6caa27: xor        r13d, r13d
0x6caa2a: mov        qword ptr [rsp + 0xb5], 0
0x6caa36: mov        qword ptr [rsp + 0xa0], r12
0x6caa3e: mov        qword ptr [rsp + 0x108], 0
0x6caa4a: mov        dword ptr [rsp + 0x7c], 0
0x6caa52: mov        dword ptr [rsp + 0x9c], 0
0x6caa5d: mov        byte ptr [rsp + 0x94], 0
0x6caa65: mov        byte ptr [rsp + 0x98], r14b
0x6caa6d: mov        byte ptr [rsp + 0x99], al
0x6caa74: mov        dword ptr [rsp + 0xbc], 0
0x6caa7f: mov        byte ptr [rsp + 0xb4], 0
0x6caa87: movzx      eax, byte ptr [rsp + 0x14]
0x6caa8c: mov        byte ptr [rsp + 0xb8], al
0x6caa93: call       0x7fea50
0x6caa98: mov        rdi, rax
0x6caa9b: mov        r12, rax
0x6caa9e: call       0x816810
0x6caaa3: pxor       xmm1, xmm1
0x6caaa7: xor        eax, eax
0x6caaa9: pxor       xmm3, xmm3
0x6caaad: xor        r11d, r11d
0x6caab0: mov        dword ptr [rsp + 0x70], ebx
0x6caab4: lea        rdi, [rsp + 0x1a8]
0x6caabc: mov        ecx, 0xe
0x6caac1: mov        word ptr [rsp + 0x180], r11w
0x6caaca: movq       xmm0, qword ptr [rsp + 0x20]
0x6caad0: mov        qword ptr [rsp + 0x128], 0
0x6caadc: mov        byte ptr [rsp + 0x182], 0
0x6caae4: mov        qword ptr [rsp + 0x188], 0
0x6caaf0: mov        qword ptr [rsp + 0x190], 0
0x6caafc: mov        dword ptr [rsp + 0x198], 0
0x6cab07: mov        byte ptr [rsp + 0x19c], 0
0x6cab0f: mov        dword ptr [rsp + 0x1a0], 0
0x6cab1a: mov        byte ptr [rsp + 0x1a4], 0
0x6cab22: movups     xmmword ptr [rsp + 0x118], xmm3
0x6cab2a: movaps     xmmword ptr [rsp + 0x130], xmm1
0x6cab32: movaps     xmmword ptr [rsp + 0x140], xmm1
0x6cab3a: movaps     xmmword ptr [rsp + 0x150], xmm1
0x6cab42: movaps     xmmword ptr [rsp + 0x160], xmm1
0x6cab4a: movaps     xmmword ptr [rsp + 0x170], xmm1
0x6cab52: rep stosq  qword ptr [rdi], rax
0x6cab55: movzx      eax, word ptr [rip + 0x15651a]
0x6cab5c: mov        word ptr [rsp + 0x218], r13w
0x6cab65: mov        byte ptr [rsp + 0x74], 1
0x6cab6a: mov        word ptr [rsp + 0x1d6], ax
0x6cab72: mov        word ptr [rsp + 0x20e], ax
0x6cab7a: mov        rax, qword ptr [rsp + 8]
0x6cab7f: mov        byte ptr [rsp + 0x78], bpl
0x6cab84: mov        qword ptr [rsp + 0x60], rax
0x6cab89: movzx      eax, byte ptr [rsp + 0x2a8]
0x6cab91: movq       qword ptr [rsp + 0x68], xmm0
0x6cab97: mov        byte ptr [rsp + 0x79], al
0x6cab9b: movdqa     xmm0, xmmword ptr [rsp + 0x60]
0x6caba1: movq       xmm2, qword ptr [rsp + 0x18]
0x6caba7: lea        rdx, [rsp + 0xa0]
0x6cabaf: lea        rsi, [rsp + 0x80]
0x6cabb7: lea        rdi, [rsp + 0xc0]
0x6cabbf: lea        rcx, [rsp + 0xe0]
0x6cabc7: sub        rsp, 8
0x6cabcb: mov        r9, r12
0x6cabce: movaps     xmmword ptr [rsp + 0xc8], xmm0
0x6cabd6: movdqa     xmm0, xmmword ptr [rsp + 0x78]
0x6cabdc: movq       qword ptr [rsp + 0xd0], xmm2
0x6cabe5: movaps     xmmword ptr [rsp + 0xd8], xmm0
0x6cabed: mov        byte ptr [rsp + 0xdc], 0
0x6cabf5: lea        rbx, [rsp + 0x118]
0x6cabfd: push       rbx
0x6cabfe: movzx      r8d, byte ptr [rsp + 0x116]
0x6cac07: call       0x64a420
0x6cac0c: pop        rax
0x6cac0d: mov        rsi, rbx
0x6cac10: pop        rdx
0x6cac11: mov        rdi, r12
0x6cac14: call       0x7fedf0
0x6cac19: mov        rax, qword ptr [rsp + 0x258]
0x6cac21: sub        rax, qword ptr fs:[0x28]
0x6cac2a: jne        0x6cb0a8
0x6cac30: add        rsp, 0x268
0x6cac37: pop        rbx
0x6cac38: pop        rbp
0x6cac39: pop        r12
0x6cac3b: pop        r13
0x6cac3d: pop        r14
0x6cac3f: pop        r15
0x6cac41: ret        
0x6cac42: nop        word ptr [rax + rax]
0x6cac48: cdqe       
0x6cac4a: sub        ebx, 1
0x6cac4d: movq       xmm0, qword ptr [r13 + rax*4 + 8]
0x6cac54: movsxd     rbx, ebx
0x6cac57: mov        r10d, dword ptr [r13 + rax*4 + 8]
# ... excerpt ends ...

# tflite::optimized_ops::FullyConnected(tflite::FullyConnectedParams const&, tflite::RuntimeShape const&, unsigned char const*, tflite::RuntimeShape const&, unsigned char const*, tflite::RuntimeShape const&, int const*, tflite::RuntimeShape const&, short*, tflite::CpuBackendContext*) [clone .isra.0] @ 0x6cb0b0, size=1933
0x6cb0b0: push       r15
0x6cb0b2: push       r14
0x6cb0b4: push       r13
0x6cb0b6: push       r12
0x6cb0b8: push       rbp
0x6cb0b9: mov        ebp, edi
0x6cb0bb: push       rbx
0x6cb0bc: sub        rsp, 0x248
0x6cb0c3: mov        rax, qword ptr [rsp + 0x290]
0x6cb0cb: mov        r15, qword ptr [rsp + 0x298]
0x6cb0d3: mov        dword ptr [rsp + 0x10], esi
0x6cb0d7: mov        rbx, qword ptr [rsp + 0x2b0]
0x6cb0df: mov        dword ptr [rsp + 0x20], ecx
0x6cb0e3: mov        r10d, dword ptr [r15]
0x6cb0e6: mov        qword ptr [rsp], rax
0x6cb0ea: mov        rax, qword ptr [rsp + 0x2a0]
0x6cb0f2: mov        ecx, dword ptr [rbx]
0x6cb0f4: mov        dword ptr [rsp + 0x14], edx
0x6cb0f8: mov        r13, qword ptr [rsp + 0x2a8]
0x6cb100: mov        r11, qword ptr [rsp + 0x2b8]
0x6cb108: lea        r12d, [r10 - 2]
0x6cb10c: mov        qword ptr [rsp + 8], rax
0x6cb111: lea        esi, [rcx - 1]
0x6cb114: mov        r14, qword ptr fs:[0x28]
0x6cb11d: mov        qword ptr [rsp + 0x238], r14
0x6cb125: mov        r14, qword ptr [rsp + 0x2c0]
0x6cb12d: cmp        ecx, 5
0x6cb130: jle        0x6cb480
0x6cb136: mov        rdi, qword ptr [rbx + 8]
0x6cb13a: xor        eax, eax
0x6cb13c: mov        edx, 1
0x6cb141: nop        dword ptr [rax]
0x6cb145: nop        word ptr cs:[rax + rax]
0x6cb150: cmp        esi, eax
0x6cb152: je         0x6cb158
0x6cb154: imul       edx, dword ptr [rdi + rax*4]
0x6cb158: add        rax, 1
0x6cb15c: cmp        ecx, eax
0x6cb15e: jg         0x6cb150
0x6cb160: test       edx, edx
0x6cb162: setg       al
0x6cb165: cmp        ecx, 5
0x6cb168: jle        0x6cb48e
0x6cb16e: mov        rcx, qword ptr [rbx + 8]
0x6cb172: movsxd     rsi, esi
0x6cb175: mov        ebx, dword ptr [rcx + rsi*4]
0x6cb178: cmp        r10d, 5
0x6cb17c: jle        0x6cb460
0x6cb182: mov        rcx, qword ptr [r15 + 8]
0x6cb186: movsxd     r12, r12d
0x6cb189: mov        esi, dword ptr [rcx + r12*4]
0x6cb18d: mov        r15d, dword ptr [rcx + r12*4 + 4]
0x6cb192: cmp        ebx, esi
0x6cb194: cmovg      ebx, esi
0x6cb197: test       ebx, ebx
0x6cb199: setg       sil
0x6cb19d: test       r15d, r15d
0x6cb1a0: setg       cl
0x6cb1a3: test       sil, cl
0x6cb1a6: je         0x6cb434
0x6cb1ac: test       al, al
0x6cb1ae: je         0x6cb434
0x6cb1b4: mov        eax, r9d
0x6cb1b7: movzx      r12d, byte ptr [rsp + 0x10]
0x6cb1bd: movzx      ecx, r8w
0x6cb1c1: neg        ebp
0x6cb1c3: shl        eax, 0x10
0x6cb1c6: or         eax, ecx
0x6cb1c8: neg        r12d
0x6cb1cb: movd       xmm1, eax
0x6cb1cf: cmp        byte ptr [r14 + 0x20], 0
0x6cb1d4: je         0x6cb4b0
0x6cb1da: mov        eax, dword ptr [rsp + 0x14]
0x6cb1de: pxor       xmm0, xmm0
0x6cb1e2: mov        rdi, qword ptr [r14 + 8]
0x6cb1e6: mov        dword ptr [rsp + 0x6c], edx
0x6cb1ea: movups     xmmword ptr [rsp + 0xc8], xmm0
0x6cb1f2: mov        dword ptr [rsp + 0xd0], eax
0x6cb1f9: mov        eax, dword ptr [rsp + 0x20]
0x6cb1fd: movups     xmmword ptr [rsp + 0xd8], xmm0
0x6cb205: mov        dword ptr [rsp + 0xe0], eax
0x6cb20c: mov        rax, qword ptr [rsp]
0x6cb210: mov        qword ptr [rsp + 0x75], 0
0x6cb219: mov        qword ptr [rsp + 0x60], rax
0x6cb21e: movzx      eax, byte ptr [rsp + 0x288]
0x6cb226: mov        qword ptr [rsp + 0x80], r11
0x6cb22e: movd       dword ptr [rsp + 0xe4], xmm1
0x6cb237: mov        qword ptr [rsp + 0xc0], r13
0x6cb23f: xor        r13d, r13d
0x6cb242: mov        qword ptr [rsp + 0x55], 0
0x6cb24b: mov        byte ptr [rsp + 0x78], bpl
0x6cb250: mov        qword ptr [rsp + 0x95], 0
0x6cb25c: mov        dword ptr [rsp + 0x8c], edx
0x6cb263: mov        qword ptr [rsp + 0xe8], 0
0x6cb26f: mov        dword ptr [rsp + 0x5c], 0
0x6cb277: mov        dword ptr [rsp + 0x7c], 0
0x6cb27f: mov        dword ptr [rsp + 0x68], r15d
0x6cb284: mov        dword ptr [rsp + 0x70], r15d
0x6cb289: mov        byte ptr [rsp + 0x74], 0
0x6cb28e: mov        byte ptr [rsp + 0x79], al
0x6cb292: mov        dword ptr [rsp + 0x9c], 0
0x6cb29d: mov        dword ptr [rsp + 0x88], ebx
0x6cb2a4: mov        dword ptr [rsp + 0x90], ebx
0x6cb2ab: mov        byte ptr [rsp + 0x94], 0
0x6cb2b3: call       0x7fea50
0x6cb2b8: mov        rdi, rax
0x6cb2bb: mov        rbp, rax
0x6cb2be: call       0x816810
0x6cb2c3: pxor       xmm0, xmm0
0x6cb2c7: xor        eax, eax
0x6cb2c9: pxor       xmm1, xmm1
0x6cb2cd: xor        r11d, r11d
0x6cb2d0: mov        dword ptr [rsp + 0x48], ebx
0x6cb2d4: lea        rdi, [rsp + 0x188]
0x6cb2dc: mov        ecx, 0xe
0x6cb2e1: mov        qword ptr [rsp + 0x108], 0
0x6cb2ed: mov        word ptr [rsp + 0x160], r11w
0x6cb2f6: mov        byte ptr [rsp + 0x162], 0
0x6cb2fe: mov        qword ptr [rsp + 0x168], 0
0x6cb30a: mov        qword ptr [rsp + 0x170], 0
0x6cb316: mov        dword ptr [rsp + 0x178], 0
0x6cb321: mov        byte ptr [rsp + 0x17c], 0
0x6cb329: mov        dword ptr [rsp + 0x180], 0
0x6cb334: mov        byte ptr [rsp + 0x184], 0
0x6cb33c: movups     xmmword ptr [rsp + 0xf8], xmm1
0x6cb344: movaps     xmmword ptr [rsp + 0x110], xmm0
0x6cb34c: movaps     xmmword ptr [rsp + 0x120], xmm0
0x6cb354: movaps     xmmword ptr [rsp + 0x130], xmm0
0x6cb35c: movaps     xmmword ptr [rsp + 0x140], xmm0
0x6cb364: movaps     xmmword ptr [rsp + 0x150], xmm0
0x6cb36c: rep stosq  qword ptr [rdi], rax
0x6cb36f: movzx      eax, word ptr [rip + 0x155d00]
0x6cb376: mov        dword ptr [rsp + 0x4c], r15d
0x6cb37b: mov        word ptr [rsp + 0x1f8], r13w
0x6cb384: mov        word ptr [rsp + 0x1b6], ax
0x6cb38c: mov        word ptr [rsp + 0x1ee], ax
0x6cb394: mov        rax, qword ptr [rsp + 8]
0x6cb399: mov        dword ptr [rsp + 0x50], r15d
0x6cb39e: mov        qword ptr [rsp + 0x40], rax
0x6cb3a3: movzx      eax, byte ptr [rsp + 0x280]
0x6cb3ab: mov        byte ptr [rsp + 0x54], 1
0x6cb3b0: mov        byte ptr [rsp + 0x58], r12b
0x6cb3b5: mov        byte ptr [rsp + 0x59], al
0x6cb3b9: movdqa     xmm0, xmmword ptr [rsp + 0x40]
0x6cb3bf: lea        rsi, [rsp + 0x60]
0x6cb3c4: lea        rdx, [rsp + 0x80]
0x6cb3cc: mov        r9, rbp
0x6cb3cf: lea        rdi, [rsp + 0xa0]
0x6cb3d7: lea        rcx, [rsp + 0xc0]
0x6cb3df: sub        rsp, 8
0x6cb3e3: movaps     xmmword ptr [rsp + 0xa8], xmm0
0x6cb3eb: movdqa     xmm0, xmmword ptr [rsp + 0x58]
0x6cb3f1: mov        dword ptr [rsp + 0xb0], r15d
0x6cb3f9: movaps     xmmword ptr [rsp + 0xb8], xmm0
0x6cb401: mov        dword ptr [rsp + 0xb4], ebx
0x6cb408: mov        byte ptr [rsp + 0xbc], 0
0x6cb410: lea        rbx, [rsp + 0xf8]
0x6cb418: push       rbx
0x6cb419: movzx      r8d, byte ptr [rsp + 0xf8]
0x6cb422: call       0x6dd4c0
0x6cb427: pop        rax
0x6cb428: mov        rsi, rbx
0x6cb42b: pop        rdx
0x6cb42c: mov        rdi, rbp
0x6cb42f: call       0x7fedf0
0x6cb434: mov        rax, qword ptr [rsp + 0x238]
0x6cb43c: sub        rax, qword ptr fs:[0x28]
0x6cb445: jne        0x6cb838
0x6cb44b: add        rsp, 0x248
0x6cb452: pop        rbx
0x6cb453: pop        rbp
0x6cb454: pop        r12
0x6cb456: pop        r13
0x6cb458: pop        r14
0x6cb45a: pop        r15
0x6cb45c: ret        
0x6cb45d: nop        dword ptr [rax]
0x6cb460: movsxd     r12, r12d
0x6cb463: mov        ecx, dword ptr [r15 + r12*4 + 8]
0x6cb468: cmp        ebx, ecx
# ... excerpt ends ...

# tflite::optimized_ops::MaxPool(tflite::PoolParams const&, tflite::RuntimeShape const&, float const*, tflite::RuntimeShape const&, float*) @ 0x7923c0, size=2953
0x7923c0: endbr64    
0x7923c4: push       r15
0x7923c6: mov        rax, rsi
0x7923c9: mov        rsi, rcx
0x7923cc: push       r14
0x7923ce: mov        r14, rdx
0x7923d1: push       r13
0x7923d3: mov        r13, r8
0x7923d6: push       r12
0x7923d8: push       rbp
0x7923d9: push       rbx
0x7923da: sub        rsp, 0x20
0x7923de: mov        qword ptr [rsp - 0x48], rdi
0x7923e3: mov        edi, dword ptr [rcx]
0x7923e5: cmp        edi, 5
0x7923e8: jle        0x792c84
0x7923ee: mov        r9, qword ptr [rcx + 8]
0x7923f2: mov        ecx, dword ptr [rax]
0x7923f4: mov        edx, dword ptr [r9]
0x7923f7: cmp        ecx, 5
0x7923fa: jg         0x792c92
0x792400: mov        r8d, dword ptr [rax + 8]
0x792404: mov        r10d, dword ptr [rax + 0xc]
0x792408: mov        ebp, dword ptr [rax + 0x10]
0x79240b: cmp        edx, r8d
0x79240e: cmovle     r8d, edx
0x792412: mov        ebx, dword ptr [r9 + 4]
0x792416: mov        dword ptr [rsp - 0x38], ebx
0x79241a: mov        ebx, dword ptr [r9 + 8]
0x79241e: mov        dword ptr [rsp - 0x34], ebx
0x792422: mov        rbx, qword ptr [rsp - 0x48]
0x792427: mov        edx, dword ptr [rbx + 0xc]
0x79242a: mov        ebx, dword ptr [rbx + 0x10]
0x79242d: mov        dword ptr [rsp - 0x40], edx
0x792431: lea        edx, [rcx - 1]
0x792434: mov        dword ptr [rsp - 0x3c], ebx
0x792438: cmp        ecx, 5
0x79243b: jg         0x792e99
0x792441: movsxd     rdx, edx
0x792444: lea        r9d, [rdi - 1]
0x792448: mov        r12d, dword ptr [rax + rdx*4 + 8]
0x79244d: cmp        edi, 5
0x792450: jle        0x792ce9
0x792456: mov        rcx, qword ptr [rsi + 8]
0x79245a: movsxd     rax, r9d
0x79245d: mov        r11d, dword ptr [rcx + rax*4]
0x792461: xor        edx, edx
0x792463: mov        eax, 1
0x792468: cmp        r9d, edx
0x79246b: je         0x792471
0x79246d: imul       eax, dword ptr [rcx + rdx*4]
0x792471: add        rdx, 1
0x792475: cmp        edi, edx
0x792477: jg         0x792468
0x792479: cdqe       
0x79247b: movsxd     r15, r11d
0x79247e: mov        r11, r13
0x792481: mov        qword ptr [rsp - 0x20], r13
0x792486: imul       rax, r15
0x79248a: mov        rdx, rax
0x79248d: and        r11d, 3
0x792491: jne        0x792db2
0x792497: mov        rax, r13
0x79249a: mov        r9, rdx
0x79249d: shr        rax, 2
0x7924a1: neg        rax
0x7924a4: and        eax, 3
0x7924a7: cmp        rax, rdx
0x7924aa: cmovg      rax, rdx
0x7924ae: sub        r9, rax
0x7924b1: lea        rcx, [r9 + 3]
0x7924b5: cmovns     rcx, r9
0x7924b9: and        rcx, 0xfffffffffffffffc
0x7924bd: add        rcx, rax
0x7924c0: test       rax, rax
0x7924c3: jle        0x7924f3
0x7924c5: movss      xmm0, dword ptr [rip + 0x8eb57]
0x7924cd: xor        r9d, r9d
0x7924d0: movss      dword ptr [r13], xmm0
0x7924d6: cmp        rax, 1
0x7924da: je         0x7924f3
0x7924dc: add        r9, 2
0x7924e0: movss      dword ptr [r13 + r11 + 4], xmm0
0x7924e7: cmp        r9, rax
0x7924ea: jge        0x7924f3
0x7924ec: movss      dword ptr [r13 + r11 + 8], xmm0
0x7924f3: cmp        rcx, rax
0x7924f6: jle        0x79254a
0x7924f8: mov        r9, rax
0x7924fb: movss      xmm0, dword ptr [rip + 0x8eb21]
0x792503: not        r9
0x792506: add        r9, rcx
0x792509: shufps     xmm0, xmm0, 0
0x79250d: movaps     xmmword ptr [r13 + rax*4], xmm0
0x792513: add        rax, 4
0x792517: shr        r9, 2
0x79251b: cmp        rcx, rax
0x79251e: jle        0x79254a
0x792520: and        r9d, 1
0x792524: je         0x792535
0x792526: movaps     xmmword ptr [r13 + rax*4], xmm0
0x79252c: add        rax, 4
0x792530: cmp        rcx, rax
0x792533: jle        0x79254a
0x792535: movaps     xmmword ptr [r13 + rax*4], xmm0
0x79253b: movaps     xmmword ptr [r13 + rax*4 + 0x10], xmm0
0x792541: add        rax, 8
0x792545: cmp        rcx, rax
0x792548: jg         0x792535
0x79254a: cmp        rdx, rcx
0x79254d: jle        0x7925e4
0x792553: mov        r11, rdx
0x792556: sub        r11, rcx
0x792559: lea        rax, [r11 - 1]
0x79255d: cmp        rax, 2
0x792561: jbe        0x7925b5
0x792563: mov        r9, r11
0x792566: movss      xmm0, dword ptr [rip + 0x8eab6]
0x79256e: lea        rax, [r13 + rcx*4]
0x792573: shr        r9, 2
0x792577: shl        r9, 4
0x79257b: shufps     xmm0, xmm0, 0
0x79257f: lea        rbx, [r9 + rax]
0x792583: and        r9d, 0x10
0x792587: je         0x792595
0x792589: movups     xmmword ptr [rax], xmm0
0x79258c: add        rax, 0x10
0x792590: cmp        rbx, rax
0x792593: je         0x7925a5
0x792595: movups     xmmword ptr [rax], xmm0
0x792598: add        rax, 0x20
0x79259c: movups     xmmword ptr [rax - 0x10], xmm0
0x7925a0: cmp        rbx, rax
0x7925a3: jne        0x792595
0x7925a5: test       r11b, 3
0x7925a9: je         0x7925e4
0x7925ab: mov        rax, r11
0x7925ae: and        rax, 0xfffffffffffffffc
0x7925b2: add        rcx, rax
0x7925b5: movss      xmm0, dword ptr [rip + 0x8ea67]
0x7925bd: lea        rax, [rcx + 1]
0x7925c1: movss      dword ptr [r13 + rcx*4], xmm0
0x7925c8: cmp        rdx, rax
0x7925cb: jle        0x7925e4
0x7925cd: lea        rax, [rcx + 2]
0x7925d1: movss      dword ptr [r13 + rcx*4 + 4], xmm0
0x7925d8: cmp        rdx, rax
0x7925db: jle        0x7925e4
0x7925dd: movss      dword ptr [r13 + rcx*4 + 8], xmm0
0x7925e4: test       r8d, r8d
0x7925e7: jle        0x792a5c
0x7925ed: test       r10d, r10d
0x7925f0: jle        0x792a5c
0x7925f6: test       ebp, ebp
0x7925f8: jle        0x792a5c
0x7925fe: movsxd     rdx, r12d
0x792601: movsxd     rax, dword ptr [rsp - 0x34]
0x792606: mov        ecx, r10d
0x792609: mov        qword ptr [rsp - 8], rsi
0x79260e: mov        qword ptr [rsp - 0x18], rdx
0x792613: mov        rdx, r13
0x792616: imul       ecx, ebp
0x792619: xor        ebx, ebx
0x79261b: imul       rax, r15
0x79261f: sub        rdx, r14
0x792622: xor        edi, edi
0x792624: mov        r12d, ebp
0x792627: mov        dword ptr [rsp - 0x30], 0
0x79262f: mov        qword ptr [rsp - 0x10], rdx
0x792634: mov        esi, ecx
0x792636: mov        rcx, rax
0x792639: mov        dword ptr [rsp - 0x2c], ebx
0x79263d: xor        ebp, ebp
0x79263f: mov        dword ptr [rsp], edi
0x792642: mov        r9d, ebp
0x792645: mov        dword ptr [rsp + 4], ebx
0x792649: mov        dword ptr [rsp + 8], esi
0x79264d: mov        dword ptr [rsp - 0x28], r10d
0x792652: xor        ebx, ebx
0x792654: mov        dword ptr [rsp - 0x24], r8d
# ... excerpt ends ...
