# Actual instructions and data from model; addresses are ELF virtual addresses.
# At the MaxPool call: rdi=params, rsi=input_shape, rdx=input_data, rcx=output_shape, r8=output_data.

# MaxEval entry: fetch output/input TfLiteTensor
0x792f60: endbr64   
0x792f64: push      r15
0x792f66: xor       edx, edx
0x792f68: push      r14
0x792f6a: push      r13
0x792f6c: mov       r13, rdi
0x792f6f: push      r12
0x792f71: push      rbp
0x792f72: push      rbx
0x792f73: sub       rsp, 0x148
0x792f7a: mov       rbp, qword ptr [rsi + 0x28]
0x792f7e: mov       r14, qword ptr [rsi + 0x20]
0x792f82: mov       r12, qword ptr fs:[0x28]
0x792f8b: mov       qword ptr [rsp + 0x138], r12
0x792f93: mov       r12, rsi
0x792f96: lea       rcx, [rsp + 0xb0]
0x792f9e: call      0x6f51e0
0x792fa3: mov       ebx, eax
0x792fa5: test      eax, eax
0x792fa7: je        0x792fd4
0x792fa9: mov       rax, qword ptr [rsp + 0x138]
0x792fb1: sub       rax, qword ptr fs:[0x28]
0x792fba: jne       0x7937d6
0x792fc0: add       rsp, 0x148
0x792fc7: mov       eax, ebx
0x792fc9: pop       rbx
0x792fca: pop       rbp
0x792fcb: pop       r12
0x792fcd: pop       r13
0x792fcf: pop       r14
0x792fd1: pop       r15
0x792fd3: ret       
0x792fd4: lea       rcx, [rsp + 0xb8]
0x792fdc: xor       edx, edx
0x792fde: mov       rsi, r12
0x792fe1: mov       rdi, r13
0x792fe4: call      0x6f50a0
0x792fe9: mov       ebx, eax
0x792feb: test      eax, eax
0x792fed: jne       0x792fa9
0x792fef: mov       r12, qword ptr [rsp + 0xb8]
0x792ff7: mov       edi, dword ptr [r12]
0x792ffb: cmp       edi, 7
0x792ffe: je        0x793036
0x793000: ja        0x79318d
0x793006: cmp       edi, 1
0x793009: je        0x7931d4
0x79300f: cmp       edi, 3
0x793012: jne       0x7931b0

# Float branch
0x7931d4: mov       eax, dword ptr [rbp + 0x14]
0x7931d7: mov       r13, qword ptr [rsp + 0xb0]
0x7931df: cmp       eax, 1
0x7931e2: je        0x793649
0x7931e8: cmp       eax, 3
0x7931eb: je        0x793838
0x7931f1: cmp       eax, 2
0x7931f4: je        0x793823
0x7931fa: movss     xmm0, dword ptr [rip + 0x8de16]
0x793202: movss     xmm1, dword ptr [rip + 0x8de1a]
0x79320a: jmp       0x793655

# Build PoolParams and two RuntimeShape objects; call MaxPool
0x793655: movdqu    xmm2, xmmword ptr [rbp + 4]
0x79365a: pshufd    xmm2, xmm2, 0xb1
0x79365f: movups    xmmword ptr [rsp + 0xcc], xmm2
0x793667: mov       eax, dword ptr [r14 + 4]
0x79366b: mov       word ptr [rsp + 0xc4], ax
0x793673: mov       eax, dword ptr [r14]
0x793676: movss     dword ptr [rsp + 0xe4], xmm1
0x79367f: mov       word ptr [rsp + 0xc2], ax
0x793687: movss     dword ptr [rsp + 0xe8], xmm0
0x793690: test      r13, r13
0x793693: je        0x793797
0x793699: mov       rbp, qword ptr [r13 + 0x10]
0x79369d: mov       r14, qword ptr [r13 + 8]
0x7936a1: lea       rdi, [rsp + 0xf8]
0x7936a9: movsxd    r13, dword ptr [rbp]
0x7936ad: add       rbp, 4
0x7936b1: mov       rax, r13
0x7936b4: mov       dword ptr [rsp + 0xf0], r13d
0x7936bc: shl       r13, 2
0x7936c0: cmp       eax, 5
0x7936c3: jle       0x7936d8
0x7936c5: mov       rdi, r13
0x7936c8: call      0x405040
0x7936cd: mov       qword ptr [rsp + 0xf8], rax
0x7936d5: mov       rdi, rax
0x7936d8: mov       rdx, r13
0x7936db: mov       rsi, rbp
0x7936de: mov       r13, r14
0x7936e1: call      0x405420
0x7936e6: mov       ebp, dword ptr [rsp + 0xf0]
0x7936ed: mov       r14, qword ptr [r12 + 8]
0x7936f2: mov       r12, qword ptr [r12 + 0x10]
0x7936f7: lea       rdi, [rsp + 0x118]
0x7936ff: movsxd    r15, dword ptr [r12]
0x793703: mov       rax, r15
0x793706: mov       dword ptr [rsp + 0x110], r15d
0x79370e: shl       r15, 2
0x793712: cmp       eax, 5
0x793715: jg        0x793782
0x793717: lea       rsi, [r12 + 4]
0x79371c: mov       rdx, r15
0x79371f: call      0x405420
0x793724: lea       rcx, [rsp + 0xf0]
0x79372c: mov       r8, r13
0x79372f: mov       rdx, r14
0x793732: lea       rsi, [rsp + 0x110]
0x79373a: lea       rdi, [rsp + 0xc0]
0x793742: call      0x7923c0

# MaxPool: read shape ranks and dimensions
0x7923c0: endbr64   
0x7923c4: push      r15
0x7923c6: mov       rax, rsi
0x7923c9: mov       rsi, rcx
0x7923cc: push      r14
0x7923ce: mov       r14, rdx
0x7923d1: push      r13
0x7923d3: mov       r13, r8
0x7923d6: push      r12
0x7923d8: push      rbp
0x7923d9: push      rbx
0x7923da: sub       rsp, 0x20
0x7923de: mov       qword ptr [rsp - 0x48], rdi
0x7923e3: mov       edi, dword ptr [rcx]
0x7923e5: cmp       edi, 5
0x7923e8: jle       0x792c84
0x7923ee: mov       r9, qword ptr [rcx + 8]
0x7923f2: mov       ecx, dword ptr [rax]
0x7923f4: mov       edx, dword ptr [r9]
0x7923f7: cmp       ecx, 5
0x7923fa: jg        0x792c92
0x792400: mov       r8d, dword ptr [rax + 8]
0x792404: mov       r10d, dword ptr [rax + 0xc]
0x792408: mov       ebp, dword ptr [rax + 0x10]
0x79240b: cmp       edx, r8d
0x79240e: cmovle    r8d, edx
0x792412: mov       ebx, dword ptr [r9 + 4]
0x792416: mov       dword ptr [rsp - 0x38], ebx
0x79241a: mov       ebx, dword ptr [r9 + 8]
0x79241e: mov       dword ptr [rsp - 0x34], ebx
0x792422: mov       rbx, qword ptr [rsp - 0x48]
0x792427: mov       edx, dword ptr [rbx + 0xc]
0x79242a: mov       ebx, dword ptr [rbx + 0x10]
0x79242d: mov       dword ptr [rsp - 0x40], edx
0x792431: lea       edx, [rcx - 1]
0x792434: mov       dword ptr [rsp - 0x3c], ebx

# Small output shape branch
0x792c84: mov       edx, dword ptr [rcx + 8]
0x792c87: mov       ecx, dword ptr [rax]
0x792c89: cmp       ecx, 5
0x792c8c: jle       0x792e42

# First pool input FlatBuffer shape vector: length, N,H,W,C
0xe687d0: .long 4, 1, 32, 32, 20

# First pool output FlatBuffer shape vector: length, N,H,W,C
0xe68714: .long 4, 1, 16, 16, 20
