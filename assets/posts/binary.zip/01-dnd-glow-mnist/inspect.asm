Instructions decoded from the delivered ELF bytes.
Names/addresses from a debug companion are navigation aids only; the companion is not packaged.
Symbol locator: delivered ELF
Numeric indirect targets require their own analysis. Snippets can be intentionally truncated.


main @ 0x60003a2c:
  0x60003a2c: 10 b5                        push         {r4, lr}
  0x60003a2e: 2d ed 02 8b                  vpush        {d8}
  0x60003a32: 01 f0 a9 f9                  bl           #0x60004d88
  0x60003a36: 9f ed 23 8a                  vldr         s16, [pc, #0x8c]
  0x60003a3a: 01 f0 a1 f9                  bl           #0x60004d80
  0x60003a3e: 01 f0 a1 f9                  bl           #0x60004d84
  0x60003a42: 00 f0 81 fd                  bl           #0x60004548
  0x60003a46: 00 f0 73 f8                  bl           #0x60003b30
  0x60003a4a: 1f 4b                        ldr          r3, [pc, #0x7c]
  0x60003a4c: 4f f4 44 62                  mov.w        r2, #0xc40
  0x60003a50: 1e 49                        ldr          r1, [pc, #0x78]
  0x60003a52: 18 68                        ldr          r0, [r3]
  0x60003a54: 02 f0 2d fe                  bl           #0x600066b2
  0x60003a58: 00 f0 88 f8                  bl           #0x60003b6c
  0x60003a5c: 04 46                        mov          r4, r0
  0x60003a5e: 1c 4a                        ldr          r2, [pc, #0x70]
  0x60003a60: 1c 49                        ldr          r1, [pc, #0x70]
  0x60003a62: 1d 48                        ldr          r0, [pc, #0x74]
  0x60003a64: 01 f0 b2 f9                  bl           #0x60004dcc
  0x60003a68: 00 f0 80 f8                  bl           #0x60003b6c
  0x60003a6c: 1b 49                        ldr          r1, [pc, #0x6c]
  0x60003a6e: 00 1b                        subs         r0, r0, r4
  0x60003a70: 1b 4a                        ldr          r2, [pc, #0x6c]
  0x60003a72: 00 23                        movs         r3, #0
  0x60003a74: a1 fb 00 01                  umull        r0, r1, r1, r0
  0x60003a78: 12 68                        ldr          r2, [r2]
  0x60003a7a: 1c 46                        mov          r4, r3
  0x60003a7c: 89 09                        lsrs         r1, r1, #6
  0x60003a7e: f2 ec 01 7a                  vldmia       r2!, {s15}
  0x60003a82: f4 ee c8 7a                  vcmpe.f32    s15, s16
  0x60003a86: f1 ee 10 fa                  vmrs         apsr_nzcv, fpscr
  0x60003a8a: 02 dd                        ble          #0x60003a92
  0x60003a8c: b0 ee 67 8a                  vmov.f32     s16, s15
  0x60003a90: 1c 46                        mov          r4, r3
  0x60003a92: 01 33                        adds         r3, #1
  0x60003a94: 0a 2b                        cmp          r3, #0xa
  0x60003a96: f2 d1                        bne          #0x60003a7e
  0x60003a98: 12 48                        ldr          r0, [pc, #0x48]
  0x60003a9a: fe f7 ff fe                  bl           #0x6000289c
  0x60003a9e: df ed 12 7a                  vldr         s15, [pc, #0x48]
  0x60003aa2: 12 48                        ldr          r0, [pc, #0x48]
  0x60003aa4: 28 ee 27 8a                  vmul.f32     s16, s16, s15
  0x60003aa8: fd ee c8 7a                  vcvt.s32.f32 s15, s16
  0x60003aac: 17 ee 90 1a                  vmov         r1, s15
  0x60003ab0: fe f7 f4 fe                  bl           #0x6000289c
  0x60003ab4: 21 46                        mov          r1, r4
  0x60003ab6: 0e 48                        ldr          r0, [pc, #0x38]
  0x60003ab8: fe f7 f0 fe                  bl           #0x6000289c
  0x60003abc: 00 20                        movs         r0, #0
  0x60003abe: bd ec 02 8b                  vpop         {d8}
  0x60003ac2: 10 bd                        pop          {r4, pc}

lenet_mnist @ 0x60004dcc:
  0x60004dcc: f0 b5                        push         {r4, r5, r6, r7, lr}
  0x60004dce: 81 b0                        sub          sp, #4
  0x60004dd0: 16 46                        mov          r6, r2
  0x60004dd2: 04 46                        mov          r4, r0
  0x60004dd4: 00 f1 c0 02                  add.w        r2, r0, #0xc0
  0x60004dd8: 30 46                        mov          r0, r6
  0x60004dda: 23 46                        mov          r3, r4
  0x60004ddc: 0d 46                        mov          r5, r1
  0x60004dde: 00 f0 21 f8                  bl           #0x60004e24
  0x60004de2: 06 f5 c4 47                  add.w        r7, r6, #0x6200
  0x60004de6: 30 46                        mov          r0, r6
  0x60004de8: 39 46                        mov          r1, r7
  0x60004dea: 00 f0 c1 fa                  bl           #0x60005370
  0x60004dee: 04 f5 80 62                  add.w        r2, r4, #0x400
  0x60004df2: 04 f1 40 03                  add.w        r3, r4, #0x40
  0x60004df6: 30 46                        mov          r0, r6
  0x60004df8: 39 46                        mov          r1, r7
  0x60004dfa: 00 f0 33 fc                  bl           #0x60005664
  0x60004dfe: 06 f5 44 57                  add.w        r7, r6, #0x3100
  0x60004e02: 30 46                        mov          r0, r6
  0x60004e04: 39 46                        mov          r1, r7
  0x60004e06: 01 f0 3f f8                  bl           #0x60005e88
  0x60004e0a: 05 f5 44 60                  add.w        r0, r5, #0xc40
  0x60004e0e: 04 f5 58 52                  add.w        r2, r4, #0x3600
  0x60004e12: 04 f1 80 03                  add.w        r3, r4, #0x80
  0x60004e16: 39 46                        mov          r1, r7
  0x60004e18: 01 f0 cc f9                  bl           #0x600061b4
  0x60004e1c: 00 20                        movs         r0, #0
  0x60004e1e: 01 b0                        add          sp, #4
  0x60004e20: f0 bd                        pop          {r4, r5, r6, r7, pc}

libjit_conv2d_f_0_specialized @ 0x60004e24:
  0x60004e24: 2d e9 f0 4f                  push.w       {r4, r5, r6, r7, r8, sb, sl, fp, lr}
  0x60004e28: 94 b0                        sub          sp, #0x50
  0x60004e2a: 4f f0 00 08                  mov.w        r8, #0
  0x60004e2e: 4f f0 1c 0c                  mov.w        ip, #0x1c
  0x60004e32: 4f f0 00 0e                  mov.w        lr, #0
  0x60004e36: 00 92                        str          r2, [sp]
  0x60004e38: 0a 91                        str          r1, [sp, #0x28]
  0x60004e3a: 00 bf                        nop          
  0x60004e3c: a8 fb 0c 65                  umull        r6, r5, r8, ip
  0x60004e40: 00 25                        movs         r5, #0
  0x60004e42: 00 24                        movs         r4, #0
  0x60004e44: a9 19                        adds         r1, r5, r6
  0x60004e46: 1f 68                        ldr          r7, [r3]
  0x60004e48: 49 01                        lsls         r1, r1, #5
  0x60004e4a: 47 50                        str          r7, [r0, r1]
  0x60004e4c: 5f 68                        ldr          r7, [r3, #4]
  0x60004e4e: 0a 1d                        adds         r2, r1, #4
  0x60004e50: 87 50                        str          r7, [r0, r2]
  0x60004e52: 9a 68                        ldr          r2, [r3, #8]
  0x60004e54: 01 f1 08 07                  add.w        r7, r1, #8
  0x60004e58: c2 51                        str          r2, [r0, r7]
  0x60004e5a: da 68                        ldr          r2, [r3, #0xc]
  0x60004e5c: 01 f1 0c 07                  add.w        r7, r1, #0xc
  0x60004e60: c2 51                        str          r2, [r0, r7]
  0x60004e62: 1a 69                        ldr          r2, [r3, #0x10]
  0x60004e64: 01 f1 10 07                  add.w        r7, r1, #0x10
  0x60004e68: c2 51                        str          r2, [r0, r7]
  0x60004e6a: 5a 69                        ldr          r2, [r3, #0x14]
  0x60004e6c: 01 f1 14 07                  add.w        r7, r1, #0x14
  0x60004e70: c2 51                        str          r2, [r0, r7]
  0x60004e72: 9a 69                        ldr          r2, [r3, #0x18]
  0x60004e74: 01 f1 18 07                  add.w        r7, r1, #0x18
  0x60004e78: c2 51                        str          r2, [r0, r7]
  0x60004e7a: da 69                        ldr          r2, [r3, #0x1c]
  0x60004e7c: 1c 31                        adds         r1, #0x1c
  0x60004e7e: 42 50                        str          r2, [r0, r1]
  0x60004e80: 45 f0 01 01                  orr          r1, r5, #1
  0x60004e84: 31 44                        add          r1, r6
  0x60004e86: 1a 68                        ldr          r2, [r3]
  0x60004e88: 49 01                        lsls         r1, r1, #5
  0x60004e8a: 42 50                        str          r2, [r0, r1]
  0x60004e8c: 5a 68                        ldr          r2, [r3, #4]
  0x60004e8e: 0f 1d                        adds         r7, r1, #4
  0x60004e90: c2 51                        str          r2, [r0, r7]
  0x60004e92: 9a 68                        ldr          r2, [r3, #8]
  0x60004e94: 01 f1 08 07                  add.w        r7, r1, #8
  0x60004e98: c2 51                        str          r2, [r0, r7]
  0x60004e9a: da 68                        ldr          r2, [r3, #0xc]
  0x60004e9c: 01 f1 0c 07                  add.w        r7, r1, #0xc
  0x60004ea0: c2 51                        str          r2, [r0, r7]
  0x60004ea2: 1a 69                        ldr          r2, [r3, #0x10]
  0x60004ea4: 01 f1 10 07                  add.w        r7, r1, #0x10
  0x60004ea8: c2 51                        str          r2, [r0, r7]
  0x60004eaa: 5a 69                        ldr          r2, [r3, #0x14]
  0x60004eac: 01 f1 14 07                  add.w        r7, r1, #0x14
  0x60004eb0: c2 51                        str          r2, [r0, r7]
  0x60004eb2: 9a 69                        ldr          r2, [r3, #0x18]
  0x60004eb4: 01 f1 18 07                  add.w        r7, r1, #0x18
  0x60004eb8: c2 51                        str          r2, [r0, r7]
  0x60004eba: da 69                        ldr          r2, [r3, #0x1c]
  0x60004ebc: 1c 31                        adds         r1, #0x1c
  0x60004ebe: 42 50                        str          r2, [r0, r1]
  0x60004ec0: 45 f0 02 01                  orr          r1, r5, #2
  0x60004ec4: 31 44                        add          r1, r6
  0x60004ec6: 1a 68                        ldr          r2, [r3]
  0x60004ec8: 49 01                        lsls         r1, r1, #5
  0x60004eca: 42 50                        str          r2, [r0, r1]
  0x60004ecc: 5a 68                        ldr          r2, [r3, #4]
  0x60004ece: 0f 1d                        adds         r7, r1, #4
  0x60004ed0: c2 51                        str          r2, [r0, r7]
... excerpt ends here ...
