Instructions decoded from the delivered ELF bytes.
Names/addresses from a debug companion are navigation aids only; the companion is not packaged.
Symbol locator: delivered ELF
Numeric indirect targets require their own analysis. Snippets can be intentionally truncated.


main @ 0x4011f0:
  0x4011f0: 41 54                        push         r12
  0x4011f2: 55                           push         rbp
  0x4011f3: 53                           push         rbx
  0x4011f4: 48 81 ec b0 40 09 00         sub          rsp, 0x940b0
  0x4011fb: 64 48 8b 04 25 28 00 00 00   mov          rax, qword ptr fs:[0x28]
  0x401204: 48 89 84 24 a8 40 09 00      mov          qword ptr [rsp + 0x940a8], rax
  0x40120c: 31 c0                        xor          eax, eax
  0x40120e: 83 ff 02                     cmp          edi, 2
  0x401211: 0f 85 6c 03 00 00            jne          0x401583
  0x401217: 48 89 f3                     mov          rbx, rsi
  0x40121a: 44 8b 25 3b ac 03 00         mov          r12d, dword ptr [rip + 0x3ac3b]
  0x401221: 48 8d 7c 24 10               lea          rdi, [rsp + 0x10]
  0x401226: 31 f6                        xor          esi, esi
  0x401228: e8 d3 fe ff ff               call         0x401100
  0x40122d: 48 8b 0b                     mov          rcx, qword ptr [rbx]
  0x401230: 48 8b 35 b1 1d 03 00         mov          rsi, qword ptr [rip + 0x31db1]
  0x401237: 48 c7 c7 40 31 43 00         mov          rdi, 0x433140
  0x40123e: 4c 89 e2                     mov          rdx, r12
  0x401241: e8 ca 05 00 00               call         0x401810
  0x401246: 48 8d 7c 24 20               lea          rdi, [rsp + 0x20]
  0x40124b: 31 f6                        xor          esi, esi
  0x40124d: 48 89 c5                     mov          rbp, rax
  0x401250: e8 ab fe ff ff               call         0x401100
  0x401255: 48 8b 7b 08                  mov          rdi, qword ptr [rbx + 8]
  0x401259: 48 8d 35 b2 cd 01 00         lea          rsi, [rip + 0x1cdb2]
  0x401260: 48 8d 9c 24 a0 10 00 00      lea          rbx, [rsp + 0x10a0]
  0x401268: e8 13 ff ff ff               call         0x401180
  0x40126d: ba 04 00 00 00               mov          edx, 4
  0x401272: be 00 4c 02 00               mov          esi, 0x24c00
  0x401277: 48 89 df                     mov          rdi, rbx
  0x40127a: 48 89 c1                     mov          rcx, rax
  0x40127d: 49 89 c4                     mov          r12, rax
  0x401280: e8 fb fd ff ff               call         0x401080
  0x401285: 4c 89 e7                     mov          rdi, r12
  0x401288: 41 bc ff ff ff ff            mov          r12d, 0xffffffff
  0x40128e: e8 fd fd ff ff               call         0x401090
  0x401293: 48 8d 54 24 70               lea          rdx, [rsp + 0x70]
  0x401298: 48 89 ef                     mov          rdi, rbp
  0x40129b: 48 b8 04 00 00 00 02 20 01 00 movabs       rax, 0x1200200000004
  0x4012a5: 48 89 84 24 80 00 00 00      mov          qword ptr [rsp + 0x80], rax
  0x4012ad: 48 8d 35 f2 ca 02 00         lea          rsi, [rip + 0x2caf2]
  0x4012b4: 48 8d 84 24 e0 00 00 00      lea          rax, [rsp + 0xe0]
  0x4012bc: 48 89 5c 24 70               mov          qword ptr [rsp + 0x70], rbx
  0x4012c1: 48 8d 9c 24 00 01 00 00      lea          rbx, [rsp + 0x100]
  0x4012c9: 48 89 84 24 88 00 00 00      mov          qword ptr [rsp + 0x88], rax
  0x4012d1: 48 c7 44 24 78 01 00 00 00   mov          qword ptr [rsp + 0x78], 1
  0x4012da: 48 c7 84 24 e0 00 00 00 01 00 00 00 mov          qword ptr [rsp + 0xe0], 1
  0x4012e6: 48 c7 84 24 e8 00 00 00 03 00 00 00 mov          qword ptr [rsp + 0xe8], 3
  0x4012f2: 48 c7 84 24 f0 00 00 00 e0 00 00 00 mov          qword ptr [rsp + 0xf0], 0xe0
  0x4012fe: 48 c7 84 24 f8 00 00 00 e0 00 00 00 mov          qword ptr [rsp + 0xf8], 0xe0
  0x40130a: 48 c7 84 24 90 00 00 00 00 00 00 00 mov          qword ptr [rsp + 0x90], 0
  0x401316: 48 c7 84 24 98 00 00 00 00 00 00 00 mov          qword ptr [rsp + 0x98], 0
  0x401322: e8 b9 03 00 00               call         0x4016e0
  0x401327: 31 f6                        xor          esi, esi
  0x401329: 48 8d 7c 24 30               lea          rdi, [rsp + 0x30]
  0x40132e: e8 cd fd ff ff               call         0x401100
  0x401333: 48 89 ef                     mov          rdi, rbp
  0x401336: e8 b5 03 00 00               call         0x4016f0
  0x40133b: 48 8d 7c 24 40               lea          rdi, [rsp + 0x40]
  0x401340: 31 f6                        xor          esi, esi
  0x401342: e8 b9 fd ff ff               call         0x401100
  0x401347: 48 8d 94 24 a0 00 00 00      lea          rdx, [rsp + 0xa0]
  0x40134f: 31 f6                        xor          esi, esi
  0x401351: 48 b8 02 00 00 00 02 20 01 00 movabs       rax, 0x1200200000002
  0x40135b: 48 89 84 24 b0 00 00 00      mov          qword ptr [rsp + 0xb0], rax
  0x401363: 48 89 ef                     mov          rdi, rbp
  0x401366: 48 8d 84 24 d0 00 00 00      lea          rax, [rsp + 0xd0]
  0x40136e: 48 89 84 24 b8 00 00 00      mov          qword ptr [rsp + 0xb8], rax
  0x401376: 48 89 9c 24 a0 00 00 00      mov          qword ptr [rsp + 0xa0], rbx
  0x40137e: 48 c7 84 24 a8 00 00 00 01 00 00 00 mov          qword ptr [rsp + 0xa8], 1
  0x40138a: 48 c7 84 24 d0 00 00 00 01 00 00 00 mov          qword ptr [rsp + 0xd0], 1
  0x401396: 48 c7 84 24 d8 00 00 00 e8 03 00 00 mov          qword ptr [rsp + 0xd8], 0x3e8
  0x4013a2: 48 c7 84 24 c0 00 00 00 00 00 00 00 mov          qword ptr [rsp + 0xc0], 0
  0x4013ae: 48 c7 84 24 c8 00 00 00 00 00 00 00 mov          qword ptr [rsp + 0xc8], 0
  0x4013ba: e8 41 03 00 00               call         0x401700
  0x4013bf: 48 8d 7c 24 50               lea          rdi, [rsp + 0x50]
  0x4013c4: 31 f6                        xor          esi, esi
  0x4013c6: e8 35 fd ff ff               call         0x401100
  0x4013cb: f3 0f 10 05 29 cd 01 00      movss        xmm0, dword ptr [rip + 0x1cd29]
  0x4013d3: 31 c0                        xor          eax, eax
  0x4013d5: 0f 1f 00                     nop          dword ptr [rax]
  0x4013d8: f3 0f 10 0c 83               movss        xmm1, dword ptr [rbx + rax*4]
  0x4013dd: 0f 2f c8                     comiss       xmm1, xmm0
  0x4013e0: f3 0f 5f c8                  maxss        xmm1, xmm0
  0x4013e4: 44 0f 47 e0                  cmova        r12d, eax
  0x4013e8: 48 83 c0 01                  add          rax, 1
  0x4013ec: 0f 28 c1                     movaps       xmm0, xmm1
  0x4013ef: 48 3d e8 03 00 00            cmp          rax, 0x3e8
  0x4013f5: 75 e1                        jne          0x4013d8
  0x4013f7: 48 89 ef                     mov          rdi, rbp
  0x4013fa: f3 0f 11 4c 24 0c            movss        dword ptr [rsp + 0xc], xmm1
  0x401400: e8 9b 02 00 00               call         0x4016a0
  0x401405: 31 f6                        xor          esi, esi
  0x401407: 48 8d 7c 24 60               lea          rdi, [rsp + 0x60]
  0x40140c: e8 ef fc ff ff               call         0x401100
  0x401411: f3 0f 10 44 24 0c            movss        xmm0, dword ptr [rsp + 0xc]
  0x401417: 44 89 e2                     mov          edx, r12d
  0x40141a: 48 8d 35 27 cc 01 00         lea          rsi, [rip + 0x1cc27]
  0x401421: bf 01 00 00 00               mov          edi, 1
  0x401426: b8 01 00 00 00               mov          eax, 1
  0x40142b: f3 0f 5a c0                  cvtss2sd     xmm0, xmm0
  0x40142f: e8 3c fd ff ff               call         0x401170
  0x401434: 4c 8b 4c 24 50               mov          r9, qword ptr [rsp + 0x50]
  0x401439: 4c 8b 5c 24 60               mov          r11, qword ptr [rsp + 0x60]
  0x40143e: 66 0f ef c0                  pxor         xmm0, xmm0
  0x401442: 66 0f ef e4                  pxor         xmm4, xmm4
  0x401446: 4c 8b 44 24 58               mov          r8, qword ptr [rsp + 0x58]
  0x40144b: f3 0f 10 35 ad cc 01 00      movss        xmm6, dword ptr [rip + 0x1ccad]
  0x401453: 4d 29 cb                     sub          r11, r9
  0x401456: 48 8b 7c 24 48               mov          rdi, qword ptr [rsp + 0x48]
  0x40145b: 66 0f ef db                  pxor         xmm3, xmm3
  0x40145f: 66 0f ef d2                  pxor         xmm2, xmm2
  0x401463: 4d 69 db e8 03 00 00         imul         r11, r11, 0x3e8
  0x40146a: 48 8b 4c 24 40               mov          rcx, qword ptr [rsp + 0x40]
  0x40146f: 4c 8b 54 24 38               mov          r10, qword ptr [rsp + 0x38]
  0x401474: 66 0f ef c9                  pxor         xmm1, xmm1
  0x401478: 48 8b 54 24 30               mov          rdx, qword ptr [rsp + 0x30]
  0x40147d: 48 8b 44 24 20               mov          rax, qword ptr [rsp + 0x20]
  0x401482: 66 0f ef ed                  pxor         xmm5, xmm5
  0x401486: 49 29 c9                     sub          r9, rcx
  0x401489: 48 8b 74 24 28               mov          rsi, qword ptr [rsp + 0x28]
  0x40148e: f3 49 0f 2a c3               cvtsi2ss     xmm0, r11
  0x401493: 4c 8b 5c 24 68               mov          r11, qword ptr [rsp + 0x68]
  0x401498: 48 29 d1                     sub          rcx, rdx
  0x40149b: 48 29 c2                     sub          rdx, rax
  0x40149e: 4d 69 c9 e8 03 00 00         imul         r9, r9, 0x3e8
  0x4014a5: 48 2b 44 24 10               sub          rax, qword ptr [rsp + 0x10]
  0x4014aa: 4d 29 c3                     sub          r11, r8
  0x4014ad: 49 29 f8                     sub          r8, rdi
  0x4014b0: 4c 29 d7                     sub          rdi, r10
  0x4014b3: f3 49 0f 2a e3               cvtsi2ss     xmm4, r11
  0x4014b8: f3 49 0f 2a d8               cvtsi2ss     xmm3, r8
  0x4014bd: 48 69 c9 e8 03 00 00         imul         rcx, rcx, 0x3e8
  0x4014c4: 48 69 d2 e8 03 00 00         imul         rdx, rdx, 0x3e8
  0x4014cb: f3 0f 5e e6                  divss        xmm4, xmm6
  0x4014cf: 48 69 c0 e8 03 00 00         imul         rax, rax, 0x3e8
  0x4014d6: f3 48 0f 2a d1               cvtsi2ss     xmm2, rcx
  0x4014db: f3 48 0f 2a ca               cvtsi2ss     xmm1, rdx
  0x4014e0: 4c 89 d2                     mov          rdx, r10
  0x4014e3: 48 29 f2                     sub          rdx, rsi
  0x4014e6: 48 2b 74 24 18               sub          rsi, qword ptr [rsp + 0x18]
  0x4014eb: f3 48 0f 2a ee               cvtsi2ss     xmm5, rsi
  0x4014f0: 48 8d 35 99 cb 01 00         lea          rsi, [rip + 0x1cb99]
  0x4014f7: f3 0f 5e de                  divss        xmm3, xmm6
  0x4014fb: f3 0f 58 e0                  addss        xmm4, xmm0
  0x4014ff: 66 0f ef c0                  pxor         xmm0, xmm0
  0x401503: f3 49 0f 2a c1               cvtsi2ss     xmm0, r9
  0x401508: f3 0f 5a e4                  cvtss2sd     xmm4, xmm4
  0x40150c: f3 0f 5e ee                  divss        xmm5, xmm6
  0x401510: f3 0f 58 d8                  addss        xmm3, xmm0
  0x401514: 66 0f ef c0                  pxor         xmm0, xmm0
  0x401518: f3 48 0f 2a c7               cvtsi2ss     xmm0, rdi
  0x40151d: bf 01 00 00 00               mov          edi, 1
  0x401522: f3 0f 5a db                  cvtss2sd     xmm3, xmm3
  0x401526: f3 0f 5e c6                  divss        xmm0, xmm6
  0x40152a: f3 0f 58 d0                  addss        xmm2, xmm0
  0x40152e: 66 0f ef c0                  pxor         xmm0, xmm0
  0x401532: f3 48 0f 2a c2               cvtsi2ss     xmm0, rdx
  0x401537: f3 0f 5a d2                  cvtss2sd     xmm2, xmm2
  0x40153b: f3 0f 5e c6                  divss        xmm0, xmm6
  0x40153f: f3 0f 58 c8                  addss        xmm1, xmm0
  0x401543: 66 0f ef c0                  pxor         xmm0, xmm0
  0x401547: f3 48 0f 2a c0               cvtsi2ss     xmm0, rax
  0x40154c: b8 05 00 00 00               mov          eax, 5
  0x401551: f3 0f 5a c9                  cvtss2sd     xmm1, xmm1
  0x401555: f3 0f 58 c5                  addss        xmm0, xmm5
  0x401559: f3 0f 5a c0                  cvtss2sd     xmm0, xmm0
  0x40155d: e8 0e fc ff ff               call         0x401170
  0x401562: 48 8b 84 24 a8 40 09 00      mov          rax, qword ptr [rsp + 0x940a8]
  0x40156a: 64 48 33 04 25 28 00 00 00   xor          rax, qword ptr fs:[0x28]
  0x401573: 75 2d                        jne          0x4015a2
  0x401575: 48 81 c4 b0 40 09 00         add          rsp, 0x940b0
  0x40157c: 31 c0                        xor          eax, eax
  0x40157e: 5b                           pop          rbx
  0x40157f: 5d                           pop          rbp
  0x401580: 41 5c                        pop          r12
  0x401582: c3                           ret          
  0x401583: 48 8d 0d 6d cb 01 00         lea          rcx, [rip + 0x1cb6d]
  0x40158a: ba 13 00 00 00               mov          edx, 0x13
  0x40158f: 48 8d 35 6e ca 01 00         lea          rsi, [rip + 0x1ca6e]
  0x401596: 48 8d 3d 7b ca 01 00         lea          rdi, [rip + 0x1ca7b]
  0x40159d: e8 6e fb ff ff               call         0x401110
  0x4015a2: e8 19 fb ff ff               call         0x4010c0

TVMGraphExecutor_Run @ 0x419bc0:
  0x419bc0: 8b 87 c0 00 00 00            mov          eax, dword ptr [rdi + 0xc0]
  0x419bc6: 85 c0                        test         eax, eax
  0x419bc8: 74 4e                        je           0x419c18
  0x419bca: 55                           push         rbp
  0x419bcb: 48 89 fd                     mov          rbp, rdi
  0x419bce: 53                           push         rbx
  0x419bcf: 31 db                        xor          ebx, ebx
  0x419bd1: 48 83 ec 08                  sub          rsp, 8
  0x419bd5: 0f 1f 00                     nop          dword ptr [rax]
  0x419bd8: 89 da                        mov          edx, ebx
  0x419bda: 48 89 d0                     mov          rax, rdx
  0x419bdd: 48 c1 e0 04                  shl          rax, 4
  0x419be1: 48 29 d0                     sub          rax, rdx
  0x419be4: 48 c1 e0 05                  shl          rax, 5
  0x419be8: 48 03 85 b8 00 00 00         add          rax, qword ptr [rbp + 0xb8]
  0x419bef: 48 83 b8 c8 00 00 00 00      cmp          qword ptr [rax + 0xc8], 0
  0x419bf7: 74 09                        je           0x419c02
  0x419bf9: 48 89 c7                     mov          rdi, rax
  0x419bfc: ff 90 d0 01 00 00            call         qword ptr [rax + 0x1d0]
  0x419c02: 83 c3 01                     add          ebx, 1
  0x419c05: 39 9d c0 00 00 00            cmp          dword ptr [rbp + 0xc0], ebx
  0x419c0b: 77 cb                        ja           0x419bd8
  0x419c0d: 48 83 c4 08                  add          rsp, 8
  0x419c11: 5b                           pop          rbx
  0x419c12: 5d                           pop          rbp
  0x419c13: c3                           ret          
  0x419c14: 0f 1f 40 00                  nop          dword ptr [rax]
  0x419c18: c3                           ret          

tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu @ 0x404730:
  0x404730: 55                           push         rbp
  0x404731: 41 57                        push         r15
  0x404733: 41 56                        push         r14
  0x404735: 41 55                        push         r13
  0x404737: 41 54                        push         r12
  0x404739: 53                           push         rbx
  0x40473a: 48 83 ec 18                  sub          rsp, 0x18
  0x40473e: 83 fa 04                     cmp          edx, 4
  0x404741: 0f 85 f1 03 00 00            jne          0x404b38
  0x404747: 8b 06                        mov          eax, dword ptr [rsi]
  0x404749: 83 f8 0d                     cmp          eax, 0xd
  0x40474c: 0f 87 90 03 00 00            ja           0x404ae2
  0x404752: b9 98 20 00 00               mov          ecx, 0x2098
  0x404757: 0f a3 c1                     bt           ecx, eax
  0x40475a: 0f 83 82 03 00 00            jae          0x404ae2
  0x404760: 8b 46 04                     mov          eax, dword ptr [rsi + 4]
  0x404763: 83 f8 0d                     cmp          eax, 0xd
  0x404766: 0f 87 7f 03 00 00            ja           0x404aeb
  0x40476c: b9 98 20 00 00               mov          ecx, 0x2098
  0x404771: 0f a3 c1                     bt           ecx, eax
  0x404774: 0f 83 71 03 00 00            jae          0x404aeb
  0x40477a: 8b 46 08                     mov          eax, dword ptr [rsi + 8]
  0x40477d: 83 f8 0d                     cmp          eax, 0xd
  0x404780: 0f 87 6e 03 00 00            ja           0x404af4
  0x404786: b9 98 20 00 00               mov          ecx, 0x2098
  0x40478b: 0f a3 c1                     bt           ecx, eax
  0x40478e: 0f 83 60 03 00 00            jae          0x404af4
  0x404794: 8b 46 0c                     mov          eax, dword ptr [rsi + 0xc]
  0x404797: 83 f8 0d                     cmp          eax, 0xd
  0x40479a: 0f 87 5d 03 00 00            ja           0x404afd
  0x4047a0: b9 98 20 00 00               mov          ecx, 0x2098
  0x4047a5: 0f a3 c1                     bt           ecx, eax
  0x4047a8: 0f 83 4f 03 00 00            jae          0x404afd
  0x4047ae: 48 8b 07                     mov          rax, qword ptr [rdi]
  0x4047b1: 83 78 10 05                  cmp          dword ptr [rax + 0x10], 5
  0x4047b5: 0f 85 98 03 00 00            jne          0x404b53
  0x4047bb: 66 83 78 16 01               cmp          word ptr [rax + 0x16], 1
  0x4047c0: 0f 85 57 03 00 00            jne          0x404b1d
  0x4047c6: 80 78 15 20                  cmp          byte ptr [rax + 0x15], 0x20
  0x4047ca: 0f 85 4d 03 00 00            jne          0x404b1d
  0x4047d0: 80 78 14 02                  cmp          byte ptr [rax + 0x14], 2
  0x4047d4: 0f 85 43 03 00 00            jne          0x404b1d
  0x4047da: 48 8b 48 18                  mov          rcx, qword ptr [rax + 0x18]
  0x4047de: 83 39 01                     cmp          dword ptr [rcx], 1
  0x4047e1: 0f 85 75 03 00 00            jne          0x404b5c
  0x4047e7: 83 79 08 01                  cmp          dword ptr [rcx + 8], 1
  0x4047eb: 0f 85 50 03 00 00            jne          0x404b41
  0x4047f1: 81 79 10 e0 00 00 00         cmp          dword ptr [rcx + 0x10], 0xe0
  0x4047f8: 0f 85 70 03 00 00            jne          0x404b6e
  0x4047fe: 81 79 18 e0 00 00 00         cmp          dword ptr [rcx + 0x18], 0xe0
  0x404805: 0f 85 6c 03 00 00            jne          0x404b77
  0x40480b: 83 79 20 03                  cmp          dword ptr [rcx + 0x20], 3
  0x40480f: 0f 85 35 03 00 00            jne          0x404b4a
  0x404815: 48 8b 5f 08                  mov          rbx, qword ptr [rdi + 8]
  0x404819: 4c 8b 6f 10                  mov          r13, qword ptr [rdi + 0x10]
  0x40481d: 4c 8b 5f 18                  mov          r11, qword ptr [rdi + 0x18]
  0x404821: 48 8b 08                     mov          rcx, qword ptr [rax]
  0x404824: 48 89 4c 24 10               mov          qword ptr [rsp + 0x10], rcx
  0x404829: 4c 8b 48 20                  mov          r9, qword ptr [rax + 0x20]
  0x40482d: 44 8b 40 0c                  mov          r8d, dword ptr [rax + 0xc]
  0x404831: 48 8b 0b                     mov          rcx, qword ptr [rbx]
  0x404834: 48 89 4c 24 08               mov          qword ptr [rsp + 8], rcx
  0x404839: 48 8b 6b 18                  mov          rbp, qword ptr [rbx + 0x18]
  0x40483d: 4c 8b 63 20                  mov          r12, qword ptr [rbx + 0x20]
  0x404841: 49 8b 4d 00                  mov          rcx, qword ptr [r13]
  0x404845: 4d 8b 7d 18                  mov          r15, qword ptr [r13 + 0x18]
  0x404849: 4d 8b 75 20                  mov          r14, qword ptr [r13 + 0x20]
  0x40484d: 49 8b 13                     mov          rdx, qword ptr [r11]
  0x404850: 4d 8b 53 18                  mov          r10, qword ptr [r11 + 0x18]
  0x404854: 49 8b 73 20                  mov          rsi, qword ptr [r11 + 0x20]
  0x404858: 4d 85 c9                     test         r9, r9
  0x40485b: 74 2d                        je           0x40488a
  0x40485d: 41 0f 10 01                  movups       xmm0, xmmword ptr [r9]
  0x404861: 41 0f 10 49 10               movups       xmm1, xmmword ptr [r9 + 0x10]
  0x404866: 0f c6 c1 88                  shufps       xmm0, xmm1, 0x88
  0x40486a: 66 0f 76 05 5e 9f 01 00      pcmpeqd      xmm0, xmmword ptr [rip + 0x19f5e]
  0x404872: 0f 50 f8                     movmskps     edi, xmm0
  0x404875: 40 80 ff 0f                  cmp          dil, 0xf
  0x404879: 0f 85 01 03 00 00            jne          0x404b80
  0x40487f: 41 83 79 20 01               cmp          dword ptr [r9 + 0x20], 1
  0x404884: 0f 85 f6 02 00 00            jne          0x404b80
  0x40488a: 48 83 78 28 00               cmp          qword ptr [rax + 0x28], 0
  0x40488f: 0f 85 91 02 00 00            jne          0x404b26
  0x404895: 83 78 08 01                  cmp          dword ptr [rax + 8], 1
  0x404899: 0f 85 90 02 00 00            jne          0x404b2f
  0x40489f: 83 7b 10 06                  cmp          dword ptr [rbx + 0x10], 6
  0x4048a3: 0f 85 e3 02 00 00            jne          0x404b8c
  0x4048a9: 66 83 7b 16 01               cmp          word ptr [rbx + 0x16], 1
  0x4048ae: 0f 85 69 02 00 00            jne          0x404b1d
  0x4048b4: 80 7b 15 20                  cmp          byte ptr [rbx + 0x15], 0x20
  0x4048b8: 0f 85 5f 02 00 00            jne          0x404b1d
  0x4048be: 80 7b 14 02                  cmp          byte ptr [rbx + 0x14], 2
  0x4048c2: 0f 85 55 02 00 00            jne          0x404b1d
  0x4048c8: 83 7d 00 10                  cmp          dword ptr [rbp], 0x10
  0x4048cc: 0f 85 c6 02 00 00            jne          0x404b98
  0x4048d2: 83 7d 08 01                  cmp          dword ptr [rbp + 8], 1
  0x4048d6: 0f 85 65 02 00 00            jne          0x404b41
  0x4048dc: 83 7d 10 03                  cmp          dword ptr [rbp + 0x10], 3
  0x4048e0: 0f 85 be 02 00 00            jne          0x404ba4
  0x4048e6: 83 7d 18 03                  cmp          dword ptr [rbp + 0x18], 3
  0x4048ea: 0f 85 c0 02 00 00            jne          0x404bb0
  0x4048f0: 83 7d 20 03                  cmp          dword ptr [rbp + 0x20], 3
  0x4048f4: 0f 85 50 02 00 00            jne          0x404b4a
  0x4048fa: 83 7d 28 04                  cmp          dword ptr [rbp + 0x28], 4
  0x4048fe: 0f 85 b8 02 00 00            jne          0x404bbc
  0x404904: 4d 85 e4                     test         r12, r12
  0x404907: 74 3a                        je           0x404943
  0x404909: 41 0f 10 04 24               movups       xmm0, xmmword ptr [r12]
  0x40490e: 41 0f 10 4c 24 10            movups       xmm1, xmmword ptr [r12 + 0x10]
  0x404914: 0f c6 c1 88                  shufps       xmm0, xmm1, 0x88
  0x404918: 66 0f 76 05 f0 9e 01 00      pcmpeqd      xmm0, xmmword ptr [rip + 0x19ef0]
  0x404920: 0f 50 c0                     movmskps     eax, xmm0
  0x404923: 3c 0f                        cmp          al, 0xf
  0x404925: 0f 85 9d 02 00 00            jne          0x404bc8
  0x40492b: 41 83 7c 24 20 04            cmp          dword ptr [r12 + 0x20], 4
  0x404931: 0f 85 91 02 00 00            jne          0x404bc8
  0x404937: 41 83 7c 24 28 01            cmp          dword ptr [r12 + 0x28], 1
  0x40493d: 0f 85 85 02 00 00            jne          0x404bc8
  0x404943: 48 83 7b 28 00               cmp          qword ptr [rbx + 0x28], 0
  0x404948: 0f 85 d8 01 00 00            jne          0x404b26
  0x40494e: 83 7b 08 01                  cmp          dword ptr [rbx + 8], 1
  0x404952: 0f 85 d7 01 00 00            jne          0x404b2f
  0x404958: 44 3b 43 0c                  cmp          r8d, dword ptr [rbx + 0xc]
  0x40495c: 0f 85 03 02 00 00            jne          0x404b65
  0x404962: 41 83 7d 10 05               cmp          dword ptr [r13 + 0x10], 5
  0x404967: 0f 85 e6 01 00 00            jne          0x404b53
  0x40496d: 66 41 83 7d 16 01            cmp          word ptr [r13 + 0x16], 1
  0x404973: 0f 85 a4 01 00 00            jne          0x404b1d
  0x404979: 41 80 7d 15 20               cmp          byte ptr [r13 + 0x15], 0x20
  0x40497e: 0f 85 99 01 00 00            jne          0x404b1d
  0x404984: 41 80 7d 14 02               cmp          byte ptr [r13 + 0x14], 2
  0x404989: 0f 85 8e 01 00 00            jne          0x404b1d
  0x40498f: 41 83 3f 01                  cmp          dword ptr [r15], 1
  0x404993: 0f 85 c3 01 00 00            jne          0x404b5c
  0x404999: 41 83 7f 08 10               cmp          dword ptr [r15 + 8], 0x10
  0x40499e: 0f 85 30 02 00 00            jne          0x404bd4
  0x4049a4: 41 83 7f 10 01               cmp          dword ptr [r15 + 0x10], 1
  0x4049a9: 0f 85 31 02 00 00            jne          0x404be0
  0x4049af: 41 83 7f 18 01               cmp          dword ptr [r15 + 0x18], 1
  0x4049b4: 0f 85 32 02 00 00            jne          0x404bec
  0x4049ba: 41 83 7f 20 04               cmp          dword ptr [r15 + 0x20], 4
  0x4049bf: 0f 85 33 02 00 00            jne          0x404bf8
  0x4049c5: 4d 85 f6                     test         r14, r14
  0x4049c8: 74 2b                        je           0x4049f5
  0x4049ca: 41 0f 10 06                  movups       xmm0, xmmword ptr [r14]
  0x4049ce: 41 0f 10 4e 10               movups       xmm1, xmmword ptr [r14 + 0x10]
  0x4049d3: 0f c6 c1 88                  shufps       xmm0, xmm1, 0x88
  0x4049d7: 66 0f 76 05 41 9e 01 00      pcmpeqd      xmm0, xmmword ptr [rip + 0x19e41]
  0x4049df: 0f 50 c0                     movmskps     eax, xmm0
  0x4049e2: 3c 0f                        cmp          al, 0xf
  0x4049e4: 0f 85 1a 02 00 00            jne          0x404c04
  0x4049ea: 41 83 7e 20 01               cmp          dword ptr [r14 + 0x20], 1
  0x4049ef: 0f 85 0f 02 00 00            jne          0x404c04
  0x4049f5: 49 83 7d 28 00               cmp          qword ptr [r13 + 0x28], 0
  0x4049fa: 0f 85 26 01 00 00            jne          0x404b26
  0x404a00: 41 83 7d 08 01               cmp          dword ptr [r13 + 8], 1
  0x404a05: 0f 85 24 01 00 00            jne          0x404b2f
  0x404a0b: 45 3b 45 0c                  cmp          r8d, dword ptr [r13 + 0xc]
  0x404a0f: 0f 85 50 01 00 00            jne          0x404b65
  0x404a15: 41 83 7b 10 05               cmp          dword ptr [r11 + 0x10], 5
  0x404a1a: 0f 85 f0 01 00 00            jne          0x404c10
  0x404a20: 66 41 83 7b 16 01            cmp          word ptr [r11 + 0x16], 1
  0x404a26: 0f 85 f0 01 00 00            jne          0x404c1c
  0x404a2c: 41 80 7b 15 20               cmp          byte ptr [r11 + 0x15], 0x20
  0x404a31: 0f 85 e5 01 00 00            jne          0x404c1c
  0x404a37: 41 80 7b 14 02               cmp          byte ptr [r11 + 0x14], 2
  0x404a3c: 0f 85 da 01 00 00            jne          0x404c1c
  0x404a42: 41 83 3a 01                  cmp          dword ptr [r10], 1
  0x404a46: 0f 85 dc 01 00 00            jne          0x404c28
  0x404a4c: 41 83 7a 08 10               cmp          dword ptr [r10 + 8], 0x10
  0x404a51: 0f 85 dd 01 00 00            jne          0x404c34
  0x404a57: 41 83 7a 10 6f               cmp          dword ptr [r10 + 0x10], 0x6f
  0x404a5c: 0f 85 de 01 00 00            jne          0x404c40
  0x404a62: 41 83 7a 18 6f               cmp          dword ptr [r10 + 0x18], 0x6f
  0x404a67: 0f 85 df 01 00 00            jne          0x404c4c
  0x404a6d: 41 83 7a 20 04               cmp          dword ptr [r10 + 0x20], 4
  0x404a72: 0f 85 e0 01 00 00            jne          0x404c58
  0x404a78: 48 85 f6                     test         rsi, rsi
  0x404a7b: 74 28                        je           0x404aa5
  0x404a7d: 0f 10 06                     movups       xmm0, xmmword ptr [rsi]
  0x404a80: 0f 10 4e 10                  movups       xmm1, xmmword ptr [rsi + 0x10]
  0x404a84: 0f c6 c1 88                  shufps       xmm0, xmm1, 0x88
  0x404a88: 66 0f 76 05 a0 9d 01 00      pcmpeqd      xmm0, xmmword ptr [rip + 0x19da0]
  0x404a90: 0f 50 c0                     movmskps     eax, xmm0
  0x404a93: 3c 0f                        cmp          al, 0xf
  0x404a95: 0f 85 c9 01 00 00            jne          0x404c64
  0x404a9b: 83 7e 20 01                  cmp          dword ptr [rsi + 0x20], 1
  0x404a9f: 0f 85 bf 01 00 00            jne          0x404c64
  0x404aa5: 49 83 7b 28 00               cmp          qword ptr [r11 + 0x28], 0
  0x404aaa: 0f 85 c0 01 00 00            jne          0x404c70
  0x404ab0: 41 83 7b 08 01               cmp          dword ptr [r11 + 8], 1
  0x404ab5: 0f 85 c1 01 00 00            jne          0x404c7c
  0x404abb: 45 3b 43 0c                  cmp          r8d, dword ptr [r11 + 0xc]
  0x404abf: 0f 85 c3 01 00 00            jne          0x404c88
  0x404ac5: 48 8b 7c 24 10               mov          rdi, qword ptr [rsp + 0x10]
  0x404aca: 48 8b 74 24 08               mov          rsi, qword ptr [rsp + 8]
  0x404acf: 48 83 c4 18                  add          rsp, 0x18
  0x404ad3: 5b                           pop          rbx
  0x404ad4: 41 5c                        pop          r12
  0x404ad6: 41 5d                        pop          r13
  0x404ad8: 41 5e                        pop          r14
  0x404ada: 41 5f                        pop          r15
  0x404adc: 5d                           pop          rbp
  0x404add: e9 be 01 00 00               jmp          0x404ca0
  0x404ae2: 48 8d 3d 99 ea 01 00         lea          rdi, [rip + 0x1ea99]
  0x404ae9: eb 19                        jmp          0x404b04
  0x404aeb: 48 8d 3d 74 eb 01 00         lea          rdi, [rip + 0x1eb74]
  0x404af2: eb 10                        jmp          0x404b04
  0x404af4: 48 8d 3d 4f ec 01 00         lea          rdi, [rip + 0x1ec4f]
  0x404afb: eb 07                        jmp          0x404b04
  0x404afd: 48 8d 3d 2a ed 01 00         lea          rdi, [rip + 0x1ed2a]
  0x404b04: e8 17 72 01 00               call         0x41bd20
  0x404b09: b8 ff ff ff ff               mov          eax, 0xffffffff
  0x404b0e: 48 83 c4 18                  add          rsp, 0x18
  0x404b12: 5b                           pop          rbx
  0x404b13: 41 5c                        pop          r12
  0x404b15: 41 5d                        pop          r13
  0x404b17: 41 5e                        pop          r14
  0x404b19: 41 5f                        pop          r15
  0x404b1b: 5d                           pop          rbp
  0x404b1c: c3                           ret          
  0x404b1d: 48 8d 3d 94 a1 01 00         lea          rdi, [rip + 0x1a194]
  0x404b24: eb de                        jmp          0x404b04
  0x404b26: 48 8d 3d c4 a6 01 00         lea          rdi, [rip + 0x1a6c4]
  0x404b2d: eb d5                        jmp          0x404b04
  0x404b2f: 48 8d 3d 7f a7 01 00         lea          rdi, [rip + 0x1a77f]
  0x404b36: eb cc                        jmp          0x404b04
  0x404b38: 48 8d 3d d6 e9 01 00         lea          rdi, [rip + 0x1e9d6]
  0x404b3f: eb c3                        jmp          0x404b04
  0x404b41: 48 8d 3d b6 ed 01 00         lea          rdi, [rip + 0x1edb6]
  0x404b48: eb ba                        jmp          0x404b04
  0x404b4a: 48 8d 3d 4a ee 01 00         lea          rdi, [rip + 0x1ee4a]
  0x404b51: eb b1                        jmp          0x404b04
  0x404b53: 48 8d 3d f3 a0 01 00         lea          rdi, [rip + 0x1a0f3]
  0x404b5a: eb a8                        jmp          0x404b04
  0x404b5c: 48 8d 3d 47 a2 01 00         lea          rdi, [rip + 0x1a247]
  0x404b63: eb 9f                        jmp          0x404b04
  0x404b65: 48 8d 3d ff a7 01 00         lea          rdi, [rip + 0x1a7ff]
  0x404b6c: eb 96                        jmp          0x404b04
  0x404b6e: 48 8d 3d 9b ca 01 00         lea          rdi, [rip + 0x1ca9b]
  0x404b75: eb 8d                        jmp          0x404b04
  0x404b77: 48 8d 3d 33 cb 01 00         lea          rdi, [rip + 0x1cb33]
  0x404b7e: eb 84                        jmp          0x404b04
  0x404b80: 48 8d 3d b1 ee 01 00         lea          rdi, [rip + 0x1eeb1]
  0x404b87: e9 78 ff ff ff               jmp          0x404b04
  0x404b8c: 48 8d 3d d6 ef 01 00         lea          rdi, [rip + 0x1efd6]
  0x404b93: e9 6c ff ff ff               jmp          0x404b04
  0x404b98: 48 8d 3d 35 f0 01 00         lea          rdi, [rip + 0x1f035]
  0x404b9f: e9 60 ff ff ff               jmp          0x404b04
  0x404ba4: 48 8d 3d c8 f0 01 00         lea          rdi, [rip + 0x1f0c8]
  0x404bab: e9 54 ff ff ff               jmp          0x404b04
  0x404bb0: 48 8d 3d 59 f1 01 00         lea          rdi, [rip + 0x1f159]
  0x404bb7: e9 48 ff ff ff               jmp          0x404b04
  0x404bbc: 48 8d 3d ea f1 01 00         lea          rdi, [rip + 0x1f1ea]
  0x404bc3: e9 3c ff ff ff               jmp          0x404b04
  0x404bc8: 48 8d 3d 7b f2 01 00         lea          rdi, [rip + 0x1f27b]
  0x404bcf: e9 30 ff ff ff               jmp          0x404b04
  0x404bd4: 48 8d 3d 6c a2 01 00         lea          rdi, [rip + 0x1a26c]
  0x404bdb: e9 24 ff ff ff               jmp          0x404b04
  0x404be0: 48 8d 3d 63 d7 01 00         lea          rdi, [rip + 0x1d763]
  0x404be7: e9 18 ff ff ff               jmp          0x404b04
  0x404bec: 48 8d 3d f4 d7 01 00         lea          rdi, [rip + 0x1d7f4]
  0x404bf3: e9 0c ff ff ff               jmp          0x404b04
  0x404bf8: 48 8d 3d 25 a4 01 00         lea          rdi, [rip + 0x1a425]
  0x404bff: e9 00 ff ff ff               jmp          0x404b04
  0x404c04: 48 8d 3d 98 f3 01 00         lea          rdi, [rip + 0x1f398]
  0x404c0b: e9 f4 fe ff ff               jmp          0x404b04
  0x404c10: 48 8d 3d b2 f4 01 00         lea          rdi, [rip + 0x1f4b2]
  0x404c17: e9 e8 fe ff ff               jmp          0x404b04
  0x404c1c: 48 8d 3d 07 f5 01 00         lea          rdi, [rip + 0x1f507]
  0x404c23: e9 dc fe ff ff               jmp          0x404b04
  0x404c28: 48 8d 3d d9 f5 01 00         lea          rdi, [rip + 0x1f5d9]
  0x404c2f: e9 d0 fe ff ff               jmp          0x404b04
  0x404c34: 48 8d 3d 5b f6 01 00         lea          rdi, [rip + 0x1f65b]
  0x404c3b: e9 c4 fe ff ff               jmp          0x404b04
  0x404c40: 48 8d 3d df f6 01 00         lea          rdi, [rip + 0x1f6df]
  0x404c47: e9 b8 fe ff ff               jmp          0x404b04
  0x404c4c: 48 8d 3d 65 f7 01 00         lea          rdi, [rip + 0x1f765]
  0x404c53: e9 ac fe ff ff               jmp          0x404b04
  0x404c58: 48 8d 3d eb f7 01 00         lea          rdi, [rip + 0x1f7eb]
  0x404c5f: e9 a0 fe ff ff               jmp          0x404b04
  0x404c64: 48 8d 3d 6d f8 01 00         lea          rdi, [rip + 0x1f86d]
  0x404c6b: e9 94 fe ff ff               jmp          0x404b04
  0x404c70: 48 8d 3d 73 f9 01 00         lea          rdi, [rip + 0x1f973]
  0x404c77: e9 88 fe ff ff               jmp          0x404b04
  0x404c7c: 48 8d 3d 1c fa 01 00         lea          rdi, [rip + 0x1fa1c]
  0x404c83: e9 7c fe ff ff               jmp          0x404b04
  0x404c88: 48 8d 3d b7 fa 01 00         lea          rdi, [rip + 0x1fab7]
  0x404c8f: e9 70 fe ff ff               jmp          0x404b04

tvmgen_default_fused_nn_contrib_conv2d_NCHWc_add_nn_relu_compute_ @ 0x404ca0:
  0x404ca0: 48 83 ec 28                  sub          rsp, 0x28
  0x404ca4: 48 89 3c 24                  mov          qword ptr [rsp], rdi
  0x404ca8: 48 89 74 24 08               mov          qword ptr [rsp + 8], rsi
  0x404cad: 48 89 54 24 10               mov          qword ptr [rsp + 0x10], rdx
  0x404cb2: 48 89 4c 24 18               mov          qword ptr [rsp + 0x18], rcx
  0x404cb7: 44 89 44 24 20               mov          dword ptr [rsp + 0x20], r8d
  0x404cbc: 48 8d 3d 1d 00 00 00         lea          rdi, [rip + 0x1d]
  0x404cc3: 48 89 e6                     mov          rsi, rsp
  0x404cc6: 31 d2                        xor          edx, edx
  0x404cc8: e8 a3 84 01 00               call         0x41d170
  0x404ccd: 48 83 c4 28                  add          rsp, 0x28
  0x404cd1: c3                           ret          
